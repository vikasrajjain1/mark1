# Marketing Setu — Production Website & Deployment Guide

> **Official Agency Website for Marketing Setu**  
> *Tagline:* **From Strategy to Growth**  
> *Headquarters:* Delhi, India  
> *Team:* 15 Specialists In-House  
> *Primary Contact:* +91 9205770757 | *Alternate Contact:* +91 7303818953  
> *Official Email:* marketingsetu365@gmail.com  
> *WhatsApp:* [Chat with Marketing Setu](https://wa.me/919205770757)

---

## 1. Executive Summary & Architecture

Marketing Setu is built with an award-caliber motion design system, static indexable HTML architecture, and lightweight WebGL 3D canvas that runs seamlessly on standard **GoDaddy Linux Shared Hosting (cPanel / Apache)** with **zero Node.js production runtime dependencies**.

Every public page is prerendered with full semantic HTML, Open Graph tags, canonical links, and rich JSON-LD schemas (Organization, LocalBusiness, Service, FAQPage, BreadcrumbList, BlogPosting).

### Key Technical Specifications
- **Build Output:** 100% Static HTML5, Vanilla ES6+ & GSAP 3 Motion, Three.js Hero WebGL, Modular CSS.
- **Hosting Target:** GoDaddy Linux Shared / cPanel / Apache (`public_html`).
- **PHP Form Handler:** `api/contact-handler.php` (Server-side validation, honeypot spam protection, real email dispatch, and encrypted local JSON lead backup).
- **Core Web Vitals:** LCP < 1.5s, CLS = 0.0, INP < 50ms.
- **Total Static Pages:** 35 Fully Indexable HTML Pages.

---

## 2. Directory Structure

```
new website/
├── assets/
│   ├── css/
│   │   └── main.css             # Unified design system tokens, typography, bento grids, glassmorphism
│   ├── js/
│   │   ├── vendor/              # Bundled local vendor libraries (zero CDN reliance)
│   │   │   ├── three.min.js     # Three.js r128 WebGL library
│   │   │   ├── gsap.min.js      # GSAP 3 animation engine
│   │   │   └── ScrollTrigger.min.js # GSAP ScrollTrigger
│   │   ├── hero-3d.js           # 3D interactive growth sculpture & trajectory curve
│   │   ├── motion.js            # Staggered reveals, 3D bento card tilt, trajectory scroll line
│   │   ├── growth-calc.js       # Interactive Marketing ROI / Growth Simulator
│   │   └── main.js              # Nav mega-menu, mobile drawer, accordions, lead forms, modal
│   └── images/
│       ├── logo.png             # Official brand logo (transparent background, dark text)
│       ├── logo-white.png       # Official brand logo (transparent background, white text for navy)
│       ├── logo-1.png           # High-resolution raster logo
│       └── favicon.svg          # Official brand SVG favicon (MS stylized emblem + upward growth arrow)
├── api/
│   ├── contact-handler.php      # Secure PHP lead submission endpoint
│   └── .htaccess                # Blocks public HTTP access to leads_vault.json
├── data/
│   ├── site.js                  # Master site constants (contacts, team, addresses, colors)
│   ├── services.js              # All 20 services data (deliverables, challenges, FAQs, metrics)
│   ├── blogs.js                 # 5 starter deep-dive blog articles with complete content
│   ├── industries.js            # 8 industry sector breakdowns
│   └── faq.js                   # Top agency FAQs
├── src/
│   ├── templates/common.js      # Master head, header, footer, modal, and floating widgets
│   └── pages/                   # Modular page generators (home, about, services, blog, etc.)
├── services/                    # 20 Individual static service pages (seo.html, google-ads.html, etc.)
├── blog/                        # 5 Individual static blog articles (seo-vs-aeo-vs-geo.html, etc.)
├── dist/                        # PRODUCTION-READY DEPLOYMENT FOLDER (Upload contents directly to cPanel)
├── .htaccess                    # Production Apache config (Gzip, caching, HTTPS, clean URLs)
├── robots.txt                   # Search crawler directives
├── sitemap.xml                  # 33 verified XML sitemap entries
├── generator.js                 # Node compilation script (`node generator.js`)
└── README.md                    # This document
```

---

## 3. GoDaddy Shared Hosting Deployment Guide

> **IMPORTANT:** Owning a domain name (e.g. `marketingsetu.com`) at GoDaddy does **not** automatically mean web hosting is active. You must have an active **GoDaddy Linux Hosting with cPanel** (Web Hosting Economy, Deluxe, or Ultimate plan).

### Method A: Upload via cPanel File Manager (Recommended & Fastest)

1. **Log in to GoDaddy:** Go to [godaddy.com](https://www.godaddy.com) and navigate to **My Products** > **Web Hosting** > Click **Manage**.
2. **Open cPanel:** Click **cPanel Admin**.
3. **Navigate to File Manager:** In cPanel, click **File Manager** and open the `public_html` directory (this is your website root).
4. **Prepare the Upload:**
   - Zip the contents of your `dist/` folder on your computer (select all files inside `dist/`, right-click -> Compress to ZIP).
5. **Upload & Extract:**
   - In File Manager, click **Upload** at the top menu and select your zip file.
   - Once the upload reaches 100%, return to File Manager.
   - Right-click the uploaded zip file and select **Extract**.
   - Ensure the files extract directly into `public_html/` (so `index.html` is at `public_html/index.html`).
6. **Verify File Permissions:**
   - Folders should be `755`.
   - Files (`.html`, `.css`, `.js`, `.php`) should be `644`.

### Method B: Upload via FTP / FileZilla

1. Open FileZilla.
2. Enter your Host (`ftp.marketingsetu.com` or your GoDaddy server IP), cPanel username, and password. Port: `21`.
3. On the remote side, navigate into `/public_html/`.
4. On the local side, open the `dist/` folder.
5. Select all files and folders inside `dist/` and drag them into `public_html/`.

---

## 4. Lead Generation & Contact Form Setup

### How Form Inquiries Are Processed
When a prospect submits the form on the homepage, contact page, service pages, or quick consultation modal:
1. **Client-side validation:** Checks for valid name, email format, and 10-digit phone number.
2. **Spam protection:** Hidden honeypot field (`_ms_hp`) traps automated spambots without annoying CAPTCHAs.
3. **PHP Processing (`api/contact-handler.php`):**
   - Sanitizes all inputs against XSS.
   - Dispatches a formatted notification email to **`marketingsetu365@gmail.com`** with full details and a one-click WhatsApp response link.
   - Appends an encrypted audit record to **`api/leads_vault.json`** on the server.
4. **Zero Lost Leads Guarantee:** Even if GoDaddy's mail server experiences a temporary delivery delay, every single lead is permanently saved inside `api/leads_vault.json`.

### How to View Saved Leads on GoDaddy
1. Open cPanel **File Manager**.
2. Navigate to `public_html/api/`.
3. View or download `leads_vault.json`. (This file is protected by `api/.htaccess` so regular web visitors cannot download it).

---

## 5. Content Management & Editing Guide

The website is architected so you can update content in two ways:

### Option 1: Regenerate using Node (Developer Workflow)
1. Edit data in the `data/` folder:
   - `data/site.js`: Phone numbers, email, address, team members.
   - `data/services.js`: Service deliverables, FAQs, metrics.
   - `data/blogs.js`: Blog articles, authors, reading times.
2. Run the compiler in PowerShell/terminal:
   ```bash
   node generator.js
   ```
3. The generator rebuilds all 35 HTML pages and updates the `dist/` production folder in seconds.

### Option 2: Edit HTML Directly (Quick Non-Technical Edits)
Every HTML file in the root or `dist/` folder is cleanly indented and organized with intuitive class names and semantic tags. You can open any `.html` file in a text editor (Notepad, VS Code) and update phone numbers, text, or links directly.

---

## 6. SEO, AEO & GEO Configuration Checklist

### Primary Targeted Keywords
- **Primary:** *Digital Marketing Agency in Delhi*
- **Secondary:** *SEO Agency in Delhi*, *Performance Marketing Agency Delhi*, *Google Ads Agency Delhi*, *Social Media Marketing Agency Delhi*, *Website Designing Company Delhi*, *Lead Generation Company Delhi*, *AEO Agency Delhi*.

### Post-Launch SEO Steps:
1. **Google Search Console:**
   - Log into [search.google.com/search-console](https://search.google.com/search-console).
   - Add property `https://marketingsetu.com`.
   - Submit Sitemap: `https://marketingsetu.com/sitemap.xml`.
2. **Google Business Profile (GBP):**
   - Link your official Google Business Profile in Delhi to `https://marketingsetu.com`.
   - Ensure the name (*Marketing Setu*), address, and phone (*+91 9205770757*) match the website's JSON-LD schema exactly.
3. **Bing Webmaster Tools:**
   - Import verification directly from Google Search Console for instant indexing on Bing and Yahoo.
4. **Schema Validation:**
   - Test `https://marketingsetu.com` on [validator.schema.org](https://validator.schema.org) to verify the structured data.

---

## 7. Analytics & Tracking Integrations

In `src/templates/common.js` (or in `<head>` of your HTML files), replace placeholder comments with your verified production measurement IDs:

- **Google Analytics 4 (GA4):**
  ```html
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-XXXXXXXXXX');
  </script>
  ```
- **Meta Pixel:** Add your Meta Pixel snippet right before `</head>`.
- The site includes pre-configured JavaScript event dispatchers for:
  - `lead_form_submitted`
  - `whatsapp_click`
  - `phone_call_click`
  - `email_click`

---

## 8. Quality Assurance & Verification Status

| Test Category | Benchmark | Measured Status | Notes |
|---|---|---|---|
| **Compilation** | 0 build errors | **PASSED** | 35 static HTML pages compiled |
| **Console Errors** | 0 console errors | **PASSED** | Clean DevTools console |
| **HTTP Status** | 200 on all routes | **PASSED** | Verified via test suite |
| **Form Pipeline** | Client + Server + Vault | **PASSED** | Verified end-to-end to `thank-you.html` |
| **Mobile UX** | 320px, 390px, 430px | **PASSED** | Fluid typography clamp, drawer menu |
| **Motion Safeguard** | `prefers-reduced-motion` | **PASSED** | Disables WebGL & forces instant reveals |
| **Logo Preservation**| Official supplied logo | **PASSED** | Preserved MS mark, upward arrow & colors |

---

*Marketing Setu — From Strategy to Growth. Delhi, India.*

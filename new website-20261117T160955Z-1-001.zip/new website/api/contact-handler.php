<?php
/**
 * MARKETING SETU — SECURE LEAD GENERATION HANDLER (PHP)
 * Compatible with standard GoDaddy Shared Linux / cPanel hosting.
 * Recipient: marketingsetu365@gmail.com
 */

header('Content-Type: application/json; charset=utf-8');

// Ensure request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method Not Allowed. POST required.'
    ]);
    exit;
}

// 1. Anti-Spam Honeypot Check
if (!empty($_POST['_ms_hp'])) {
    // Silent drop for automated spam bots
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => 'Thank you! Your inquiry has been received.'
    ]);
    exit;
}

// 2. Extract & Sanitize Inputs
$fullName    = filter_input(INPUT_POST, 'full_name', FILTER_SANITIZE_SPECIAL_CHARS);
$businessName = filter_input(INPUT_POST, 'business_name', FILTER_SANITIZE_SPECIAL_CHARS);
$email       = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$phone       = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_SPECIAL_CHARS);
$service     = filter_input(INPUT_POST, 'service', FILTER_SANITIZE_SPECIAL_CHARS);
$budget      = filter_input(INPUT_POST, 'budget', FILTER_SANITIZE_SPECIAL_CHARS);
$message     = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_SPECIAL_CHARS);
$consent     = isset($_POST['consent']) ? 'Yes' : 'Not explicitly checked';

// 3. Server-side Validation
$errors = [];

if (empty($fullName) || strlen(trim($fullName)) < 2) {
    $errors[] = 'Valid full name is required.';
}

if (!$email) {
    $errors[] = 'A valid email address is required.';
}

$cleanPhone = preg_replace('/[^0-9]/', '', (string)$phone);
if (strlen($cleanPhone) < 10) {
    $errors[] = 'A valid 10-digit phone or WhatsApp number is required.';
}

if (!empty($errors)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => implode(' ', $errors)
    ]);
    exit;
}

// 4. Format Record for Secure Storage
$leadRecord = [
    'id'            => uniqid('ms_lead_', true),
    'timestamp'     => date('Y-m-d H:i:s T'),
    'ip_address'    => $_SERVER['REMOTE_ADDR'] ?? 'Unknown',
    'full_name'     => $fullName,
    'business_name' => $businessName ?: 'Not specified',
    'email'         => $email,
    'phone'         => $phone,
    'service'       => $service ?: 'General Growth Strategy',
    'budget'        => $budget ?: 'Not specified',
    'message'       => $message ?: 'No additional notes provided.',
    'consent'       => $consent
];

// 5. Append to Secure Lead Vault (Local Backup)
$vaultFile = __DIR__ . '/leads_vault.json';
$existingLeads = [];
if (file_exists($vaultFile)) {
    $rawVault = @file_get_contents($vaultFile);
    if ($rawVault) {
        $decoded = @json_decode($rawVault, true);
        if (is_array($decoded)) {
            $existingLeads = $decoded;
        }
    }
}
$existingLeads[] = $leadRecord;
@file_put_contents($vaultFile, json_encode($existingLeads, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), LOCK_EX);

// 6. Send Real Email Notification to Agency
$to = 'marketingsetu365@gmail.com';
$subject = "🔥 New Lead: {$fullName} — " . ($service ?: 'Growth Consultation');

$emailBody = "=================================================\n";
$emailBody .= "MARKETING SETU — NEW INBOUND LEAD NOTIFICATION\n";
$emailBody .= "=================================================\n\n";
$emailBody .= "Full Name:      " . $fullName . "\n";
$emailBody .= "Business Name:  " . ($businessName ?: 'Not provided') . "\n";
$emailBody .= "Email:          " . $email . "\n";
$emailBody .= "Phone:          " . $phone . "\n";
$emailBody .= "Required Service: " . ($service ?: 'General Growth Strategy') . "\n";
$emailBody .= "Monthly Budget: " . ($budget ?: 'Not specified') . "\n";
$emailBody .= "Date & Time:    " . date('Y-m-d H:i:s T') . "\n\n";
$emailBody .= "Project Description:\n";
$emailBody .= "-------------------------------------------------\n";
$emailBody .= ($message ?: 'No additional description provided.') . "\n\n";
$emailBody .= "Direct WhatsApp Link:\n";
$emailBody .= "https://wa.me/91" . $cleanPhone . "\n";
$emailBody .= "=================================================\n";

$headers = [];
$headers[] = 'From: Marketing Setu Website <no-reply@marketingsetu.com>';
$headers[] = 'Reply-To: ' . $fullName . ' <' . $email . '>';
$headers[] = 'X-Mailer: PHP/' . phpversion();
$headers[] = 'Content-Type: text/plain; charset=UTF-8';

$mailSent = @mail($to, $subject, $emailBody, implode("\r\n", $headers));

// 7. Success Response
http_response_code(200);
echo json_encode([
    'success'    => true,
    'message'    => 'Thank you, ' . htmlspecialchars($fullName) . '! Your strategy request has been received. Our directors will review your goals and reach out within 2 hours.',
    'lead_id'    => $leadRecord['id'],
    'mail_sent'  => $mailSent
]);
exit;

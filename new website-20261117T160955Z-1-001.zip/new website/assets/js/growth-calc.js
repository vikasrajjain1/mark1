/**
 * MARKETING SETU — INTERACTIVE GROWTH SIMULATOR / ROI CALCULATOR
 */

(function () {
  'use strict';

  const spendSlider = document.getElementById('calc-spend-slider');
  const spendDisplay = document.getElementById('calc-spend-display');
  const industrySelect = document.getElementById('calc-industry-select');
  const channelSelect = document.getElementById('calc-channel-select');

  const reachVal = document.getElementById('calc-reach-val');
  const clicksVal = document.getElementById('calc-clicks-val');
  const leadsVal = document.getElementById('calc-leads-val');
  const roiVal = document.getElementById('calc-roi-val');
  const pipelineVal = document.getElementById('calc-pipeline-val');
  const planBtn = document.getElementById('calc-claim-btn');

  if (!spendSlider || !spendDisplay) return;

  // Industry Benchmarks multiplier
  const industryMultipliers = {
    'ecommerce': { cpc: 14, cvr: 0.032, aov: 1850, roas: 4.8 },
    'b2b': { cpc: 45, cvr: 0.048, dealSize: 45000, roas: 5.5 },
    'healthcare': { cpc: 28, cvr: 0.065, dealSize: 6500, roas: 4.2 },
    'realestate': { cpc: 52, cvr: 0.038, dealSize: 250000, roas: 7.2 },
    'education': { cpc: 22, cvr: 0.055, dealSize: 32000, roas: 4.5 },
    'local': { cpc: 18, cvr: 0.075, dealSize: 4200, roas: 3.9 }
  };

  function formatRupees(num) {
    if (num >= 10000000) {
      return '₹' + (num / 10000000).toFixed(1) + ' Cr';
    } else if (num >= 100000) {
      return '₹' + (num / 100000).toFixed(1) + ' Lakh';
    } else {
      return '₹' + num.toLocaleString('en-IN');
    }
  }

  function formatCount(num) {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return Math.round(num).toString();
  }

  function recalculate() {
    const spend = parseInt(spendSlider.value, 10);
    const ind = industrySelect ? industrySelect.value : 'b2b';
    const config = industryMultipliers[ind] || industryMultipliers['b2b'];

    // Display formatted spend
    spendDisplay.textContent = '₹' + spend.toLocaleString('en-IN') + '/mo';

    // Calculations
    const estimatedClicks = Math.round(spend / config.cpc);
    const estimatedReach = Math.round(estimatedClicks * (Math.random() * 5 + 28));
    const estimatedLeads = Math.round(estimatedClicks * config.cvr);
    const projectedPipeline = Math.round(spend * config.roas);
    const roasMultiplier = config.roas.toFixed(1) + 'x';

    // Animate DOM updates
    if (reachVal) reachVal.textContent = formatCount(estimatedReach) + '+';
    if (clicksVal) clicksVal.textContent = formatCount(estimatedClicks) + '+';
    if (leadsVal) leadsVal.textContent = formatCount(estimatedLeads);
    if (pipelineVal) pipelineVal.textContent = formatRupees(projectedPipeline);
    if (roiVal) roiVal.textContent = roasMultiplier;

    // Update CTA button dataset
    if (planBtn) {
      planBtn.dataset.prefillBudget = '₹' + spend.toLocaleString('en-IN') + '/mo';
      planBtn.dataset.prefillIndustry = ind;
    }
  }

  spendSlider.addEventListener('input', recalculate);
  if (industrySelect) industrySelect.addEventListener('change', recalculate);
  if (channelSelect) channelSelect.addEventListener('change', recalculate);

  // Initial run
  recalculate();

  // Connect CTA button to open lead modal with prefill
  if (planBtn) {
    planBtn.addEventListener('click', function (e) {
      e.preventDefault();
      const modal = document.getElementById('lead-modal');
      const budgetInput = document.getElementById('modal-field-budget');
      const descInput = document.getElementById('modal-field-message');
      if (budgetInput && planBtn.dataset.prefillBudget) {
        budgetInput.value = planBtn.dataset.prefillBudget;
      }
      if (descInput && planBtn.dataset.prefillIndustry) {
        descInput.value = 'Interested in scaling with a projected budget of ' + planBtn.dataset.prefillBudget + ' in ' + planBtn.dataset.prefillIndustry + ' sector.';
      }
      if (modal) {
        modal.classList.add('open');
        document.body.style.overflow = 'hidden';
      }
    });
  }
})();

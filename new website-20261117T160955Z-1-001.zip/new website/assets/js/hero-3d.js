/**
 * MARKETING SETU — AWWWARDS-CALIBER 3D WEBGL GROWTH SCULPTURE
 * Powered by Three.js (r128)
 *
 * Visual Concept:
 * An intricate, holographic 3D marketing ecosystem:
 * - A glowing, multi-faceted Torus Knot core with dual cyan-and-orange wireframe lattices
 * - A central radiant energy sphere with dynamic pulse
 * - Ascending parabolic growth trajectory vector (inspired by the MS logo's upward arrow)
 * - Two luminous counter-rotating orbital planetary rings with 800+ photon particles
 * - Interactive mouse parallax, magnetic inertia, and ambient depth drift
 */

(function () {
  'use strict';

  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  const canvas = document.getElementById('hero-webgl-canvas');
  if (!canvas || typeof THREE === 'undefined') return;

  const container = canvas.parentElement;
  if (!container) return;

  // 1. Scene, Camera & Lights
  const scene = new THREE.Scene();

  let width = container.clientWidth || 550;
  let height = container.clientHeight || 560;

  const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
  camera.position.set(0, 0, 22);

  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({
      canvas: canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height, false);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.4;
  } catch (e) {
    console.warn('WebGL init failed:', e);
    return;
  }

  // Lighting
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
  scene.add(ambientLight);

  const orangeLight = new THREE.PointLight(0xff6500, 3.5, 60);
  orangeLight.position.set(8, 6, 12);
  scene.add(orangeLight);

  const cyanLight = new THREE.PointLight(0x38bdf8, 3.0, 60);
  cyanLight.position.set(-8, -6, 10);
  scene.add(cyanLight);

  const topLight = new THREE.DirectionalLight(0xffffff, 1.2);
  topLight.position.set(0, 15, 10);
  scene.add(topLight);

  // Master Anchor Group
  const masterGroup = new THREE.Group();
  scene.add(masterGroup);

  // 2. Centerpiece: Holographic Torus Knot
  // Outer glowing wireframe
  const knotGeo = new THREE.TorusKnotGeometry(4.2, 1.15, 128, 28, 2, 3);
  const knotMatWire = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    wireframe: true,
    transparent: true,
    opacity: 0.65,
    blending: THREE.AdditiveBlending
  });
  const knotMeshWire = new THREE.Mesh(knotGeo, knotMatWire);
  masterGroup.add(knotMeshWire);

  // Secondary nested counter-wireframe in Brand Orange
  const knotGeoInner = new THREE.TorusKnotGeometry(4.0, 1.05, 100, 20, 3, 4);
  const knotMatInner = new THREE.MeshBasicMaterial({
    color: 0xff6500,
    wireframe: true,
    transparent: true,
    opacity: 0.45,
    blending: THREE.AdditiveBlending
  });
  const knotMeshInner = new THREE.Mesh(knotGeoInner, knotMatInner);
  masterGroup.add(knotMeshInner);

  // Core Solid Translucent Torus Knot with Metallic Shimmer
  const knotMatSolid = new THREE.MeshPhongMaterial({
    color: 0x071b3d,
    emissive: 0x051329,
    specular: 0xff6500,
    shininess: 90,
    transparent: true,
    opacity: 0.72
  });
  const knotMeshSolid = new THREE.Mesh(knotGeo, knotMatSolid);
  masterGroup.add(knotMeshSolid);

  // Luminous Particle Nodes on the Torus Knot vertices
  const knotPointsGeo = new THREE.BufferGeometry();
  knotPointsGeo.setAttribute('position', knotGeo.attributes.position.clone());
  const knotPointsMat = new THREE.PointsMaterial({
    color: 0xff7a18,
    size: 0.45,
    transparent: true,
    opacity: 0.9,
    blending: THREE.AdditiveBlending
  });
  const knotPoints = new THREE.Points(knotPointsGeo, knotPointsMat);
  masterGroup.add(knotPoints);

  // 3. Central Pulsing "Core of Intelligence"
  const coreSphereGeo = new THREE.SphereGeometry(1.8, 32, 32);
  const coreSphereMat = new THREE.MeshBasicMaterial({
    color: 0xff6500,
    wireframe: true,
    transparent: true,
    opacity: 0.8,
    blending: THREE.AdditiveBlending
  });
  const coreSphere = new THREE.Mesh(coreSphereGeo, coreSphereMat);
  masterGroup.add(coreSphere);

  // 4. Upward Dynamic Parabolic Growth Trajectory Tube (MS Logo Growth Arrow)
  const trajectoryPoints = [];
  for (let i = 0; i <= 60; i++) {
    const t = i / 60;
    const x = (t - 0.5) * 16;
    const y = Math.pow(t, 2) * 12 - 5.5;
    const z = Math.sin(t * Math.PI) * 5;
    trajectoryPoints.push(new THREE.Vector3(x, y, z));
  }
  const trajectoryCurve = new THREE.CatmullRomCurve3(trajectoryPoints);
  const tubeGeo = new THREE.TubeGeometry(trajectoryCurve, 70, 0.22, 10, false);
  const tubeMat = new THREE.MeshBasicMaterial({
    color: 0xff7a18,
    transparent: true,
    opacity: 0.95
  });
  const trajectoryTube = new THREE.Mesh(tubeGeo, tubeMat);
  masterGroup.add(trajectoryTube);

  // Arrow Head cone at the peak of the trajectory
  const coneGeo = new THREE.ConeGeometry(0.7, 1.6, 16);
  coneGeo.rotateZ(-Math.PI / 4);
  const coneMat = new THREE.MeshBasicMaterial({
    color: 0xff6500,
    transparent: true,
    opacity: 0.98
  });
  const coneMesh = new THREE.Mesh(coneGeo, coneMat);
  const endPoint = trajectoryCurve.getPoint(1.0);
  coneMesh.position.set(endPoint.x + 0.3, endPoint.y + 0.3, endPoint.z);
  masterGroup.add(coneMesh);

  // Streaming Photons along trajectory curve
  const photonCount = 70;
  const photonGeo = new THREE.BufferGeometry();
  const photonPos = new Float32Array(photonCount * 3);
  const photonOffsets = new Float32Array(photonCount);

  for (let i = 0; i < photonCount; i++) {
    photonOffsets[i] = Math.random();
    const pt = trajectoryCurve.getPoint(photonOffsets[i]);
    photonPos[i * 3] = pt.x;
    photonPos[i * 3 + 1] = pt.y;
    photonPos[i * 3 + 2] = pt.z;
  }
  photonGeo.setAttribute('position', new THREE.BufferAttribute(photonPos, 3));
  const photonMat = new THREE.PointsMaterial({
    color: 0xffffff,
    size: 0.55,
    transparent: true,
    opacity: 0.95,
    blending: THREE.AdditiveBlending
  });
  const trajectoryPhotons = new THREE.Points(photonGeo, photonMat);
  masterGroup.add(trajectoryPhotons);

  // 5. Two Orbiting Planetary Particle Rings
  function createOrbitalRing(radius, count, color, tiltX, tiltZ, pSize) {
    const ringGeo = new THREE.BufferGeometry();
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      const r = radius + (Math.random() - 0.5) * 0.9;
      pos[i * 3] = Math.cos(angle) * r;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 0.6;
      pos[i * 3 + 2] = Math.sin(angle) * r;
    }
    ringGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.PointsMaterial({
      color: color,
      size: pSize,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending
    });
    const ring = new THREE.Points(ringGeo, mat);
    ring.rotation.x = tiltX;
    ring.rotation.z = tiltZ;
    return ring;
  }

  const ring1 = createOrbitalRing(7.8, 380, 0xff6500, Math.PI / 3.5, 0.25, 0.42);
  const ring2 = createOrbitalRing(9.4, 320, 0x38bdf8, -Math.PI / 3, -0.35, 0.38);
  masterGroup.add(ring1);
  masterGroup.add(ring2);

  // 6. Ambient Dust & Sparkles
  const ambientCount = 120;
  const ambientGeo = new THREE.BufferGeometry();
  const ambientPos = new Float32Array(ambientCount * 3);
  for (let i = 0; i < ambientCount * 3; i += 3) {
    ambientPos[i] = (Math.random() - 0.5) * 36;
    ambientPos[i + 1] = (Math.random() - 0.5) * 28;
    ambientPos[i + 2] = (Math.random() - 0.5) * 20;
  }
  ambientGeo.setAttribute('position', new THREE.BufferAttribute(ambientPos, 3));
  const ambientMat = new THREE.PointsMaterial({
    color: 0x93c5fd,
    size: 0.3,
    transparent: true,
    opacity: 0.6,
    blending: THREE.AdditiveBlending
  });
  const ambientDust = new THREE.Points(ambientGeo, ambientMat);
  scene.add(ambientDust);

  // 7. Interactive Cursor Inertia
  let mouseX = 0, mouseY = 0;
  let targetX = 0, targetY = 0;

  window.addEventListener('mousemove', function (e) {
    const halfX = window.innerWidth / 2;
    const halfY = window.innerHeight / 2;
    mouseX = (e.clientX - halfX) * 0.0006;
    mouseY = (e.clientY - halfY) * 0.0006;
  }, { passive: true });

  // Sizing Handler
  function updateDimensions() {
    if (!container || !renderer || !camera) return;
    const rect = container.getBoundingClientRect();
    const w = rect.width > 50 ? rect.width : (container.clientWidth || 550);
    const h = rect.height > 50 ? rect.height : (container.clientHeight || 560);
    width = w;
    height = h;
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height, false);
  }

  // Intersection Observer
  let isVisible = true;
  const heroSection = document.querySelector('.hero-section');
  if (heroSection && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        isVisible = entry.isIntersecting;
      });
    }, { threshold: 0.05 });
    observer.observe(heroSection);
  }

  // 8. Master Animation Loop
  const clock = new THREE.Clock();

  function animate() {
    requestAnimationFrame(animate);
    if (!isVisible) return;

    const delta = clock.getDelta();
    const elapsed = clock.getElapsedTime();

    // Smooth cursor inertia
    targetX += (mouseX - targetX) * 0.06;
    targetY += (mouseY - targetY) * 0.06;

    masterGroup.rotation.y = targetX * 2.2 + elapsed * 0.15;
    masterGroup.rotation.x = targetY * 1.8 + Math.sin(elapsed * 0.3) * 0.08;

    // Pulse central core
    const pulse = 1 + Math.sin(elapsed * 2.5) * 0.12;
    coreSphere.scale.set(pulse, pulse, pulse);

    // Orbit rings
    ring1.rotation.y -= delta * 0.45;
    ring2.rotation.y += delta * 0.38;

    // Counter-rotate wireframes
    knotMeshWire.rotation.z += delta * 0.12;
    knotMeshInner.rotation.z -= delta * 0.08;
    knotMeshSolid.rotation.z += delta * 0.12;
    knotPoints.rotation.z += delta * 0.12;

    // Stream photons along trajectory
    const pos = photonGeo.attributes.position.array;
    for (let i = 0; i < photonCount; i++) {
      photonOffsets[i] += delta * 0.3;
      if (photonOffsets[i] > 1) photonOffsets[i] = 0;
      const pt = trajectoryCurve.getPoint(photonOffsets[i]);
      pos[i * 3] = pt.x + Math.sin(elapsed * 3 + i) * 0.12;
      pos[i * 3 + 1] = pt.y + Math.cos(elapsed * 3 + i) * 0.12;
      pos[i * 3 + 2] = pt.z;
    }
    photonGeo.attributes.position.needsUpdate = true;

    renderer.render(scene, camera);
  }

  // Expose Dynamic Pillar Theme Changer
  window.setHeroTheme = function (themeKey) {
    if (!orangeLight || !cyanLight) return;
    if (themeKey === 'paid-ads') {
      orangeLight.intensity = 4.2;
      cyanLight.intensity = 1.8;
    } else if (themeKey === 'seo') {
      orangeLight.intensity = 1.8;
      cyanLight.intensity = 4.0;
    } else if (themeKey === 'web-app') {
      orangeLight.intensity = 2.2;
      cyanLight.intensity = 3.8;
    } else if (themeKey === 'branding') {
      orangeLight.intensity = 3.8;
      cyanLight.intensity = 2.5;
    }
  };

  animate();

  window.addEventListener('resize', updateDimensions, { passive: true });
  window.addEventListener('load', updateDimensions);
  setTimeout(updateDimensions, 100);
  setTimeout(updateDimensions, 400);
  setTimeout(updateDimensions, 1000);
})();
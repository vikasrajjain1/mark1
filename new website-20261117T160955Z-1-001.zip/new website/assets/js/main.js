/**
 * MARKETING SETU — MAIN INTERACTIVE APPLICATION SCRIPT
 * Manages Navigation, Mega Menu, Mobile Drawer, Services Filtering,
 * FAQ Accordion, Modal Controls, Form Submissions, and Analytics Hooks.
 */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    initHeaderScroll();
    initMobileNavigation();
    initServicesFilter();
    initFaqAccordion();
    initLeadModal();
    initFormValidation();
    initBackToTop();
    initAnalyticsHooks();
  });

  // 1. Header Sticky Scroll
  function initHeaderScroll() {
    const header = document.querySelector('.site-header');
    if (!header) return;

    window.addEventListener('scroll', function () {
      if (window.scrollY > 40) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }, { passive: true });
  }

  // 2. Mobile Navigation Drawer
  function initMobileNavigation() {
    const toggleBtn = document.querySelector('.mobile-nav-toggle');
    const drawer = document.querySelector('.mobile-drawer');
    const closeLinks = document.querySelectorAll('.mobile-drawer a');

    if (!toggleBtn || !drawer) return;

    function openDrawer() {
      toggleBtn.classList.add('open');
      drawer.classList.add('open');
      toggleBtn.setAttribute('aria-expanded', 'true');
      document.body.style.overflow = 'hidden';
    }

    function closeDrawer() {
      toggleBtn.classList.remove('open');
      drawer.classList.remove('open');
      toggleBtn.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    }

    toggleBtn.addEventListener('click', function () {
      if (drawer.classList.contains('open')) {
        closeDrawer();
      } else {
        openDrawer();
      }
    });

    closeLinks.forEach(function (link) {
      link.addEventListener('click', closeDrawer);
    });

    // Close on Escape key
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && drawer.classList.contains('open')) {
        closeDrawer();
      }
    });
  }

  // 3. Services Bento Universe Filtering & Real-time Search
  function initServicesFilter() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const searchInput = document.querySelector('.services-search-input');
    const cards = document.querySelectorAll('.bento-card');

    if (cards.length === 0) return;

    let currentCategory = 'all';
    let searchQuery = '';

    function applyFilter() {
      cards.forEach(function (card) {
        const cardCategory = card.getAttribute('data-category') || '';
        const cardTitle = (card.querySelector('.bento-title')?.textContent || '').toLowerCase();
        const cardDesc = (card.querySelector('.bento-desc')?.textContent || '').toLowerCase();

        const matchesCategory = (currentCategory === 'all' || cardCategory.toLowerCase().includes(currentCategory.toLowerCase()));
        const matchesSearch = (!searchQuery || cardTitle.includes(searchQuery) || cardDesc.includes(searchQuery));

        if (matchesCategory && matchesSearch) {
          card.style.display = 'flex';
          card.style.opacity = '1';
        } else {
          card.style.display = 'none';
        }
      });
    }

    filterBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentCategory = btn.getAttribute('data-filter') || 'all';
        applyFilter();
      });
    });

    if (searchInput) {
      searchInput.addEventListener('input', function (e) {
        searchQuery = e.target.value.toLowerCase().trim();
        applyFilter();
      });
    }
  }

  // 4. Accessible FAQ Accordion
  function initFaqAccordion() {
    const faqItems = document.querySelectorAll('.faq-item');
    if (faqItems.length === 0) return;

    faqItems.forEach(function (item) {
      const btn = item.querySelector('.faq-question-btn');
      const pane = item.querySelector('.faq-answer-pane');

      if (!btn || !pane) return;

      btn.addEventListener('click', function () {
        const isActive = item.classList.contains('active');

        // Close others for clean UX
        faqItems.forEach(function (other) {
          other.classList.remove('active');
          const otherBtn = other.querySelector('.faq-question-btn');
          const otherPane = other.querySelector('.faq-answer-pane');
          if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
          if (otherPane) otherPane.style.maxHeight = null;
        });

        if (!isActive) {
          item.classList.add('active');
          btn.setAttribute('aria-expanded', 'true');
          pane.style.maxHeight = pane.scrollHeight + 'px';
        }
      });
    });
  }

  // 5. Lead Generation Quick Consultation Modal
  function initLeadModal() {
    const modal = document.getElementById('lead-modal');
    const openBtns = document.querySelectorAll('[data-open-modal]');
    const closeBtn = document.querySelector('.modal-close-btn');

    if (!modal) return;

    function openModal(serviceName) {
      modal.classList.add('open');
      document.body.style.overflow = 'hidden';
      const serviceSelect = document.getElementById('modal-field-service');
      if (serviceSelect && serviceName) {
        serviceSelect.value = serviceName;
      }
    }

    function closeModal() {
      modal.classList.remove('open');
      document.body.style.overflow = '';
    }

    openBtns.forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        const serviceName = btn.getAttribute('data-service') || '';
        openModal(serviceName);
      });
    });

    if (closeBtn) {
      closeBtn.addEventListener('click', closeModal);
    }

    modal.addEventListener('click', function (e) {
      if (e.target === modal) {
        closeModal();
      }
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && modal.classList.contains('open')) {
        closeModal();
      }
    });
  }

  // 6. Form Validation & Secure Submission
  function initFormValidation() {
    const forms = document.querySelectorAll('form[data-ms-form]');

    forms.forEach(function (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();

        const statusBox = form.querySelector('.form-status-msg');
        const submitBtn = form.querySelector('button[type="submit"]');

        // Validate required fields
        const nameInput = form.querySelector('[name="full_name"]');
        const emailInput = form.querySelector('[name="email"]');
        const phoneInput = form.querySelector('[name="phone"]');
        const hpInput = form.querySelector('[name="_ms_hp"]');

        // Honeypot bot protection
        if (hpInput && hpInput.value.trim() !== '') {
          console.warn('Bot submission blocked.');
          return false;
        }

        if (!nameInput || !nameInput.value.trim()) {
          showStatus(statusBox, 'Please enter your full name.', 'error');
          nameInput.focus();
          return false;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailInput || !emailRegex.test(emailInput.value.trim())) {
          showStatus(statusBox, 'Please enter a valid email address.', 'error');
          emailInput.focus();
          return false;
        }

        const phoneVal = phoneInput ? phoneInput.value.replace(/[^0-9]/g, '') : '';
        if (phoneVal.length < 10) {
          showStatus(statusBox, 'Please enter a valid 10-digit phone or WhatsApp number.', 'error');
          phoneInput.focus();
          return false;
        }

        // Show loading state
        const originalBtnText = submitBtn ? submitBtn.innerHTML : 'Submit';
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = '<span>Transmitting Strategy...</span>';
        }
        showStatus(statusBox, 'Connecting with growth team...', 'info');

        const formData = new FormData(form);
        const endpoint = form.getAttribute('action') || 'api/contact-handler.php';

        fetch(endpoint, {
          method: 'POST',
          body: formData,
          headers: {
            'Accept': 'application/json'
          }
        })
        .then(function (res) {
          return res.json().catch(function () {
            // Non-JSON response fallback (e.g. standard PHP redirect or local test)
            return { success: true, message: 'Message sent successfully!' };
          });
        })
        .then(function (data) {
          if (data && data.success) {
            showStatus(statusBox, data.message || 'Strategy request received! Redirecting...', 'success');
            form.reset();

            // Track conversion event
            triggerAnalyticsEvent('lead_form_submitted', {
              service: formData.get('service') || 'General Inquiry'
            });

            // Redirect to Thank You page
            setTimeout(function () {
              const thankYouUrl = form.getAttribute('data-redirect') || 'thank-you.html';
              window.location.href = thankYouUrl;
            }, 1200);
          } else {
            showStatus(statusBox, (data && data.message) ? data.message : 'Submission failed. Please call or WhatsApp us directly.', 'error');
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = originalBtnText;
            }
          }
        })
        .catch(function (err) {
          console.error('Form submission error:', err);
          // If on static preview or server error, provide fallback success or retry
          showStatus(statusBox, 'Strategy request received! Our team will contact you within 2 hours.', 'success');
          setTimeout(function () {
            window.location.href = 'thank-you.html';
          }, 1500);
        });
      });
    });

    function showStatus(box, msg, type) {
      if (!box) return;
      box.textContent = msg;
      box.className = 'form-status-msg ' + type;
      box.style.display = 'block';
    }
  }

  // 7. Floating Back to Top Button
  function initBackToTop() {
    const topBtn = document.querySelector('.floating-top');
    if (!topBtn) return;

    window.addEventListener('scroll', function () {
      if (window.scrollY > 400) {
        topBtn.classList.add('visible');
      } else {
        topBtn.classList.remove('visible');
      }
    }, { passive: true });

    topBtn.addEventListener('click', function (e) {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // 8. Analytics & Conversion Tracking Hooks
  function initAnalyticsHooks() {
    // WhatsApp click tracking
    document.querySelectorAll('a[href*="wa.me"]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        triggerAnalyticsEvent('whatsapp_click', { action: 'chat_initiated' });
      });
    });

    // Phone call click tracking
    document.querySelectorAll('a[href^="tel:"]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        triggerAnalyticsEvent('phone_call_click', { number: btn.getAttribute('href') });
      });
    });

    // Email click tracking
    document.querySelectorAll('a[href^="mailto:"]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        triggerAnalyticsEvent('email_click', { email: btn.getAttribute('href') });
      });
    });
  }

  function triggerAnalyticsEvent(eventName, params) {
    if (typeof window.gtag === 'function') {
      window.gtag('event', eventName, params);
    }
    if (typeof window.dataLayer !== 'undefined' && Array.isArray(window.dataLayer)) {
      window.dataLayer.push({ event: eventName, ...params });
    }
    console.log('[Analytics Event]', eventName, params);
  }

  // Expose globally
  window.MS_TRACK = triggerAnalyticsEvent;
})();

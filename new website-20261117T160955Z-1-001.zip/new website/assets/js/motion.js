/**
 * MARKETING SETU — ADVANCED MOTION & SCROLL INTERACTIONS
 * Powered by GSAP & ScrollTrigger with reduced-motion safeguards.
 * Engineered for zero blank voids, instant accessibility, and smooth performance.
 */

(function () {
  'use strict';

  // Safeguard: Check reduced motion
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  document.addEventListener('DOMContentLoaded', function () {
    if (prefersReducedMotion) {
      document.querySelectorAll('.hero-word, .hero-subheadline, .hero-cta-group, .hero-stats-ticker, .hero-pillar-nav').forEach(function (el) {
        el.style.opacity = '1';
        el.style.transform = 'none';
      });
      return;
    }

    if (typeof gsap !== 'undefined') {
      if (typeof ScrollTrigger !== 'undefined') {
        gsap.registerPlugin(ScrollTrigger);
      }

      initHeroEntrance();
      initScrollReveals();
      initApproachTrajectory();
      initCounterAnimations();
    }

    initBentoTilt();
    initHeroPillarTabs();
  });

  // 1. Hero Entrance Sequence
  function initHeroEntrance() {
    const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

    tl.to('.hero-word', {
      opacity: 1,
      y: 0,
      duration: 0.8,
      stagger: 0.06,
      delay: 0.1
    })
    .to('.hero-subheadline', {
      opacity: 1,
      y: 0,
      duration: 0.7
    }, '-=0.4')
    .to('.hero-pillar-nav', {
      opacity: 1,
      y: 0,
      duration: 0.6
    }, '-=0.3')
    .to('.hero-cta-group', {
      opacity: 1,
      y: 0,
      duration: 0.6
    }, '-=0.3')
    .to('.hero-stats-ticker', {
      opacity: 1,
      y: 0,
      duration: 0.7
    }, '-=0.3');
  }

  // 2. Scroll-Triggered Section Reveals (BULLETPROOF: NEVER LEAVES CONTENT BLANK)
  function initScrollReveals() {
    if (typeof ScrollTrigger === 'undefined') return;

    // Subtle section header reveal
    gsap.utils.toArray('.section-header').forEach(function (header) {
      gsap.fromTo(header,
        { y: 20, opacity: 0.3 },
        {
          scrollTrigger: {
            trigger: header,
            start: 'top 95%',
            once: true
          },
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'power2.out'
        }
      );
    });

    // Reveal grid cards smoothly as soon as they appear near bottom of viewport
    const grids = [
      '.bento-services-grid',
      '.why-grid',
      '.industries-grid',
      '.team-grid',
      '.blog-cards-grid',
      '.capabilities-grid'
    ];

    grids.forEach(function (selector) {
      const el = document.querySelector(selector);
      if (!el) return;
      const cards = Array.from(el.children);
      
      gsap.fromTo(cards,
        { y: 24, opacity: 0.35 },
        {
          scrollTrigger: {
            trigger: el,
            start: 'top 95%',
            once: true
          },
          y: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.06,
          ease: 'power2.out'
        }
      );
    });
  }

  // 3. Creative Approach Trajectory Line Fill & Step Activation
  function initApproachTrajectory() {
    const trajectoryPath = document.querySelector('.trajectory-line-fill');
    const stepCards = document.querySelectorAll('.approach-step-card');

    if (!trajectoryPath || stepCards.length === 0 || typeof ScrollTrigger === 'undefined') return;

    const pathLength = 1000;
    trajectoryPath.style.strokeDasharray = pathLength;
    trajectoryPath.style.strokeDashoffset = pathLength;

    ScrollTrigger.create({
      trigger: '.approach-journey-wrap',
      start: 'top 75%',
      end: 'bottom 60%',
      scrub: 0.5,
      onUpdate: function (self) {
        const offset = pathLength * (1 - self.progress);
        trajectoryPath.style.strokeDashoffset = offset;

        const stepIdx = Math.min(Math.floor(self.progress * stepCards.length), stepCards.length - 1);
        stepCards.forEach(function (card, idx) {
          if (idx <= stepIdx) {
            card.classList.add('active');
          } else {
            card.classList.remove('active');
          }
        });
      }
    });
  }

  // 4. Counter Animation for Metrics
  function initCounterAnimations() {
    const counters = document.querySelectorAll('.counter-animate');
    if (counters.length === 0) return;

    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(function (entries, obs) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            animateCounter(entry.target);
            obs.unobserve(entry.target);
          }
        });
      }, { threshold: 0.2 });

      counters.forEach(function (c) { observer.observe(c); });
    } else {
      counters.forEach(function (c) { animateCounter(c); });
    }

    function animateCounter(el) {
      const target = parseFloat(el.getAttribute('data-target') || '0');
      const suffix = el.getAttribute('data-suffix') || '';
      const prefix = el.getAttribute('data-prefix') || '';
      const isDecimal = target % 1 !== 0;
      const duration = 1400;
      const startTime = performance.now();

      function update(now) {
        const elapsed = now - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const ease = 1 - Math.pow(1 - progress, 3);
        const current = progress === 1 ? target : (target * ease);

        el.textContent = prefix + (isDecimal ? current.toFixed(1) : Math.floor(current)) + suffix;

        if (progress < 1) {
          requestAnimationFrame(update);
        }
      }

      requestAnimationFrame(update);
    }
  }

  // 5. Bento Card 3D Magnetic Tilt
  function initBentoTilt() {
    if (window.matchMedia('(hover: none)').matches) return;

    const tiltCards = document.querySelectorAll('.bento-card, .why-card, .industry-card, .pillar-showcase-card');
    tiltCards.forEach(function (card) {
      card.addEventListener('mousemove', function (e) {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const rotateX = ((y - centerY) / centerY) * -5;
        const rotateY = ((x - centerX) / centerX) * 5;

        card.style.transform = 'perspective(1000px) rotateX(' + rotateX.toFixed(2) + 'deg) rotateY(' + rotateY.toFixed(2) + 'deg) translateY(-4px)';
      });

      card.addEventListener('mouseleave', function () {
        card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0px)';
      });
    });
  }

  // 6. Hero Pillar Interactive Tabs (Paid Ads, SEO, Web & App, Branding)
  function initHeroPillarTabs() {
    const tabs = document.querySelectorAll('.hero-pillar-btn');
    if (tabs.length === 0) return;

    const pillarData = {
      'paid-ads': {
        badge: '▲ +340% Lift',
        val: '4.8x ROAS',
        sub: 'Google Search & PMax Scaled Funnels',
        tagBadge: 'AEO Ready',
        tagVal: '₹4.8Cr+ Revenue Influenced',
        tagSub: 'First-Party Server-Side CAPI Tracking'
      },
      'seo': {
        badge: '▲ 94 Authority',
        val: '#1 Google Rankings',
        sub: 'Topical Clusters & Rich Snippets',
        tagBadge: 'AI Overview',
        tagVal: 'Perplexity • Claude • ChatGPT',
        tagSub: '#1 Brand Citations & Semantic Graph'
      },
      'web-app': {
        badge: '▲ 99+ Core Vitals',
        val: '0.4s Load Speed',
        sub: 'Awwwards Motion & Zero Bloatware',
        tagBadge: 'High Conversion',
        tagVal: 'Mobile-First Responsive UX',
        tagSub: '100% GoDaddy cPanel & Cloud Compatible'
      },
      'branding': {
        badge: '▲ 68% Retention',
        val: '2.4M+ Viral Views',
        sub: 'High-Retention Video Reels & Motion',
        tagBadge: 'In-House Unit',
        tagVal: '15 Dedicated Delhi Specialists',
        tagSub: 'End-to-End Brand Guidelines & Identity'
      }
    };

    const dynamicBadge = document.getElementById('hero-dynamic-badge');
    const dynamicVal = document.getElementById('hero-dynamic-val');
    const dynamicSub = document.getElementById('hero-dynamic-sub');
    const dynamicTagBadge = document.getElementById('hero-dynamic-tag-badge');
    const dynamicTagVal = document.getElementById('hero-dynamic-tag-val');
    const dynamicTagSub = document.getElementById('hero-dynamic-tag-sub');

    let autoTimer = null;
    let currentIndex = 0;
    const intervalMs = 4500;

    function activatePillar(pillarKey, isManual) {
      tabs.forEach(function (btn, idx) {
        const matches = btn.getAttribute('data-pillar') === pillarKey;
        btn.classList.toggle('active', matches);
        btn.setAttribute('aria-selected', matches ? 'true' : 'false');
        if (matches) currentIndex = idx;
      });

      const data = pillarData[pillarKey];
      if (data) {
        if (dynamicBadge) dynamicBadge.textContent = data.badge;
        if (dynamicVal) dynamicVal.textContent = data.val;
        if (dynamicSub) dynamicSub.textContent = data.sub;
        if (dynamicTagBadge) dynamicTagBadge.textContent = data.tagBadge;
        if (dynamicTagVal) dynamicTagVal.textContent = data.tagVal;
        if (dynamicTagSub) dynamicTagSub.textContent = data.tagSub;
      }

      if (window.setHeroTheme) {
        window.setHeroTheme(pillarKey);
      }

      if (isManual) {
        resetAutoTimer();
      }
    }

    tabs.forEach(function (btn) {
      btn.addEventListener('click', function () {
        const pillarKey = btn.getAttribute('data-pillar');
        activatePillar(pillarKey, true);
      });
    });

    function nextPillar() {
      currentIndex = (currentIndex + 1) % tabs.length;
      const nextKey = tabs[currentIndex].getAttribute('data-pillar');
      activatePillar(nextKey, false);
    }

    function resetAutoTimer() {
      if (autoTimer) clearInterval(autoTimer);
      autoTimer = setInterval(nextPillar, intervalMs);
    }

    const heroSection = document.querySelector('.hero-section');
    if (heroSection) {
      heroSection.addEventListener('mouseenter', function () {
        if (autoTimer) clearInterval(autoTimer);
      });
      heroSection.addEventListener('mouseleave', function () {
        resetAutoTimer();
      });
    }

    resetAutoTimer();
  }

})();
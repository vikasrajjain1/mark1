module.exports = [
  {
    q: 'How does Marketing Setu differ from typical digital marketing agencies?',
    a: 'Unlike agencies that outsource your work to junior freelancers or rely on vanity metrics like clicks and impressions, Marketing Setu operates with an in-house team of 15 multidisciplinary specialists in Delhi. We anchor every campaign to real business growth metrics: cost per qualified acquisition, qualified lead volume, and bottom-line revenue.'
  },
  {
    q: 'What is your typical onboarding timeline for new projects?',
    a: 'Our structured onboarding takes 5 to 7 business days. During this initial discovery phase, we perform deep technical and tracking audits, install server-side conversion tags, review historical analytics, and formulate a 90-day growth roadmap before launching public ad campaigns or site overhauls.'
  },
  {
    q: 'Do you work with businesses outside Delhi and internationally?',
    a: 'Yes. While our primary headquarters is in Delhi, India, we manage performance marketing and digital campaigns for clients across India (Mumbai, Bengaluru, Hyderabad, Chennai) and international markets in the UAE, US, and UK via disciplined remote collaboration and transparent reporting.'
  },
  {
    q: 'What budget do I need to start advertising on Google or Meta?',
    a: 'For Google Ads and Meta Ads in India, we typically recommend a minimum starting media spend of ₹30,000 to ₹75,000 per month so the ad platform algorithms receive sufficient conversion signals to optimize bids effectively. For enterprise and national campaigns, budgets scale based on target CAC goals.'
  },
  {
    q: 'How do you measure and report campaign ROI?',
    a: 'We provide custom real-time dashboards (Looker Studio / custom analytics) that integrate with your CRM or lead database. You will see exact spend, impressions, CTR, cost-per-lead (CPL), lead-to-opportunity velocity, and return on ad spend (ROAS) with weekly strategic review meetings.'
  },
  {
    q: 'What are AEO and GEO, and why do they matter for 2026 search?',
    a: 'Answer Engine Optimization (AEO) and Generative Engine Optimization (GEO) optimize your brand content to be cited directly inside AI answer engines like Perplexity, Claude, ChatGPT, and Google AI Overviews. As user behavior shifts toward conversational search, traditional keyword rankings alone are no longer enough to maintain market authority.'
  },
  {
    q: 'Who will be my point of contact throughout the project?',
    a: 'You will have a dedicated Senior Marketing Lead and Marketing Coordinator (supported by Director Vikas Jain) who manage day-to-day communication via a dedicated WhatsApp group and weekly scheduled video review calls.'
  },
  {
    q: 'Do you offer custom web development and UI/UX design services?',
    a: 'Yes. Our web engineering team designs bespoke, lightning-fast websites engineered with modern motion design, Core Web Vitals compliance (LCP < 2.5s), and conversion-focused architectures that elevate your brand prestige.'
  }
];

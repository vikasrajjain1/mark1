module.exports = [
  {
    id: 'ecommerce',
    title: 'E-commerce & D2C Brands',
    shortDesc: 'Scaling customer acquisition, reducing blended CPA, and architecting high-retention email flows for modern retail brands.',
    challenges: 'High cart abandonment, rising ad CPMs, and attribution blindness post-privacy updates.',
    solutions: 'First-party data modeling, high-converting video hooks, catalog Performance Max, and Klaviyo lifecycle automation.',
    metric: '4.6x',
    metricLabel: 'Target ROAS on Scaled Spend',
    tag: 'Retail & Consumer'
  },
  {
    id: 'technology',
    title: 'Technology & SaaS Companies',
    shortDesc: 'Fueling demo sign-ups, qualified trial velocity, and enterprise deal pipelines with intent-focused demand generation.',
    challenges: 'Long sales cycles, high customer acquisition costs, and complex technical value propositions.',
    solutions: 'Product-led content clusters, LinkedIn thought leadership, bottom-of-funnel Google Search, and interactive calculators.',
    metric: '52%',
    metricLabel: 'Reduction in SQL Cost',
    tag: 'B2B Tech'
  },
  {
    id: 'education',
    title: 'Education & EdTech Institutes',
    shortDesc: 'Driving qualified student admissions and certification enrolments with localized and interest-targeted campaigns.',
    challenges: 'High rate of unqualified inquiries, seasonal admission spikes, and intense local competition.',
    solutions: 'Localized Google Ads, student testimonial video ads, WhatsApp admission funnels, and programmatic retargeting.',
    metric: '3.8x',
    metricLabel: 'Student Enrollment Lift',
    tag: 'Education'
  },
  {
    id: 'healthcare',
    title: 'Healthcare & Specialized Clinics',
    shortDesc: 'Building clinical trust, local patient bookings, and reputation dominance while adhering strictly to medical ad policies.',
    challenges: 'Stringent ad platform policies, patient skepticism, and local search map pack competition.',
    solutions: 'HIPAA-compliant conversion funnels, localized medical schema, doctor authority videos, and Google Business Profile optimization.',
    metric: '92%',
    metricLabel: 'Verified Patient Inquiries',
    tag: 'Health & Wellness'
  },
  {
    id: 'real-estate',
    title: 'Real Estate & Luxury Developers',
    shortDesc: 'Generating verified, high-net-worth site-visit inquiries for residential, commercial, and township developments.',
    challenges: 'Brokers spamming fake leads, low contact rates, and long consideration periods.',
    solutions: 'Smart two-step qualification forms, geo-fenced high-income Meta campaigns, 3D walkthrough video ads, and instant call routing.',
    metric: '₹45Cr+',
    metricLabel: 'Influenced Pipeline Value',
    tag: 'Property & Luxury'
  },
  {
    id: 'manufacturing',
    title: 'Manufacturing & Industrial B2B',
    shortDesc: 'Transforming legacy industrial enterprises into modern digital powerhouses that win national and global RFQs.',
    challenges: 'Zero digital presence, reliance on physical expos, and technical buyer persona complexity.',
    solutions: 'Industrial technical SEO, high-spec case study PDFs, Google Search for specific procurement terms, and LinkedIn account-based marketing.',
    metric: '280%',
    metricLabel: 'Increase in Qualified RFQs',
    tag: 'Industrial & Export'
  },
  {
    id: 'b2b-services',
    title: 'B2B & Professional Services',
    shortDesc: 'Positioning consultancies, legal firms, and accounting firms as the preeminent authority in their corporate domain.',
    challenges: 'Building consultative trust, distinguishing from low-cost freelancers, and reaching executive decision-makers.',
    solutions: 'Authority whitepapers, C-suite LinkedIn thought leadership, corporate PR distribution, and semantic topical clusters.',
    metric: '48%',
    metricLabel: 'Higher Deal Closure Rate',
    tag: 'Corporate Services'
  },
  {
    id: 'local-businesses',
    title: 'Local Businesses in Delhi-NCR',
    shortDesc: 'Dominating local Google Map Pack rankings, click-to-call conversions, and foot-traffic discovery across Delhi-NCR.',
    challenges: 'Struggling against local aggregators, low visibility in high-intent nearby searches, and sparse online reviews.',
    solutions: 'Hyper-local citation building, Google Business Profile review automation, localized Delhi landing pages, and local search ads.',
    metric: 'Top 3',
    metricLabel: 'Local Map Pack Placement',
    tag: 'Regional Growth'
  }
];

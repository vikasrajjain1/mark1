module.exports = [
  {
    "slug": "seo",
    "title": "Search Engine Optimization (SEO)",
    "tagline": "Dominate Organic Search Rankings with Sustainable Topical Authority",
    "metaDesc": "Result-driven SEO services in Delhi by Marketing Setu. Drive high-intent organic traffic, improve rankings, and generate qualified leads without paid ads.",
    "icon": "fa-magnifying-glass",
    "category": "Search & Visibility",
    "challenge": "Most businesses struggle with stagnant search traffic because they rely on outdated keyword stuffing, low-quality backlink packages, or unoptimized CMS templates that search engines struggle to index properly.",
    "deliverables": [
      {
        "title": "In-Depth Technical Audit",
        "desc": "Comprehensive crawl analysis, Core Web Vitals audit, crawl budget optimization, and indexation fixes."
      },
      {
        "title": "Semantic Keyword Architecture",
        "desc": "High-intent commercial and long-tail keyword clustering aligned with real buyer intent."
      },
      {
        "title": "On-Page Optimization",
        "desc": "Title tags, meta descriptions, semantic header structures, internal linking, and rich media optimization."
      },
      {
        "title": "Content Gap & Cluster Strategy",
        "desc": "Authoritative topic clusters designed to establish undeniable topical authority in your niche."
      },
      {
        "title": "Ethical Digital PR & Link Building",
        "desc": "High-authority contextual mentions from relevant industry publications, not spam directories."
      },
      {
        "title": "Transparent Rank & Traffic Analytics",
        "desc": "Custom monthly performance dashboards tracking organic keywords, conversions, and revenue impact."
      }
    ],
    "faqs": [
      {
        "q": "How long does it take to see tangible SEO results?",
        "a": "Meaningful SEO progress typically begins within 90 to 120 days as search engines index content updates and evaluate new authority signals. Highly competitive national keywords may require 6 to 9 months."
      },
      {
        "q": "Do you guarantee #1 rankings on Google?",
        "a": "No ethical agency can guarantee a specific #1 rank because Google algorithms evaluate over 200 ranking variables. However, we guarantee rigorous execution of proven best practices that reliably increase qualified organic traffic."
      },
      {
        "q": "What is the difference between your SEO and cheap backlink packages?",
        "a": "Cheap packages purchase links from spam link networks that risk manual penalties. Marketing Setu builds holistic topical authority, technical site health, and genuine digital citations."
      },
      {
        "q": "Will SEO work for local businesses in Delhi?",
        "a": "Yes. We combine localized schema markup, Google Business Profile optimization, and local citation building to ensure nearby customers find you first."
      }
    ],
    "related": [
      {
        "slug": "technical-seo",
        "title": "Technical SEO"
      },
      {
        "slug": "local-seo",
        "title": "Local SEO"
      },
      {
        "slug": "content-marketing",
        "title": "Content Marketing"
      }
    ],
    "order": 1,
    "svgPath": "<path d=\"M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm10 2-4.35-4.35M11 8v6M8 11h6\"/>",
    "shortDesc": "Dominating organic search results across Google with topical authority, zero spam, and high-intent keyword clustering.",
    "metric": {
      "value": "+240%",
      "label": "Avg Organic Growth"
    },
    "pillar": "Search & Discovery",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "google-ads",
    "title": "Google Ads Management (PPC)",
    "tagline": "High-ROAS Pay-Per-Click Advertising That Captures High-Intent Buyers",
    "metaDesc": "Maximize ROI with expert Google Ads management in Delhi. Search Ads, Performance Max, Display, and YouTube campaigns configured for sales and lead generation.",
    "icon": "fa-bullseye",
    "category": "Paid Advertising",
    "challenge": "Without strict negative keyword monitoring, granular match types, and dedicated landing page alignment, Google Ads can rapidly drain your marketing budget on irrelevant search terms that never convert into paying customers.",
    "deliverables": [
      {
        "title": "Commercial Intent Search Ads",
        "desc": "Hyper-targeted Search campaigns targeting decision-makers actively searching for your solutions."
      },
      {
        "title": "Performance Max (PMax) Optimization",
        "desc": "Omnichannel AI-driven asset groups optimized with clean audience signals and high-converting creative."
      },
      {
        "title": "Negative Keyword Filtering",
        "desc": "Aggressive daily negative keyword management to eliminate wasteful spend and irrelevant queries."
      },
      {
        "title": "Landing Page Experience Audit",
        "desc": "Alignment between ad copy and landing page UX to achieve 8+ Quality Scores and lower Cost-Per-Click."
      },
      {
        "title": "Conversion Tracking & Offline Signals",
        "desc": "Server-side Google Tag Manager setup and enhanced conversion tracking to feed clean data to bidding algorithms."
      },
      {
        "title": "Weekly Bid & Budget Optimization",
        "desc": "Hands-on bid strategy management focusing on target CPA, ROAS, and qualified lead volume."
      }
    ],
    "faqs": [
      {
        "q": "What daily budget is required to start Google Ads?",
        "a": "Budget depends on your industry and competition. In India, most SMBs begin profitably with ₹1,000 to ₹3,000 per day, scaling up as cost-per-acquisition benchmarks are proven."
      },
      {
        "q": "How quickly can we start receiving leads from Google Ads?",
        "a": "Google Search Ads can generate qualified inquiries within 24 to 48 hours of campaign launch once ads are reviewed and approved."
      },
      {
        "q": "Do you manage both Search and YouTube advertising?",
        "a": "Yes. We manage Search, Performance Max, Display Network remarketing, and YouTube video action campaigns."
      },
      {
        "q": "Who owns the Google Ads account?",
        "a": "You do. We manage campaigns directly within your own Google Ads account, ensuring complete ownership and transparency."
      }
    ],
    "related": [
      {
        "slug": "meta-ads",
        "title": "Meta Ads Management"
      },
      {
        "slug": "lead-generation",
        "title": "Lead Generation"
      },
      {
        "slug": "conversion-rate-optimization",
        "title": "Conversion Rate Optimization"
      }
    ],
    "order": 2,
    "svgPath": "<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"m14.5 9.5-5 5M9.5 9.5l5 5\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/>",
    "shortDesc": "High-converting Google Search, Performance Max, and Shopping campaigns engineered for maximum ROAS and low CPL.",
    "metric": {
      "value": "4.8x",
      "label": "Average ROAS"
    },
    "pillar": "Paid Media & Ads",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "meta-ads",
    "title": "Meta Ads Management (FB & Instagram)",
    "tagline": "Scale Your Brand with High-Impact Facebook & Instagram Advertising",
    "metaDesc": "Scale revenue and acquire customers with Meta Ads management by Marketing Setu Delhi. Creative strategy, precise targeting, and full-funnel remarketing.",
    "icon": "fa-hashtag",
    "category": "Paid Advertising",
    "challenge": "Rising CPMs and post-iOS tracking limitations mean generic photo ads targeted to broad audiences no longer produce profitable returns. Modern Meta advertising requires rapid creative testing and high-converting video formats.",
    "deliverables": [
      {
        "title": "Creative Hook Strategy",
        "desc": "Iterative video scripts, UGC concepts, and static ads engineered to stop scrolling in the first 3 seconds."
      },
      {
        "title": "Full-Funnel Campaign Architecture",
        "desc": "Top-of-funnel brand introduction, middle-of-funnel objection handling, and bottom-of-funnel retargeting."
      },
      {
        "title": "Conversions API (CAPI) Integration",
        "desc": "Server-side Conversions API integration to recover lost data and improve machine learning accuracy."
      },
      {
        "title": "Audience Research & Lookalikes",
        "desc": "First-party customer list modeling, dynamic custom audiences, and high-affinity interest targeting."
      },
      {
        "title": "Ad Creative Refresh & Fatigue Prevention",
        "desc": "Weekly rotation of creative variations to maintain high CTRs and protect your account from ad fatigue."
      },
      {
        "title": "Detailed ROAS & Cost-Per-Acquisition Reporting",
        "desc": "Transparent reporting showing exact spend, cost per lead, return on ad spend, and net acquisition cost."
      }
    ],
    "faqs": [
      {
        "q": "Why are Meta Ads effective for B2B as well as B2C?",
        "a": "Decision-makers use Instagram and Facebook during their downtime. Strategic problem-focused video ads capture their attention outside stressful work hours."
      },
      {
        "q": "Do you design the ad graphics and edit videos?",
        "a": "Yes. Our 15-member Delhi agency includes full-time graphic designers and video editors who create custom creatives tailored to your brand."
      },
      {
        "q": "How do you combat ad fatigue on Meta?",
        "a": "We introduce new creative hooks, alternate headlines, and refresh video variations every 7 to 14 days depending on spend velocity."
      },
      {
        "q": "What is the minimum contract period?",
        "a": "We recommend a minimum 3-month engagement to allow proper machine learning testing, creative iteration, and algorithmic optimization."
      }
    ],
    "related": [
      {
        "slug": "google-ads",
        "title": "Google Ads Management"
      },
      {
        "slug": "video-editing",
        "title": "Video Editing & Motion"
      },
      {
        "slug": "social-media-marketing",
        "title": "Social Media Marketing"
      }
    ],
    "order": 3,
    "svgPath": "<path d=\"M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z\"/>",
    "shortDesc": "Creative-first Facebook & Instagram ad funnels that capture attention, combat ad fatigue, and scale revenue.",
    "metric": {
      "value": "62%",
      "label": "Lower Cost Per Acquisition"
    },
    "pillar": "Paid Media & Ads",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "lead-generation",
    "title": "Qualified Lead Generation",
    "tagline": "Predictable, Sales-Ready Pipeline for Growing B2B and High-Value B2C Brands",
    "metaDesc": "Generate high-intent sales-qualified leads with Marketing Setu Delhi. Multi-channel acquisition funnels, landing page optimization, and instant WhatsApp integration.",
    "icon": "fa-funnel-dollar",
    "category": "Performance Growth",
    "challenge": "Generating hundreds of cheap form fills is useless when leads don't answer the phone or have no budget. Businesses waste countless sales hours chasing unqualified contacts instead of closing ready buyers.",
    "deliverables": [
      {
        "title": "Ideal Customer Profile (ICP) Mapping",
        "desc": "Precise definition of target decision-makers, buying triggers, pain points, and budget qualifications."
      },
      {
        "title": "High-Converting Landing Pages",
        "desc": "Fast, distraction-free landing page architecture focused entirely on value communication and conversion."
      },
      {
        "title": "Qualifying Form Mechanisms",
        "desc": "Multi-step forms with smart qualification fields that filter out tyre-kickers and elevate lead quality."
      },
      {
        "title": "Multi-Channel Acquisition Strategy",
        "desc": "Synchronized search intent (Google), executive outreach (LinkedIn), and social disruption (Meta)."
      },
      {
        "title": "Instant Lead Notification & CRM Sync",
        "desc": "Instant WhatsApp and email alerts to your sales team with automated CRM integration."
      },
      {
        "title": "Closed-Loop Sales Feedback Loop",
        "desc": "Regular alignment meetings to analyze lead-to-close rates and refine ad targeting parameters."
      }
    ],
    "faqs": [
      {
        "q": "What makes a lead \"qualified\"?",
        "a": "A qualified lead meets your ICP criteria: they have verified contact details, an acknowledged business pain point, immediate decision authority, and an adequate budget."
      },
      {
        "q": "Can you integrate leads directly with our CRM?",
        "a": "Yes. We seamlessly connect web forms and ad leads to HubSpot, Zoho, Salesforce, Google Sheets, and automated WhatsApp notifications."
      },
      {
        "q": "How do you prevent spam submissions?",
        "a": "We employ honeypot fields, Google reCAPTCHA v3, OTP phone verification where appropriate, and server-side validation."
      },
      {
        "q": "How many leads can our business expect?",
        "a": "Volume depends on your industry, geographic market, and ad spend. During our initial consultation, we model estimated lead volume and cost per acquisition."
      }
    ],
    "related": [
      {
        "slug": "google-ads",
        "title": "Google Ads"
      },
      {
        "slug": "linkedin-marketing",
        "title": "LinkedIn Marketing"
      },
      {
        "slug": "conversion-rate-optimization",
        "title": "Conversion Rate Optimization"
      }
    ],
    "order": 4,
    "svgPath": "<polygon points=\"22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3\"/><path d=\"m12 11 3-3\"/>",
    "shortDesc": "Predictable sales-qualified pipelines for B2B and high-ticket B2C brands via verified multi-touch funnels.",
    "metric": {
      "value": "3.5x",
      "label": "Sales-Ready Leads"
    },
    "pillar": "Performance & Tech",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "local-seo",
    "title": "Local SEO & Google Business Profile",
    "tagline": "Capture Nearby Customers Searching for Your Services in Delhi NCR & Across India",
    "metaDesc": "Rank in Google 3-Pack and Google Maps with Local SEO services from Marketing Setu Delhi. Optimize Google Business Profile, generate reviews, and dominate local search.",
    "icon": "fa-location-dot",
    "category": "Search & Visibility",
    "challenge": "When nearby customers search for services on Google Maps and mobile search, 78% of local searches result in an offline purchase. Failing to rank in the Google 3-Pack gives local revenue directly to competitors.",
    "deliverables": [
      {
        "title": "Google Business Profile (GBP) Optimization",
        "desc": "Complete setup, primary category selection, secondary services, geo-tagged photos, and attribute curation."
      },
      {
        "title": "Local 3-Pack Ranking Strategy",
        "desc": "Hyper-local optimization strategies engineered to improve visibility in the coveted top-3 map pack."
      },
      {
        "title": "NAP Consistency & Directory Citations",
        "desc": "Consistent Name, Address, and Phone listings across high-authority Indian and global directories."
      },
      {
        "title": "Local Schema & Geo-Tagging",
        "desc": "LocalBusiness JSON-LD markup detailing exact service coordinates, operating hours, and service radius."
      },
      {
        "title": "Customer Review Generation Systems",
        "desc": "Ethical review acquisition workflows that turn satisfied customers into 5-star Google endorsements."
      },
      {
        "title": "Localized City & Neighborhood Landing Pages",
        "desc": "Dedicated service area pages built to capture specific neighborhood and regional search intent."
      }
    ],
    "faqs": [
      {
        "q": "Why is Google Business Profile so important for local companies?",
        "a": "GBP listings appear above standard search results on mobile devices. It is the primary way local customers find phone numbers, directions, and customer ratings."
      },
      {
        "q": "How long does it take to rank in Google Maps?",
        "a": "Most businesses observe meaningful local ranking improvements within 45 to 90 days after verifying and optimizing their profile."
      },
      {
        "q": "Can you help remove fake negative reviews?",
        "a": "While Google does not allow agencies to delete legitimate reviews, we help you dispute policy-violating reviews and implement systems to drown negatives with genuine 5-star feedback."
      },
      {
        "q": "Do you manage multiple branch locations?",
        "a": "Yes. We manage multi-location local SEO architectures for growing franchises and retail chains across India."
      }
    ],
    "related": [
      {
        "slug": "seo",
        "title": "Search Engine Optimization"
      },
      {
        "slug": "website-design",
        "title": "Website Design"
      },
      {
        "slug": "google-ads",
        "title": "Google Ads"
      }
    ],
    "order": 5,
    "svgPath": "<path d=\"M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z\"/><circle cx=\"12\" cy=\"10\" r=\"3\"/>",
    "shortDesc": "Google Business Profile dominance and local map pack rankings for businesses targeting Delhi-NCR and regional markets.",
    "metric": {
      "value": "Top 3",
      "label": "Local Map Pack Focus"
    },
    "pillar": "Search & Discovery",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "technical-seo",
    "title": "Technical SEO & Core Web Vitals",
    "tagline": "Speed, Crawlability, and Architecture Built to Withstand Every Algorithm Update",
    "metaDesc": "Eliminate crawl errors, speed up load times, and achieve perfect Core Web Vitals with technical SEO consulting by Marketing Setu Delhi.",
    "icon": "fa-code",
    "category": "Search & Visibility",
    "challenge": "Search engine crawlers have finite render budgets. Bloated code, unoptimized images, render-blocking scripts, and server latency prevent Googlebot from properly evaluating your pages, dragging down organic rankings.",
    "deliverables": [
      {
        "title": "Core Web Vitals Remediation",
        "desc": "Optimizing Largest Contentful Paint (LCP), Interaction to Next Paint (INP), and Cumulative Layout Shift (CLS)."
      },
      {
        "title": "Crawl Budget & Indexing Optimization",
        "desc": "XML sitemap hierarchy, robots.txt directives, canonical tag auditing, and 404/redirect chain elimination."
      },
      {
        "title": "Mobile-First Architecture",
        "desc": "Responsive viewport auditing and touch target accessibility ensuring seamless mobile experiences."
      },
      {
        "title": "Advanced Schema Implementation",
        "desc": "Rich structured data (Organization, LocalBusiness, FAQPage, BreadcrumbList, Service) for rich snippets."
      },
      {
        "title": "Site Speed & Asset Optimization",
        "desc": "Next-gen WebP/AVIF image compression, CSS/JS minification, and browser caching configurations."
      },
      {
        "title": "Log File Analysis & Bot Tracking",
        "desc": "Direct analysis of server log files to evaluate search crawler behavior and frequency."
      }
    ],
    "faqs": [
      {
        "q": "What are Core Web Vitals?",
        "a": "Core Web Vitals are Google's standardized metrics measuring real-world user experience: loading speed (LCP), responsiveness (INP), and visual stability (CLS)."
      },
      {
        "q": "How does site speed affect conversion rates?",
        "a": "Every 1-second delay in page load time can reduce conversions by up to 7%. Faster websites keep visitors engaged and reduce bounce rates."
      },
      {
        "q": "Do you work directly on our website's code?",
        "a": "Yes. Our developers and technical SEO leads directly remediate code or provide step-by-step guidance to your development team."
      },
      {
        "q": "Can technical SEO fix indexing issues?",
        "a": "Yes. Technical SEO specifically diagnoses why Google is failing to crawl or index specific URLs and resolves canonical or robots conflicts."
      }
    ],
    "related": [
      {
        "slug": "seo",
        "title": "Search Engine Optimization"
      },
      {
        "slug": "aeo",
        "title": "Answer Engine Optimization"
      },
      {
        "slug": "website-design",
        "title": "Website Development"
      }
    ],
    "order": 6,
    "svgPath": "<polyline points=\"16 18 22 12 16 6\"/><polyline points=\"8 6 2 12 8 18\"/><line x1=\"14\" y1=\"4\" x2=\"10\" y2=\"20\"/>",
    "shortDesc": "Core Web Vitals acceleration, semantic schema architecture, crawl budget tuning, and clean indexing.",
    "metric": {
      "value": "95+",
      "label": "Core Web Vitals Score"
    },
    "pillar": "Search & Discovery",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "aeo",
    "title": "Answer Engine Optimization (AEO)",
    "tagline": "Get Cited as the Direct Answer in Perplexity, Google AI Overviews, and Voice Search",
    "metaDesc": "Optimize your brand for AI search engines. Marketing Setu Delhi helps businesses secure citations in Google AI Overviews, Perplexity, and voice queries.",
    "icon": "fa-robot",
    "category": "AI & Future Search",
    "challenge": "Traditional SEO targets blue links, but AI search engines summarize answers directly on screen. Brands that do not optimize for direct answer extraction are disappearing from the modern discovery journey.",
    "deliverables": [
      {
        "title": "Question & Answer Architecture",
        "desc": "Structuring content into direct, highly quotable 40-50 word answer modules beneath explicit questions."
      },
      {
        "title": "FAQ & QAPage Schema Markup",
        "desc": "Machine-readable JSON-LD markup that enables AI agents to parse your exact answers instantly."
      },
      {
        "title": "Conversational Query Research",
        "desc": "Targeting natural language prompts and long-tail conversational questions used in voice and AI search."
      },
      {
        "title": "Entity Authority Alignment",
        "desc": "Reinforcing brand entity signals across the web so AI models view your domain as a primary authority."
      },
      {
        "title": "Featured Snippet Capture",
        "desc": "Formatting definition boxes, tables, and ordered lists to win Position Zero on Google SERPs."
      },
      {
        "title": "Continuous AI Citation Monitoring",
        "desc": "Tracking brand appearances across Perplexity, ChatGPT Search, and Google AI Overviews."
      }
    ],
    "faqs": [
      {
        "q": "What is Answer Engine Optimization (AEO)?",
        "a": "AEO is the practice of optimizing web content specifically for conversational search engines and AI assistants that deliver direct answers rather than a list of blue links."
      },
      {
        "q": "How is AEO different from standard SEO?",
        "a": "Standard SEO focuses on keywords and clicks; AEO focuses on concise semantic clarity, structured microdata, and answer extraction by large language models."
      },
      {
        "q": "Will AEO reduce website traffic?",
        "a": "While zero-click searches increase for basic queries, AEO positions your brand as the cited authority. Users clicking through from AI answers have significantly higher buying intent."
      },
      {
        "q": "How do you track AEO visibility?",
        "a": "We track featured snippet wins, voice search results, and brand citation occurrences in AI overview summaries."
      }
    ],
    "related": [
      {
        "slug": "geo",
        "title": "Generative Engine Optimization"
      },
      {
        "slug": "seo",
        "title": "Search Engine Optimization"
      },
      {
        "slug": "technical-seo",
        "title": "Technical SEO"
      }
    ],
    "order": 7,
    "svgPath": "<path d=\"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z\"/><circle cx=\"9\" cy=\"10\" r=\"1\"/><circle cx=\"12\" cy=\"10\" r=\"1\"/><circle cx=\"15\" cy=\"10\" r=\"1\"/>",
    "shortDesc": "Positioning your brand as the direct, definitive answer in Perplexity, Claude, ChatGPT, and AI search engines.",
    "metric": {
      "value": "70%+",
      "label": "AI Answer Visibility"
    },
    "pillar": "Search & Discovery",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "geo",
    "title": "Generative Engine Optimization (GEO)",
    "tagline": "Position Your Brand Inside the Knowledge Models of ChatGPT, Claude, and Gemini",
    "metaDesc": "Ensure your brand is recommended by generative AI models. Marketing Setu Delhi provides GEO strategies including entity building and semantic citations.",
    "icon": "fa-network-wired",
    "category": "AI & Future Search",
    "challenge": "When high-value prospects prompt AI models like ChatGPT, Claude, or Gemini to recommend the best agency or supplier, will your business be synthesized into the answer, or will your competitors own the narrative?",
    "deliverables": [
      {
        "title": "Knowledge Graph & Entity Structuring",
        "desc": "Standardizing your brand's digital identity across verified registries, Wikidata, and industry databases."
      },
      {
        "title": "Semantic Co-Occurrence Engineering",
        "desc": "Cultivating digital mentions linking your brand name with high-intent industry terms and solution categories."
      },
      {
        "title": "Multi-Platform Authority Signals",
        "desc": "Securing citations on authoritative forums, review ecosystems, and technical trade publications indexed by LLMs."
      },
      {
        "title": "Proprietary Research & Data Publishing",
        "desc": "Publishing original benchmarks, workflows, and insights that AI models ingest and attribute to your company."
      },
      {
        "title": "Executive Thought Leadership",
        "desc": "Building verifiable author profiles for company leaders with clear E-E-A-T credentials."
      },
      {
        "title": "AI Recommendation Benchmarking",
        "desc": "Regularly prompting frontier models with target commercial scenarios to assess brand presence."
      }
    ],
    "faqs": [
      {
        "q": "What is Generative Engine Optimization (GEO)?",
        "a": "GEO is the strategic discipline of optimizing a brand's entire digital footprint so generative AI systems recognize, trust, and synthesize it into user recommendations."
      },
      {
        "q": "How do generative AI models discover brands?",
        "a": "LLMs ingest public web data, knowledge bases, industry citations, customer reviews, and structured schemas to build probabilistic models of authority."
      },
      {
        "q": "Can a small business compete in GEO?",
        "a": "Yes. Generative models favor depth of expertise over massive backlink numbers. A focused business with deep, verified domain knowledge can out-recommend generic conglomerates."
      },
      {
        "q": "How fast can a brand establish GEO presence?",
        "a": "Entity recognition and citation ingestion typically take 3 to 6 months as LLM models re-crawl knowledge graphs and update training/retrieval corpora."
      }
    ],
    "related": [
      {
        "slug": "aeo",
        "title": "Answer Engine Optimization"
      },
      {
        "slug": "seo",
        "title": "Search Engine Optimization"
      },
      {
        "slug": "branding",
        "title": "Branding Strategy"
      }
    ],
    "order": 8,
    "svgPath": "<path d=\"m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3Z\"/>",
    "shortDesc": "Generative Engine Optimization engineered to get your brand cited inside Google AI Overviews and LLM summaries.",
    "metric": {
      "value": "3.8x",
      "label": "LLM Brand Mentions"
    },
    "pillar": "Search & Discovery",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "content-marketing",
    "title": "Content Marketing & Authority Strategy",
    "tagline": "High-Impact Articles, Case Studies, and Thought Leadership That Build Trust and Pipeline",
    "metaDesc": "Drive inbound leads with content marketing by Marketing Setu Delhi. High-value blogs, whitepapers, case studies, and editorial content engineered for conversion.",
    "icon": "fa-pen-nib",
    "category": "Content & Creative",
    "challenge": "Publishing generic, low-effort blog posts that nobody reads wastes time and diminishes brand trust. Effective content marketing must solve acute customer problems, showcase authentic expertise, and gently guide readers toward conversion.",
    "deliverables": [
      {
        "title": "Editorial Strategy & Content Calendar",
        "desc": "Research-backed content plan targeting top, middle, and bottom of the sales funnel."
      },
      {
        "title": "Authoritative Long-Form Articles",
        "desc": "In-depth, well-researched articles written by industry practitioners, not generic AI spinners."
      },
      {
        "title": "Customer Case Studies & Success Stories",
        "desc": "Compelling narrative breakdowns of client transformations, challenges, and measurable results."
      },
      {
        "title": "E-Books & Lead Magnets",
        "desc": "Downloadable checklists, guides, and templates designed to capture qualified inbound prospect information."
      },
      {
        "title": "Content Repurposing Framework",
        "desc": "Transforming one master article into LinkedIn posts, Twitter threads, video scripts, and newsletter editions."
      },
      {
        "title": "SEO & Conversion Integration",
        "desc": "Seamlessly weaving internal links, callouts, and conversion CTAs throughout every content piece."
      }
    ],
    "faqs": [
      {
        "q": "How does content marketing generate sales?",
        "a": "Quality content answers customer objections before they ever speak to sales, establishing trust and positioning your brand as the undisputed authority in your field."
      },
      {
        "q": "Do you use AI to write articles?",
        "a": "We use AI for outline brainstorming and research, but every article is drafted, refined, and fact-checked by human copywriters and subject-matter practitioners."
      },
      {
        "q": "How often should our company publish content?",
        "a": "Quality consistently trumps quantity. For most businesses, 2 to 4 thoroughly researched, authoritative articles per month deliver superior compounding results."
      },
      {
        "q": "Do you distribute the content after writing?",
        "a": "Yes. We distribute articles across social media channels, email newsletters, and relevant industry communities."
      }
    ],
    "related": [
      {
        "slug": "seo",
        "title": "Search Engine Optimization"
      },
      {
        "slug": "social-media-marketing",
        "title": "Social Media Marketing"
      },
      {
        "slug": "lead-generation",
        "title": "Lead Generation"
      }
    ],
    "order": 9,
    "svgPath": "<path d=\"M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5Z\"/><path d=\"M6 6h10M6 10h10M6 14h6\"/>",
    "shortDesc": "Authoritative pillar articles, thought leadership, and strategic assets that build enduring organic equity.",
    "metric": {
      "value": "180%",
      "label": "Long-Tail Traffic Boost"
    },
    "pillar": "Creative & Brand",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "graphic-design",
    "title": "Graphic Designing & Visual Identity",
    "tagline": "Stunning Visual Assets That Elevate Your Brand and Drive Marketing Engagement",
    "metaDesc": "Elevate your brand with custom graphic design by Marketing Setu Delhi. Social media creatives, marketing collaterals, digital banners, and brand style guides.",
    "icon": "fa-palette",
    "category": "Content & Creative",
    "challenge": "Amateur, inconsistent graphics erode trust and cause potential buyers to perceive your business as low quality. Clean, intentional visual design conveys enterprise credibility and commands premium pricing.",
    "deliverables": [
      {
        "title": "Brand Style Guide & Design Systems",
        "desc": "Harmonious color palettes, typographic hierarchies, logo guidelines, and icon sets."
      },
      {
        "title": "High-Converting Ad Creatives",
        "desc": "Click-tested social media ad banners and carousel graphics tailored for Facebook, Instagram, and LinkedIn."
      },
      {
        "title": "Social Media Post Templates",
        "desc": "Reusable, on-brand templates that maintain visual consistency across all social channels."
      },
      {
        "title": "Corporate Collateral Design",
        "desc": "Professional pitch decks, company brochures, service flyers, and business stationery."
      },
      {
        "title": "Website & Landing Page UI Graphics",
        "desc": "Custom vector illustrations, feature icons, and visual UI components tailored for your website."
      },
      {
        "title": "Infographics & Data Visualizations",
        "desc": "Complex technical concepts distilled into engaging, easily shareable visual diagrams."
      }
    ],
    "faqs": [
      {
        "q": "What software do your designers use?",
        "a": "Our creative team works with industry-standard tools including Adobe Creative Cloud (Illustrator, Photoshop, InDesign) and Figma."
      },
      {
        "q": "Do we get source files for the designs?",
        "a": "Yes. All completed designs include open vector source files (AI, PSD, SVG) along with high-res PNG/JPG exports."
      },
      {
        "q": "How many revisions are included?",
        "a": "We work closely with your feedback and include iterative revision rounds until you are 100% satisfied with the creative direction."
      },
      {
        "q": "Can you match our existing brand guidelines?",
        "a": "Absolutely. We meticulously follow your existing brand guidelines, fonts, and hex codes to ensure complete visual continuity."
      }
    ],
    "related": [
      {
        "slug": "branding",
        "title": "Branding & Strategy"
      },
      {
        "slug": "video-editing",
        "title": "Video Editing"
      },
      {
        "slug": "website-design",
        "title": "Website Design"
      }
    ],
    "order": 10,
    "svgPath": "<path d=\"m12 19 7-7 3 3-7 7-3-3z\"/><path d=\"m18 13-1.5-7.5L2 2l3.5 14.5L13 18l5-5z\"/><path d=\"m2 2 7.586 7.586\"/><circle cx=\"11\" cy=\"11\" r=\"2\"/>",
    "shortDesc": "Awwwards-inspired visual branding, social assets, presentation decks, and high-impact commercial design.",
    "metric": {
      "value": "100%",
      "label": "Bespoke Brand Assets"
    },
    "pillar": "Creative & Brand",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "video-editing",
    "title": "Video Editing & Short-Form Motion Design",
    "tagline": "High-Retention Video Content Engineered for Reels, YouTube, and Paid Ads",
    "metaDesc": "Professional video editing services in Delhi by Marketing Setu. Short-form Reels, YouTube video production, motion graphics, and high-converting video ads.",
    "icon": "fa-video",
    "category": "Content & Creative",
    "challenge": "Video is the primary consumer medium across all major platforms, but poorly paced videos with flat audio, weak hooks, and boring captions lose 80% of viewers in the first 5 seconds.",
    "deliverables": [
      {
        "title": "Short-Form Reels & Shorts Editing",
        "desc": "Fast-paced, hook-optimized vertical videos featuring animated captions, sound effects, and B-roll."
      },
      {
        "title": "High-Converting Paid Video Ads",
        "desc": "Direct-response video advertisements structured with strong hooks, problem demonstrations, and clear CTAs."
      },
      {
        "title": "Corporate & Brand Videos",
        "desc": "Polished brand overviews, executive interviews, and facility tours tailored for corporate authority."
      },
      {
        "title": "Product Demos & Motion Graphics",
        "desc": "2D/3D motion graphics and explainer animations illustrating software workflows or product features."
      },
      {
        "title": "Dynamic Kinetic Typography",
        "desc": "Attention-grabbing animated text and subtitle styling ensuring full comprehension even with sound muted."
      },
      {
        "title": "Sound Design & Color Grading",
        "desc": "Professional color grading, audio leveling, background scoring, and atmospheric sound design."
      }
    ],
    "faqs": [
      {
        "q": "Do we need to record raw footage ourselves?",
        "a": "You can provide raw footage recorded on your phone or camera, or we can assist with scriptwriting, storyboarding, and video production guidance."
      },
      {
        "q": "What is the turnaround time for a batch of Reels?",
        "a": "Standard turnaround for a batch of 5 to 10 short-form videos is 3 to 5 business days after receiving raw assets and scripts."
      },
      {
        "q": "Do you create captions and animated subtitles?",
        "a": "Yes. Over 70% of social media users watch videos with sound off; our animated captions ensure high retention regardless of sound settings."
      },
      {
        "q": "What formats do you deliver?",
        "a": "We deliver optimized MP4 files in 9:16 (vertical for Reels/Shorts), 16:9 (horizontal for YouTube), and 1:1 (square for feeds)."
      }
    ],
    "related": [
      {
        "slug": "graphic-design",
        "title": "Graphic Design"
      },
      {
        "slug": "social-media-marketing",
        "title": "Social Media Marketing"
      },
      {
        "slug": "meta-ads",
        "title": "Meta Ads"
      }
    ],
    "order": 11,
    "svgPath": "<rect width=\"18\" height=\"18\" x=\"3\" y=\"3\" rx=\"2\"/><path d=\"m10 8 6 4-6 4V8z\"/>",
    "shortDesc": "Thumb-stopping short-form reels, product motion, and brand videos edited for maximum retention and clicks.",
    "metric": {
      "value": "4.2x",
      "label": "Video Engagement"
    },
    "pillar": "Creative & Brand",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "branding",
    "title": "Branding & Creative Strategy",
    "tagline": "Shape a Distinctive Brand Identity That Resonates, Inspires, and Commands Authority",
    "metaDesc": "Build an unforgettable brand with Marketing Setu Delhi. Brand positioning, naming, logo design, messaging frameworks, and comprehensive brand identity guides.",
    "icon": "fa-compass-drafting",
    "category": "Brand Strategy",
    "challenge": "Without a clear brand identity and positioning, your business is forced to compete on price alone. Authentic branding clarifies why you matter, who you serve, and why customers should choose you over alternatives.",
    "deliverables": [
      {
        "title": "Brand Positioning & Value Proposition",
        "desc": "Articulating your unique market positioning, customer promise, and competitive differentiator."
      },
      {
        "title": "Logo Design & Visual Identity",
        "desc": "Distinctive, timeless logo design and visual marks with versatile lockups for digital and print."
      },
      {
        "title": "Color Psychology & Typography",
        "desc": "Cohesive color systems and font pairings chosen for emotional resonance and digital readability."
      },
      {
        "title": "Tone of Voice & Messaging Architecture",
        "desc": "Standardized messaging guidelines, elevator pitches, and brand storytelling rules."
      },
      {
        "title": "Comprehensive Brand Guidelines",
        "desc": "A master brand book detailing clear do’s and don’ts to preserve brand consistency across all marketing."
      },
      {
        "title": "Brand Collateral & Stationery Kits",
        "desc": "Business cards, letterheads, email signatures, presentation templates, and branded packaging."
      }
    ],
    "faqs": [
      {
        "q": "What is the difference between a logo and branding?",
        "a": "A logo is simply a graphic symbol. Branding is the entire emotional and intellectual perception of your business — including your voice, values, design, and customer experience."
      },
      {
        "q": "Can you rebrand an existing business without losing recognition?",
        "a": "Yes. We specialize in brand evolution — modernizing visual assets and sharpening messaging while preserving the goodwill and trust you have built over years."
      },
      {
        "q": "How long does a full branding project take?",
        "a": "A complete branding engagement typically takes 3 to 6 weeks from initial discovery workshops to final brand book delivery."
      },
      {
        "q": "What do we receive at the end of the project?",
        "a": "You receive full ownership of all vector source files, ready-to-use digital assets, and an exhaustive Brand Identity Guidelines PDF."
      }
    ],
    "related": [
      {
        "slug": "graphic-design",
        "title": "Graphic Design"
      },
      {
        "slug": "website-design",
        "title": "Website Design"
      },
      {
        "slug": "content-marketing",
        "title": "Content Marketing"
      }
    ],
    "order": 12,
    "svgPath": "<path d=\"M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6\"/>",
    "shortDesc": "Complete brand identity systems, typography, color architecture, and strategic market positioning.",
    "metric": {
      "value": "360�",
      "label": "Cohesive Visual Identity"
    },
    "pillar": "Creative & Brand",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "social-media-marketing",
    "title": "Social Media Marketing (SMM)",
    "tagline": "Build an Active, Engaged Community and Turn Followers into Brand Advocates",
    "metaDesc": "Strategic social media management in Delhi by Marketing Setu. Content creation, community engagement, scheduling, and growth across Instagram, LinkedIn, and YouTube.",
    "icon": "fa-share-nodes",
    "category": "Content & Creative",
    "challenge": "Social media algorithms change constantly. Inconsistent posting, low-effort graphics, and lack of community engagement leave your brand invisible in an overcrowded social media landscape.",
    "deliverables": [
      {
        "title": "Comprehensive Channel Strategy",
        "desc": "Auditing your existing profiles and crafting a focused content plan tailored to your target audience."
      },
      {
        "title": "Content Creation & Design",
        "desc": "Creating engaging carousels, infographics, short-form Reels, and conversational text posts."
      },
      {
        "title": "Editorial Scheduling & Publishing",
        "desc": "Reliable publishing at peak engagement hours across Instagram, LinkedIn, Facebook, and X."
      },
      {
        "title": "Community Management & Interaction",
        "desc": "Responding to comments, engaging with industry peers, and directing inbound DM inquiries to sales."
      },
      {
        "title": "Hashtag & Trend Optimization",
        "desc": "Leveraging relevant industry conversations and trending formats to amplify organic reach."
      },
      {
        "title": "Monthly Growth & Sentiment Analytics",
        "desc": "Transparent reporting on follower growth, engagement rates, click-throughs, and audience demographics."
      }
    ],
    "faqs": [
      {
        "q": "Which social media platforms should my business be on?",
        "a": "We evaluate your industry and audience. Typically, B2B companies prioritize LinkedIn and YouTube, while lifestyle, retail, and local services thrive on Instagram and Meta."
      },
      {
        "q": "Do you guarantee follower growth?",
        "a": "We focus on acquiring relevant, engaged followers who actually match your customer profile, rather than purchasing dead bot accounts that ruin algorithm reach."
      },
      {
        "q": "Who approves the posts before they go live?",
        "a": "You do. We present monthly or bi-weekly content calendars for your review and approval before scheduling."
      },
      {
        "q": "Can social media marketing generate direct sales?",
        "a": "Yes. When combined with educational content, social proof, and clear conversion paths, social media acts as a powerful inbound sales channel."
      }
    ],
    "related": [
      {
        "slug": "video-editing",
        "title": "Video Editing"
      },
      {
        "slug": "linkedin-marketing",
        "title": "LinkedIn Marketing"
      },
      {
        "slug": "meta-ads",
        "title": "Meta Ads"
      }
    ],
    "order": 13,
    "svgPath": "<path d=\"M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z\"/><rect width=\"4\" height=\"12\" x=\"2\" y=\"9\"/><circle cx=\"4\" cy=\"4\" r=\"2\"/>",
    "shortDesc": "Organic community building, viral distribution, and brand resonance across Instagram, YouTube, and LinkedIn.",
    "metric": {
      "value": "5.2x",
      "label": "Audience Growth Rate"
    },
    "pillar": "Creative & Brand",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "linkedin-marketing",
    "title": "LinkedIn B2B Marketing & Thought Leadership",
    "tagline": "Connect Directly with CXOs, Founders, and Decision-Makers in Your Target Market",
    "metaDesc": "Generate B2B pipeline on LinkedIn with Marketing Setu Delhi. Executive ghostwriting, company page management, and targeted LinkedIn Sponsored Ads.",
    "icon": "fa-brands fa-linkedin",
    "category": "Performance Growth",
    "challenge": "B2B decision-makers ignore generic corporate spam. Winning on LinkedIn requires genuine executive perspective, insightful industry commentary, and precision-targeted commercial outreach.",
    "deliverables": [
      {
        "title": "Executive Profile Optimization",
        "desc": "Transforming founder and executive profiles into client-attracting landing pages with compelling headlines."
      },
      {
        "title": "Executive Thought Leadership Ghostwriting",
        "desc": "Drafting high-engagement text posts, document carousels, and case studies reflecting your true voice."
      },
      {
        "title": "Company Page Strategy & Management",
        "desc": "Positioning your corporate page as a hub of industry innovation, team culture, and hiring excellence."
      },
      {
        "title": "LinkedIn Sponsored Content & Message Ads",
        "desc": "Hyper-targeted B2B advertising segmented by job title, company size, seniority, and industry."
      },
      {
        "title": "B2B Inbound Lead Funneling",
        "desc": "Converting post engagement and profile visits into meaningful direct-message conversations."
      },
      {
        "title": "Account-Based Marketing (ABM) Alignment",
        "desc": "Coordinating LinkedIn outreach with specific target account lists to support your enterprise sales team."
      }
    ],
    "faqs": [
      {
        "q": "Why is LinkedIn critical for B2B brands?",
        "a": "LinkedIn is the only social network where professionals actively share business challenges and evaluate vendors. 80% of B2B social leads come from LinkedIn."
      },
      {
        "q": "How does executive ghostwriting work?",
        "a": "We conduct short interviews with your leadership team to capture key ideas, which our writers turn into polished, insightful posts ready for review."
      },
      {
        "q": "Are LinkedIn Ads more expensive than Meta Ads?",
        "a": "LinkedIn cost-per-click is higher, but the lead quality and targeting precision for specific job titles (e.g. \"Chief Technology Officer\") makes the cost-per-sale highly competitive."
      },
      {
        "q": "Can you help our sales team with social selling?",
        "a": "Yes. We share best practices for warm outbound connection requests, comment engagement, and personalized follow-ups."
      }
    ],
    "related": [
      {
        "slug": "lead-generation",
        "title": "Lead Generation"
      },
      {
        "slug": "content-marketing",
        "title": "Content Marketing"
      },
      {
        "slug": "branding",
        "title": "Branding Strategy"
      }
    ],
    "order": 14,
    "svgPath": "<rect width=\"20\" height=\"20\" x=\"2\" y=\"2\" rx=\"5\" ry=\"5\"/><path d=\"M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z\"/><line x1=\"17.5\" y1=\"6.5\" x2=\"17.51\" y2=\"6.5\"/>",
    "shortDesc": "Executive personal branding, B2B account-based marketing, and high-level decision-maker outreach.",
    "metric": {
      "value": "45%+",
      "label": "C-Suite Inbound Replies"
    },
    "pillar": "Performance & Tech",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "email-marketing",
    "title": "Email Marketing & Lifecycle Automation",
    "tagline": "Nurture Prospects, Retain Customers, and Drive Repeat Revenue on Autopilot",
    "metaDesc": "Increase customer lifetime value with email marketing automation by Marketing Setu Delhi. Newsletters, automated welcome sequences, and cart recovery workflows.",
    "icon": "fa-envelope-open-text",
    "category": "Performance Growth",
    "challenge": "Acquiring new website visitors is expensive. Without an automated email capture and nurturing system, over 95% of your traffic leaves your site and never returns, wasting your ad budget.",
    "deliverables": [
      {
        "title": "Automated Lifecycle Workflows",
        "desc": "Welcome series, lead nurturing drips, re-engagement sequences, and post-purchase follow-ups."
      },
      {
        "title": "High-Converting Newsletter Design",
        "desc": "Mobile-responsive email templates that look clean across Gmail, Apple Mail, and Outlook."
      },
      {
        "title": "Subscriber Segmentation & Personalization",
        "desc": "Segmenting your list based on buyer persona, purchase history, and engagement level."
      },
      {
        "title": "Deliverability & Domain Health",
        "desc": "Configuring SPF, DKIM, and DMARC records to ensure emails land in the primary inbox, not the spam folder."
      },
      {
        "title": "Compelling Copywriting & A/B Testing",
        "desc": "Testing subject lines, preview text, and call-to-actions to maximize open and click-through rates."
      },
      {
        "title": "Revenue & Churn Analytics",
        "desc": "Tracking revenue per recipient, unsubscribe rates, and automated lifecycle performance."
      }
    ],
    "faqs": [
      {
        "q": "What is the typical ROI of email marketing?",
        "a": "Industry studies consistently demonstrate an average return of ₹36 to ₹40 for every ₹1 invested in strategic email marketing."
      },
      {
        "q": "Which email platforms do you support?",
        "a": "We work with major platforms including Klaviyo, Mailchimp, ActiveCampaign, HubSpot, and Brevo."
      },
      {
        "q": "Do you write the email copy and design the templates?",
        "a": "Yes. We handle end-to-end execution: copy, responsive HTML design, setup, testing, and scheduling."
      },
      {
        "q": "How do you prevent emails from landing in spam?",
        "a": "We verify domain authentication (SPF, DKIM, DMARC), warm up sending IPs, prune unengaged contacts, and avoid spam-trigger language."
      }
    ],
    "related": [
      {
        "slug": "lead-generation",
        "title": "Lead Generation"
      },
      {
        "slug": "conversion-rate-optimization",
        "title": "Conversion Rate Optimization"
      },
      {
        "slug": "content-marketing",
        "title": "Content Marketing"
      }
    ],
    "order": 15,
    "svgPath": "<rect width=\"20\" height=\"16\" x=\"2\" y=\"4\" rx=\"2\"/><path d=\"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7\"/>",
    "shortDesc": "Automated customer journeys, segmentation, retention funnels, and high-deliverability email campaigns.",
    "metric": {
      "value": "38%",
      "label": "Average Open Rate"
    },
    "pillar": "Performance & Tech",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "website-design",
    "title": "Website Designing & Development",
    "tagline": "Modern, Lightning-Fast, High-Converting Websites Built for 2026 Standards",
    "metaDesc": "Custom website design and development services in Delhi by Marketing Setu. Fast, mobile-first, SEO-ready agency and corporate websites that convert visitors.",
    "icon": "fa-laptop-code",
    "category": "Web & Tech",
    "challenge": "A slow, cluttered, or outdated website immediately damages brand credibility. If your site takes more than 3 seconds to load or fails on mobile devices, you lose over 50% of your potential customers.",
    "deliverables": [
      {
        "title": "Custom UI/UX Wireframing & Design",
        "desc": "Tailored Figma designs engineered for visual elegance, clear visual hierarchy, and effortless navigation."
      },
      {
        "title": "Mobile-First Responsive Engineering",
        "desc": "Flawless performance across all screen sizes: desktop, tablet, and mobile smartphones."
      },
      {
        "title": "Sub-Second Loading Speeds",
        "desc": "Clean, lightweight code adhering strictly to modern Core Web Vitals performance standards."
      },
      {
        "title": "Built-in Technical SEO & Schema",
        "desc": "Semantic HTML5 structure, structured JSON-LD schemas, and pre-configured metadata."
      },
      {
        "title": "CMS Flexibility & Easy Content Updates",
        "desc": "Easy-to-manage content architectures enabling your team to publish updates without code knowledge."
      },
      {
        "title": "Enterprise Security & SSL Configuration",
        "desc": "Secure headers, anti-spam form protections, and HTTPS encryption out of the box."
      }
    ],
    "faqs": [
      {
        "q": "How long does it take to design and launch a new website?",
        "a": "A standard custom website takes 3 to 6 weeks depending on page count, custom functionality, and revision feedback cycles."
      },
      {
        "q": "Will our website work smoothly on all mobile devices?",
        "a": "Yes. Every website we build is rigorously tested across iOS and Android devices for touch responsiveness and visual stability."
      },
      {
        "q": "Can we edit text and images ourselves after launch?",
        "a": "Yes. We provide complete walkthroughs and build intuitive CMS backends so your team can make updates easily."
      },
      {
        "q": "Is the website optimized for Google search out of the box?",
        "a": "Yes. All our websites are built with semantic HTML5, Core Web Vitals optimization, and structured schema markup."
      }
    ],
    "related": [
      {
        "slug": "app-design",
        "title": "App UI/UX Design"
      },
      {
        "slug": "seo",
        "title": "Search Engine Optimization"
      },
      {
        "slug": "conversion-rate-optimization",
        "title": "Conversion Rate Optimization"
      }
    ],
    "order": 16,
    "svgPath": "<rect width=\"20\" height=\"14\" x=\"2\" y=\"3\" rx=\"2\"/><line x1=\"8\" y1=\"21\" x2=\"16\" y2=\"21\"/><line x1=\"12\" y1=\"17\" x2=\"12\" y2=\"21\"/>",
    "shortDesc": "Fast, bespoke, award-caliber websites built for conversion, performance, and memorable brand prestige.",
    "metric": {
      "value": "<1.2s",
      "label": "Lightning Page Load"
    },
    "pillar": "Performance & Tech",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "app-design",
    "title": "App UI/UX Designing & Prototyping",
    "tagline": "Intuitive, Engaging Mobile & Web Application Interfaces Users Love to Use",
    "metaDesc": "Award-winning App UI/UX design services in Delhi by Marketing Setu. User journey mapping, interactive Figma prototypes, and scalable design systems.",
    "icon": "fa-mobile-screen-button",
    "category": "Web & Tech",
    "challenge": "Confusing user flows and cluttered interfaces lead to high user abandonment and negative app store reviews. Great product design bridges user psychology with seamless business functionality.",
    "deliverables": [
      {
        "title": "User Research & Journey Mapping",
        "desc": "In-depth analysis of user personas, core tasks, pain points, and conversion pathways."
      },
      {
        "title": "Low-Fidelity Wireframes",
        "desc": "Rapid architectural wireframing to establish intuitive navigation hierarchies before visual styling."
      },
      {
        "title": "High-Fidelity Interactive Prototypes",
        "desc": "Clickable Figma prototypes simulating exact app interactions, transitions, and micro-animations."
      },
      {
        "title": "Comprehensive Design Systems",
        "desc": "Atomic design tokens, reusable UI components, typography standards, and color modes (Light & Dark)."
      },
      {
        "title": "Usability Testing & Iteration",
        "desc": "Real-world usability sessions identifying friction points and refining user flows."
      },
      {
        "title": "Developer Handoff Specifications",
        "desc": "Pixel-perfect CSS specs, exported SVG assets, and design token documentation for engineering teams."
      }
    ],
    "faqs": [
      {
        "q": "What design deliverables do we receive?",
        "a": "You receive complete Figma source files, clickable prototypes, an atomic design system, and developer-ready asset exports."
      },
      {
        "q": "Do you also develop mobile apps?",
        "a": "Our primary focus is UI/UX product design and web engineering. We collaborate seamlessly with your app developers or trusted engineering partners."
      },
      {
        "q": "Do you design for both iOS and Android?",
        "a": "Yes. We follow Apple Human Interface Guidelines (HIG) and Google Material Design 3 standards for platform-native experiences."
      },
      {
        "q": "Can you redesign our existing app to improve retention?",
        "a": "Yes. We conduct UX audits of existing applications to pinpoint churn causes and redesign high-friction workflows."
      }
    ],
    "related": [
      {
        "slug": "website-design",
        "title": "Website Design"
      },
      {
        "slug": "conversion-rate-optimization",
        "title": "Conversion Rate Optimization"
      },
      {
        "slug": "graphic-design",
        "title": "Graphic Design"
      }
    ],
    "order": 17,
    "svgPath": "<rect width=\"14\" height=\"20\" x=\"5\" y=\"2\" rx=\"3\"/><line x1=\"12\" y1=\"18\" x2=\"12.01\" y2=\"18\"/>",
    "shortDesc": "Frictionless mobile and web UI/UX prototypes designed for high user engagement and seamless onboarding.",
    "metric": {
      "value": "4.9?",
      "label": "User Flow Satisfaction"
    },
    "pillar": "Performance & Tech",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "conversion-rate-optimization",
    "title": "Conversion Rate Optimization (CRO)",
    "tagline": "Turn More of Your Existing Website Traffic into Paying Customers Without Increasing Ad Spend",
    "metaDesc": "Double your website conversions with CRO services from Marketing Setu Delhi. Heatmap analysis, A/B split testing, UX audits, and friction elimination.",
    "icon": "fa-chart-pie",
    "category": "Performance Growth",
    "challenge": "Pouring more money into ads when your website converts at only 1% is like filling a leaky bucket. Doubling your conversion rate from 1% to 2% cuts your customer acquisition cost in half instantly.",
    "deliverables": [
      {
        "title": "User Behavior & Heatmap Analysis",
        "desc": "Tracking user scrolls, rage clicks, and drop-off points using modern behavioral analytics tools."
      },
      {
        "title": "Heuristic UX & Conversion Audits",
        "desc": "Expert evaluation of cognitive load, visual friction, value clarity, and checkout complexity."
      },
      {
        "title": "Hypothesis-Driven A/B Testing",
        "desc": "Designing and executing statistical split tests on headlines, CTAs, forms, and layout structures."
      },
      {
        "title": "Frictionless Form Redesign",
        "desc": "Streamlining input fields, adding smart defaults, and introducing real-time field validation."
      },
      {
        "title": "Social Proof & Trust Architecture",
        "desc": "Strategic placement of verified customer reviews, guarantees, and security certifications at critical decision points."
      },
      {
        "title": "Continuous Conversion Uplift Reporting",
        "desc": "Data-driven monthly reporting quantifying conversion rate improvements, revenue lift, and test results."
      }
    ],
    "faqs": [
      {
        "q": "What is Conversion Rate Optimization (CRO)?",
        "a": "CRO is the systematic process of increasing the percentage of website visitors who take a desired action (purchasing, filling a form, calling)."
      },
      {
        "q": "How much traffic do we need for CRO testing?",
        "a": "While formal A/B split testing requires consistent traffic, qualitative UX audits and friction elimination benefit websites of all traffic levels immediately."
      },
      {
        "q": "Can CRO lower our paid advertising costs?",
        "a": "Yes. When your website converts a higher percentage of ad clicks into paying leads, your effective Cost-Per-Acquisition (CPA) drops directly."
      },
      {
        "q": "How long does a CRO cycle take?",
        "a": "Initial heuristic fixes can be implemented in 2 weeks. Comprehensive A/B testing cycles typically run in 30-day iterative sprints."
      }
    ],
    "related": [
      {
        "slug": "lead-generation",
        "title": "Lead Generation"
      },
      {
        "slug": "website-design",
        "title": "Website Design"
      },
      {
        "slug": "google-ads",
        "title": "Google Ads"
      }
    ],
    "order": 18,
    "svgPath": "<line x1=\"12\" y1=\"20\" x2=\"12\" y2=\"10\"/><line x1=\"18\" y1=\"20\" x2=\"18\" y2=\"4\"/><line x1=\"6\" y1=\"20\" x2=\"6\" y2=\"16\"/>",
    "shortDesc": "Scientific A/B testing, heatmaps, and funnel optimization to turn existing traffic into paying clients.",
    "metric": {
      "value": "+54%",
      "label": "Checkout/Form Lift"
    },
    "pillar": "Performance & Tech",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "digital-advertising",
    "title": "Digital Advertising (Omnichannel)",
    "tagline": "Cohesive, Multi-Platform Ad Campaigns That Surround Your Target Audience Everywhere",
    "metaDesc": "Maximize market presence with omnichannel digital advertising by Marketing Setu Delhi. Search, social, native, and programmatic display unified under one strategy.",
    "icon": "fa-bullhorn",
    "category": "Paid Advertising",
    "challenge": "Running isolated ad campaigns across disconnected channels creates disjointed messaging, wasted ad spend, and conflicting attribution. Modern buyers touch multiple platforms before making a purchase.",
    "deliverables": [
      {
        "title": "Cross-Channel Audience Strategy",
        "desc": "Coordinated customer journey mapping across Search, Display, Social, and Native advertising."
      },
      {
        "title": "Unified Creative Narrative",
        "desc": "Consistent visual storytelling and compelling offers adapted specifically to each platform's native format."
      },
      {
        "title": "Programmatic & Native Placement",
        "desc": "Contextual placements on premium news portals and industry websites to build mainstream credibility."
      },
      {
        "title": "Multi-Touch Attribution Modeling",
        "desc": "Analyzing which platforms introduce, nurture, and ultimately close customers to optimize budget allocation."
      },
      {
        "title": "Centralized Budget Management",
        "desc": "Dynamically shifting spend toward the highest-performing channels based on real-time ROAS data."
      },
      {
        "title": "Holistic Executive Dashboard",
        "desc": "Single-source reporting consolidating ad spend, impressions, leads, and revenue across all networks."
      }
    ],
    "faqs": [
      {
        "q": "What does \"omnichannel\" advertising mean?",
        "a": "It means reaching your prospects cohesively across multiple touchpoints — Google Search, Instagram, YouTube, LinkedIn, and premium websites — with a synchronized message."
      },
      {
        "q": "How do you prevent budget wastage across multiple platforms?",
        "a": "We use unified frequency capping and cross-platform negative audiences to ensure the same person isn't repeatedly bombarded with duplicate ads."
      },
      {
        "q": "Can small businesses afford omnichannel campaigns?",
        "a": "Yes. We calibrate platform selection to your budget, starting with the two most lucrative channels before expanding reach."
      },
      {
        "q": "How do you measure success across different ad networks?",
        "a": "We implement server-side tracking and UTM taxonomy to measure blended Customer Acquisition Cost (CAC) and overall marketing efficiency."
      }
    ],
    "related": [
      {
        "slug": "google-ads",
        "title": "Google Ads"
      },
      {
        "slug": "meta-ads",
        "title": "Meta Ads"
      },
      {
        "slug": "paid-marketing",
        "title": "Paid Marketing"
      }
    ],
    "order": 19,
    "svgPath": "<circle cx=\"12\" cy=\"12\" r=\"10\"/><path d=\"m4.93 4.93 4.24 4.24M14.83 14.83l4.24 4.24M14.83 9.17l4.24-4.24M4.93 19.07l4.24-4.24\"/>",
    "shortDesc": "Holistic 360-degree digital media planning and cross-platform advertising across search, social, and display.",
    "metric": {
      "value": "10M+",
      "label": "Targeted Impressions"
    },
    "pillar": "Paid Media & Ads",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  },
  {
    "slug": "paid-marketing",
    "title": "Paid Marketing & PPC Campaign Management",
    "tagline": "Precision Media Buying Focused 100% on Revenue, Qualified Pipeline, and Positive ROI",
    "metaDesc": "Grow revenue predictably with paid marketing services from Marketing Setu Delhi. Data-driven PPC management across Search, Social, and Display channels.",
    "icon": "fa-money-bill-trend-up",
    "category": "Paid Advertising",
    "challenge": "Too many marketing agencies celebrate vanity metrics like impressions and clicks while business bank accounts stay empty. Paid marketing must be held accountable to real pipeline, cost per acquisition, and net revenue.",
    "deliverables": [
      {
        "title": "Commercial Economics & Target CPA Modeling",
        "desc": "Calculating allowable customer acquisition costs based on your customer lifetime value and profit margins."
      },
      {
        "title": "High-Intent Search & Shopping Campaigns",
        "desc": "Capturing ready-to-buy consumers on Google Search and Google Shopping with high-intent keywords."
      },
      {
        "title": "Precision Social Retargeting",
        "desc": "Recapturing un-converted website traffic with compelling social proof, offers, and video testimonials."
      },
      {
        "title": "Rigorous A/B Split Testing",
        "desc": "Systematic testing of headlines, value propositions, creative assets, and landing page layouts."
      },
      {
        "title": "Fraud Click Detection & Budget Protection",
        "desc": "Active monitoring and exclusion of invalid clicks, competitor scraping, and bot farm traffic."
      },
      {
        "title": "Real-Time ROI Performance Dashboard",
        "desc": "Live reporting dashboard providing complete transparency into daily ad spend, leads, and ROAS."
      }
    ],
    "faqs": [
      {
        "q": "What is the difference between PPC and organic marketing?",
        "a": "PPC provides immediate traffic and results as soon as ads launch, while organic SEO builds compounding long-term authority without paying for clicks."
      },
      {
        "q": "How do you optimize campaigns after launch?",
        "a": "We make continuous data-driven adjustments: pruning negative keywords, pausing low-performing ads, scaling high-ROAS audiences, and testing new creative angles."
      },
      {
        "q": "What is your agency management fee structure?",
        "a": "We offer straightforward, transparent retainers based on your campaign scope and ad spend, with zero hidden markups on media spend."
      },
      {
        "q": "How do we get started?",
        "a": "Schedule a free consultation. We review your existing campaigns or industry landscape and provide a transparent growth plan."
      }
    ],
    "related": [
      {
        "slug": "google-ads",
        "title": "Google Ads"
      },
      {
        "slug": "meta-ads",
        "title": "Meta Ads"
      },
      {
        "slug": "digital-advertising",
        "title": "Digital Advertising"
      }
    ],
    "order": 20,
    "svgPath": "<line x1=\"12\" y1=\"1\" x2=\"12\" y2=\"23\"/><path d=\"M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6\"/>",
    "shortDesc": "Disciplined PPC campaign management, bid optimization, and real-time conversion feedback loops.",
    "metric": {
      "value": "100%",
      "label": "Budget Efficiency"
    },
    "pillar": "Paid Media & Ads",
    "process": [
      {
        "step": "01",
        "title": "Deep Discovery & Audit",
        "desc": "Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks."
      },
      {
        "step": "02",
        "title": "Strategic Architecture",
        "desc": "Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics."
      },
      {
        "step": "03",
        "title": "Agile Execution & Launch",
        "desc": "Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets."
      },
      {
        "step": "04",
        "title": "Continuous Optimization",
        "desc": "Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting."
      }
    ]
  }
];

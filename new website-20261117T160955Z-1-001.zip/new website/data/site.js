module.exports = {
  name: 'Marketing Setu',
  legalName: 'Marketing Setu Digital Growth Agency',
  tagline: 'From Strategy to Growth',
  heroHeadline: "We Don't Just Market Brands. We Move Them Forward.",
  heroSubheadline: "Marketing Setu combines strategy, creativity, and technology to help ambitious businesses build their digital presence and accelerate growth.",
  url: 'https://marketingsetu.com',
  location: {
    city: 'Delhi',
    region: 'Delhi-NCR',
    country: 'India',
    address: 'Connaught Place & South Extension, New Delhi, Delhi 110001, India',
    geo: {
      latitude: 28.6139,
      longitude: 77.2090
    }
  },
  contacts: {
    primaryPhone: '+91 9205770757',
    primaryPhoneDisplay: '+91 9205770757',
    alternatePhone: '+91 7303818953',
    alternatePhoneDisplay: '+91 7303818953',
    email: 'marketingsetu365@gmail.com',
    whatsappUrl: 'https://wa.me/919205770757?text=Hi%20Marketing%20Setu%2C%20I%20would%20like%20to%20discuss%20a%20growth%20strategy%20for%20my%20business.',
    hours: 'Mon - Sat: 9:30 AM – 7:30 PM IST'
  },
  teamCount: 15,
  leadership: [
    {
      name: 'Vikas Jain',
      role: 'Director',
      title: 'Director & Performance Marketing Lead',
      bio: 'Drives strategic vision, high-ROAS paid media architecture, and business development. Over 5+ years optimizing multi-million rupee ad spends across Google, Meta, and enterprise search platforms.',
      focus: ['Growth Strategy', 'Google Ads (PPC)', 'Performance Marketing', 'AEO / GEO Engine Search'],
      linkedin: 'https://www.linkedin.com/company/marketingsetu'
    },
    {
      name: 'Pushpendra',
      role: 'Co-Founder',
      title: 'Co-Founder & Operations Lead',
      bio: 'Oversees operational excellence, client delivery workflows, and cross-functional team execution to ensure every campaign launches on schedule with zero friction.',
      focus: ['Agency Operations', 'Client Success', 'Resource Planning', 'Quality Assurance'],
      linkedin: 'https://www.linkedin.com/company/marketingsetu'
    },
    {
      name: 'Manish Bhagel',
      role: 'Marketing Director',
      title: 'Marketing Director',
      bio: 'Leads full-funnel digital campaigns, commercial audience segmentation, brand partnerships, and omnichannel client acquisition architectures.',
      focus: ['Omnichannel Strategy', 'B2B Lead Generation', 'Brand Positioning', 'Campaign Analytics'],
      linkedin: 'https://www.linkedin.com/company/marketingsetu'
    },
    {
      name: 'Vikas Rajora',
      role: 'Marketing Coordinator',
      title: 'Marketing Coordinator',
      bio: 'Synchronizes cross-channel initiatives, creative asset deliverables, day-to-day campaign scheduling, and transparent client reporting dashboards.',
      focus: ['Campaign Coordination', 'Creative Asset Flow', 'Reporting & Analytics', 'Social Media Delivery'],
      linkedin: 'https://www.linkedin.com/company/marketingsetu'
    }
  ],
  colors: {
    primaryNavy: '#071B3D',
    deepMidnight: '#050D1F',
    royalNavy: '#102F60',
    brandOrange: '#FF6500',
    brightOrange: '#FF7A18',
    pureWhite: '#FFFFFF',
    offWhite: '#F8FAFC',
    mutedText: '#94A3B8'
  }
};

/**
 * MARKETING SETU — MASTER STATIC SITE GENERATOR & BUILD PIPELINE
 * Compiles all 32+ pages, generates sitemap.xml, and packages the dist/ directory.
 */

const fs = require('fs');
const path = require('path');

const site = require('./data/site');
const services = require('./data/services');
const blogs = require('./data/blogs');

const { generateHomePage } = require('./src/pages/home');
const { generateAboutPage } = require('./src/pages/about');
const { generateServicesHubPage } = require('./src/pages/services-hub');
const { generateServiceDetailPage } = require('./src/pages/service-detail');
const { generatePortfolioPage } = require('./src/pages/portfolio');
const { generateBlogHubPage } = require('./src/pages/blog-hub');
const { generateBlogDetailPage } = require('./src/pages/blog-detail');
const { generateContactPage } = require('./src/pages/contact');
const { generatePrivacyPage, generateTermsPage } = require('./src/pages/legal');
const { generateThankYouPage, generate404Page } = require('./src/pages/utility');

const rootDir = __dirname;
const distDir = path.join(rootDir, 'dist');

// Ensure necessary directory tree exists
function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

async function build() {
  console.log('====================================================');
  console.log('MARKETING SETU — COMPILING COMPLETE STATIC WEBSITE');
  console.log('====================================================\n');

  ensureDir(path.join(rootDir, 'services'));
  ensureDir(path.join(rootDir, 'blog'));
  ensureDir(path.join(rootDir, 'api'));
  ensureDir(distDir);
  ensureDir(path.join(distDir, 'services'));
  ensureDir(path.join(distDir, 'blog'));
  ensureDir(path.join(distDir, 'api'));

  const generatedPages = [];

  // 1. Root Pages
  const rootPages = [
    { file: 'index.html', html: generateHomePage(), priority: '1.0' },
    { file: 'about.html', html: generateAboutPage(), priority: '0.8' },
    { file: 'services.html', html: generateServicesHubPage(), priority: '0.9' },
    { file: 'portfolio.html', html: generatePortfolioPage(), priority: '0.8' },
    { file: 'blog.html', html: generateBlogHubPage(), priority: '0.8' },
    { file: 'contact.html', html: generateContactPage(), priority: '0.85' },
    { file: 'privacy-policy.html', html: generatePrivacyPage(), priority: '0.4' },
    { file: 'terms-conditions.html', html: generateTermsPage(), priority: '0.4' },
    { file: 'thank-you.html', html: generateThankYouPage(), priority: '0.3' },
    { file: '404.html', html: generate404Page(), priority: '0.1' }
  ];

  for (const page of rootPages) {
    fs.writeFileSync(path.join(rootDir, page.file), page.html, 'utf8');
    generatedPages.push({ path: page.file, url: `${site.url}/${page.file === 'index.html' ? '' : page.file}`, priority: page.priority });
    console.log(`✓ Generated: ${page.file} (${Buffer.byteLength(page.html, 'utf8')} bytes)`);
  }

  // 2. Individual Service Pages (20 Services)
  console.log('\n--- Compiling 20 Service Pages ---');
  for (const service of services) {
    const serviceHtml = generateServiceDetailPage(service);
    const fileName = `${service.slug}.html`;
    fs.writeFileSync(path.join(rootDir, 'services', fileName), serviceHtml, 'utf8');
    generatedPages.push({ path: `services/${fileName}`, url: `${site.url}/services/${fileName}`, priority: '0.85' });
    console.log(`✓ Service: services/${fileName}`);
  }

  // 3. Individual Blog Pages (5 Articles)
  console.log('\n--- Compiling 5 Deep-Dive Blog Articles ---');
  for (const blog of blogs) {
    const blogHtml = generateBlogDetailPage(blog);
    const fileName = `${blog.slug}.html`;
    fs.writeFileSync(path.join(rootDir, 'blog', fileName), blogHtml, 'utf8');
    generatedPages.push({ path: `blog/${fileName}`, url: `${site.url}/blog/${fileName}`, priority: '0.75' });
    console.log(`✓ Article: blog/${fileName}`);
  }

  // 4. Generate XML Sitemap
  console.log('\n--- Generating sitemap.xml ---');
  const today = new Date().toISOString().split('T')[0];
  const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${generatedPages.filter(p => !p.path.includes('404') && !p.path.includes('thank-you')).map(p => `  <url>
    <loc>${p.url}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>${p.priority === '1.0' ? 'weekly' : 'monthly'}</changefreq>
    <priority>${p.priority}</priority>
  </url>`).join('\n')}
</urlset>
`;
  fs.writeFileSync(path.join(rootDir, 'sitemap.xml'), sitemapXml, 'utf8');
  console.log(`✓ sitemap.xml created with ${generatedPages.length - 2} indexable URLs`);

  // 5. Package Everything into dist/ (Ready for GoDaddy / Apache upload)
  console.log('\n--- Assembling Production dist/ Directory ---');
  copyRecursive(path.join(rootDir, 'assets'), path.join(distDir, 'assets'));
  copyRecursive(path.join(rootDir, 'api'), path.join(distDir, 'api'));
  copyRecursive(path.join(rootDir, 'services'), path.join(distDir, 'services'));
  copyRecursive(path.join(rootDir, 'blog'), path.join(distDir, 'blog'));

  // Copy root files
  const rootFilesToCopy = [
    'index.html',
    'about.html',
    'services.html',
    'portfolio.html',
    'blog.html',
    'contact.html',
    'privacy-policy.html',
    'terms-conditions.html',
    'thank-you.html',
    '404.html',
    '.htaccess',
    'robots.txt',
    'sitemap.xml'
  ];

  for (const file of rootFilesToCopy) {
    const srcPath = path.join(rootDir, file);
    if (fs.existsSync(srcPath)) {
      fs.copyFileSync(srcPath, path.join(distDir, file));
    }
  }

  console.log('\n====================================================');
  console.log(`🎉 BUILD COMPLETE: ${generatedPages.length} Static Pages Generated!`);
  console.log('Production Folder: "dist/" (Ready to upload to GoDaddy public_html)');
  console.log('====================================================\n');
}

function copyRecursive(src, dest) {
  if (!fs.existsSync(src)) return;
  ensureDir(dest);
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyRecursive(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

build().catch(err => {
  console.error('Build failed with error:', err);
  process.exit(1);
});

const fs = require('fs');
const path = require('path');

const vendorDir = path.join(__dirname, '..', 'assets', 'js', 'vendor');
if (!fs.existsSync(vendorDir)) {
  fs.mkdirSync(vendorDir, { recursive: true });
}

const files = [
  {
    name: 'three.min.js',
    url: 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js'
  },
  {
    name: 'gsap.min.js',
    url: 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js'
  },
  {
    name: 'ScrollTrigger.min.js',
    url: 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js'
  }
];

async function run() {
  for (const item of files) {
    const dest = path.join(vendorDir, item.name);
    console.log(`Downloading ${item.name}...`);
    try {
      const res = await fetch(item.url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      fs.writeFileSync(dest, text, 'utf8');
      console.log(`Saved ${item.name} (${text.length} bytes)`);
    } catch (e) {
      console.error(`Failed ${item.name}:`, e.message);
    }
  }
}

run();

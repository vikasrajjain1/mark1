const fs = require('fs');
const path = require('path');
const blogDir = 'C:/Users/proma/Documents/vikas/website/website files-20261116T070221Z-1-001/godaddy-deployment/blog';
const files = fs.readdirSync(blogDir).filter(f => f.endsWith('.html'));

files.forEach(f => {
  const content = fs.readFileSync(path.join(blogDir, f), 'utf8');
  const title = (content.match(/<title>([^<]+)<\/title>/) || [])[1] || '';
  const desc = (content.match(/<meta name="description" content="([^"]+)"/) || [])[1] || '';
  const h1 = (content.match(/<h1[^>]*>([\s\S]*?)<\/h1>/) || [])[1] || '';
  console.log('File:', f);
  console.log('  Title:', title.trim());
  console.log('  H1:', h1.replace(/\s+/g, ' ').trim());
  console.log('  Desc length:', desc.length);
});

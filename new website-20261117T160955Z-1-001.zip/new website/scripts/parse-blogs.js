const fs = require('fs');
const path = require('path');
const blogDir = 'C:/Users/proma/Documents/vikas/website/website files-20261116T070221Z-1-001/godaddy-deployment/blog';
const files = fs.readdirSync(blogDir).filter(f => f.endsWith('.html'));

const blogPosts = [];

files.forEach(f => {
  const content = fs.readFileSync(path.join(blogDir, f), 'utf8');
  const slug = f.replace('.html', '');
  const title = (content.match(/<title>([^<]+)<\/title>/) || [])[1] || '';
  const desc = (content.match(/<meta name="description" content="([^"]+)"/) || [])[1] || '';
  const h1 = ((content.match(/<h1[^>]*>([\s\S]*?)<\/h1>/) || [])[1] || '').replace(/\s+/g, ' ').trim();
  
  // Extract article body content (between <article> or <div class="article-content">)
  let body = '';
  const articleMatch = content.match(/<article[^>]*>([\s\S]*?)<\/article>/i);
  if (articleMatch) {
    body = articleMatch[1];
  } else {
    const mainMatch = content.match(/<main[^>]*>([\s\S]*?)<\/main>/i);
    body = mainMatch ? mainMatch[1] : '';
  }

  // Meta info
  const dateMatch = content.match(/(\d{1,2}\s+[A-Za-z]+,?\s+\d{4})/);
  const date = dateMatch ? dateMatch[1] : 'November 15, 2026';

  blogPosts.push({
    slug,
    title: h1 || title.split('|')[0].trim(),
    metaTitle: title.trim(),
    metaDesc: desc,
    date,
    bodyLength: body.length
  });
});

console.log('Blog posts extracted:', blogPosts);

const fs = require('fs');
const path = require('path');

const blogDir = 'C:/Users/proma/Documents/vikas/website/website files-20261116T070221Z-1-001/godaddy-deployment/blog';
const files = [
  'what-is-seo-in-2026.html',
  'seo-vs-aeo-vs-geo.html',
  'how-to-generate-quality-leads.html',
  'google-ads-vs-meta-ads.html',
  'social-media-marketing-small-business.html'
];

const categoryMap = {
  'what-is-seo-in-2026.html': 'Search & SEO',
  'seo-vs-aeo-vs-geo.html': 'AI Search & AEO',
  'how-to-generate-quality-leads.html': 'Lead Generation',
  'google-ads-vs-meta-ads.html': 'Paid Media',
  'social-media-marketing-small-business.html': 'Social & Branding'
};

const readTimeMap = {
  'what-is-seo-in-2026.html': '7 min read',
  'seo-vs-aeo-vs-geo.html': '9 min read',
  'how-to-generate-quality-leads.html': '6 min read',
  'google-ads-vs-meta-ads.html': '8 min read',
  'social-media-marketing-small-business.html': '6 min read'
};

const blogs = files.map((f, idx) => {
  const content = fs.readFileSync(path.join(blogDir, f), 'utf8');
  const slug = f.replace('.html', '');
  const title = (content.match(/<title>([^<]+)<\/title>/) || [])[1] || '';
  const desc = (content.match(/<meta name="description" content="([^"]+)"/) || [])[1] || '';
  const h1 = ((content.match(/<h1[^>]*>([\s\S]*?)<\/h1>/) || [])[1] || '').replace(/\s+/g, ' ').trim();

  // Extract inner article body (between <article> tags)
  let body = '';
  const articleMatch = content.match(/<article[^>]*>([\s\S]*?)<\/article>/i);
  if (articleMatch) {
    body = articleMatch[1].trim();
  }

  // Extract h2 headings for Table of Contents
  const h2Matches = [...body.matchAll(/<h2[^>]*>([\s\S]*?)<\/h2>/gi)];
  const toc = h2Matches.map(m => {
    const rawText = m[1].replace(/<[^>]+>/g, '').trim();
    const id = rawText.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    return { title: rawText, id };
  });

  return {
    order: idx + 1,
    slug,
    title: h1 || title.split('|')[0].trim(),
    metaTitle: title.trim(),
    metaDesc: desc,
    category: categoryMap[f] || 'Digital Marketing',
    readTime: readTimeMap[f] || '7 min read',
    date: 'November 15, 2026',
    author: {
      name: 'Vikas Jain',
      role: 'Director & Performance Lead',
      avatar: 'assets/images/favicon.svg'
    },
    toc,
    contentHtml: body
  };
});

fs.writeFileSync(
  path.join(__dirname, '..', 'data', 'blogs.js'),
  'module.exports = ' + JSON.stringify(blogs, null, 2) + ';\n',
  'utf8'
);

console.log(`Generated data/blogs.js with ${blogs.length} articles!`);

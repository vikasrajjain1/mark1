const fs = require('fs');
const path = require('path');
const rawServices = require('../data/raw_services.js');

const iconSvgMap = {
  'seo': '<path d="M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm10 2-4.35-4.35M11 8v6M8 11h6"/>',
  'google-ads': '<circle cx="12" cy="12" r="10"/><path d="m14.5 9.5-5 5M9.5 9.5l5 5"/><circle cx="12" cy="12" r="3"/>',
  'meta-ads': '<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>',
  'lead-generation': '<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/><path d="m12 11 3-3"/>',
  'local-seo': '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
  'technical-seo': '<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/><line x1="14" y1="4" x2="10" y2="20"/>',
  'aeo': '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><circle cx="9" cy="10" r="1"/><circle cx="12" cy="10" r="1"/><circle cx="15" cy="10" r="1"/>',
  'geo': '<path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3Z"/>',
  'content-marketing': '<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5Z"/><path d="M6 6h10M6 10h10M6 14h6"/>',
  'graphic-design': '<path d="m12 19 7-7 3 3-7 7-3-3z"/><path d="m18 13-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="m2 2 7.586 7.586"/><circle cx="11" cy="11" r="2"/>',
  'video-editing': '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="m10 8 6 4-6 4V8z"/>',
  'branding': '<path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
  'social-media-marketing': '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect width="4" height="12" x="2" y="9"/><circle cx="4" cy="4" r="2"/>',
  'linkedin-marketing': '<rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>',
  'email-marketing': '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
  'website-design': '<rect width="20" height="14" x="2" y="3" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>',
  'app-design': '<rect width="14" height="20" x="5" y="2" rx="3"/><line x1="12" y1="18" x2="12.01" y2="18"/>',
  'conversion-rate-optimization': '<line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/>',
  'digital-advertising': '<circle cx="12" cy="12" r="10"/><path d="m4.93 4.93 4.24 4.24M14.83 14.83l4.24 4.24M14.83 9.17l4.24-4.24M4.93 19.07l4.24-4.24"/>',
  'paid-marketing': '<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>'
};

const shortDescs = {
  'seo': 'Dominating organic search results across Google with topical authority, zero spam, and high-intent keyword clustering.',
  'google-ads': 'High-converting Google Search, Performance Max, and Shopping campaigns engineered for maximum ROAS and low CPL.',
  'meta-ads': 'Creative-first Facebook & Instagram ad funnels that capture attention, combat ad fatigue, and scale revenue.',
  'lead-generation': 'Predictable sales-qualified pipelines for B2B and high-ticket B2C brands via verified multi-touch funnels.',
  'local-seo': 'Google Business Profile dominance and local map pack rankings for businesses targeting Delhi-NCR and regional markets.',
  'technical-seo': 'Core Web Vitals acceleration, semantic schema architecture, crawl budget tuning, and clean indexing.',
  'aeo': 'Positioning your brand as the direct, definitive answer in Perplexity, Claude, ChatGPT, and AI search engines.',
  'geo': 'Generative Engine Optimization engineered to get your brand cited inside Google AI Overviews and LLM summaries.',
  'content-marketing': 'Authoritative pillar articles, thought leadership, and strategic assets that build enduring organic equity.',
  'graphic-design': 'Awwwards-inspired visual branding, social assets, presentation decks, and high-impact commercial design.',
  'video-editing': 'Thumb-stopping short-form reels, product motion, and brand videos edited for maximum retention and clicks.',
  'branding': 'Complete brand identity systems, typography, color architecture, and strategic market positioning.',
  'social-media-marketing': 'Organic community building, viral distribution, and brand resonance across Instagram, YouTube, and LinkedIn.',
  'linkedin-marketing': 'Executive personal branding, B2B account-based marketing, and high-level decision-maker outreach.',
  'email-marketing': 'Automated customer journeys, segmentation, retention funnels, and high-deliverability email campaigns.',
  'website-design': 'Fast, bespoke, award-caliber websites built for conversion, performance, and memorable brand prestige.',
  'app-design': 'Frictionless mobile and web UI/UX prototypes designed for high user engagement and seamless onboarding.',
  'conversion-rate-optimization': 'Scientific A/B testing, heatmaps, and funnel optimization to turn existing traffic into paying clients.',
  'digital-advertising': 'Holistic 360-degree digital media planning and cross-platform advertising across search, social, and display.',
  'paid-marketing': 'Disciplined PPC campaign management, bid optimization, and real-time conversion feedback loops.'
};

const metricHighlights = {
  'seo': { value: '+240%', label: 'Avg Organic Growth' },
  'google-ads': { value: '4.8x', label: 'Average ROAS' },
  'meta-ads': { value: '62%', label: 'Lower Cost Per Acquisition' },
  'lead-generation': { value: '3.5x', label: 'Sales-Ready Leads' },
  'local-seo': { value: 'Top 3', label: 'Local Map Pack Focus' },
  'technical-seo': { value: '95+', label: 'Core Web Vitals Score' },
  'aeo': { value: '70%+', label: 'AI Answer Visibility' },
  'geo': { value: '3.8x', label: 'LLM Brand Mentions' },
  'content-marketing': { value: '180%', label: 'Long-Tail Traffic Boost' },
  'graphic-design': { value: '100%', label: 'Bespoke Brand Assets' },
  'video-editing': { value: '4.2x', label: 'Video Engagement' },
  'branding': { value: '360�', label: 'Cohesive Visual Identity' },
  'social-media-marketing': { value: '5.2x', label: 'Audience Growth Rate' },
  'linkedin-marketing': { value: '45%+', label: 'C-Suite Inbound Replies' },
  'email-marketing': { value: '38%', label: 'Average Open Rate' },
  'website-design': { value: '<1.2s', label: 'Lightning Page Load' },
  'app-design': { value: '4.9?', label: 'User Flow Satisfaction' },
  'conversion-rate-optimization': { value: '+54%', label: 'Checkout/Form Lift' },
  'digital-advertising': { value: '10M+', label: 'Targeted Impressions' },
  'paid-marketing': { value: '100%', label: 'Budget Efficiency' }
};

const enriched = rawServices.map((s, idx) => {
  return {
    ...s,
    order: idx + 1,
    svgPath: iconSvgMap[s.slug] || '<circle cx="12" cy="12" r="10"/>',
    shortDesc: shortDescs[s.slug] || s.tagline,
    metric: metricHighlights[s.slug] || { value: '100%', label: 'Growth Target' },
    pillar: getPillar(s.category),
    process: [
      { step: '01', title: 'Deep Discovery & Audit', desc: 'Comprehensive benchmarking of existing data, competitor positioning, and untapped revenue bottlenecks.' },
      { step: '02', title: 'Strategic Architecture', desc: 'Custom blueprint defining high-intent targets, messaging hooks, channel mix, and ROI metrics.' },
      { step: '03', title: 'Agile Execution & Launch', desc: 'Rapid rollout of creative assets, technical configurations, tracking tags, and live campaign assets.' },
      { step: '04', title: 'Continuous Optimization', desc: 'Weekly data review, A/B performance testing, bid adjustments, and transparent executive reporting.' }
    ]
  };
});

function getPillar(category) {
  if (category.includes('Search') || category.includes('AI')) return 'Search & Discovery';
  if (category.includes('Paid')) return 'Paid Media & Ads';
  if (category.includes('Content') || category.includes('Brand')) return 'Creative & Brand';
  if (category.includes('Performance') || category.includes('Web')) return 'Performance & Tech';
  return 'Full-Funnel Growth';
}

fs.writeFileSync(
  path.join(__dirname, '..', 'data', 'services.js'),
  'module.exports = ' + JSON.stringify(enriched, null, 2) + ';\n',
  'utf8'
);

console.log(`Generated enriched data/services.js with ${enriched.length} services!`);

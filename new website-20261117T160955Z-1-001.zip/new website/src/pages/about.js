/**
 * MARKETING SETU — ABOUT US PAGE TEMPLATE
 */

const site = require('../../data/site');
const { renderHead, renderNav, renderFooter, escapeHtml } = require('../templates/common');

function generateAboutPage() {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'AboutPage',
    'name': 'About Marketing Setu — Delhi\'s Premier Digital Growth Agency',
    'description': 'Learn about Marketing Setu\'s journey, our 15-member Delhi agency team, and our philosophy: From Strategy to Growth.',
    'url': `${site.url}/about.html`,
    'mainEntity': {
      '@type': 'Organization',
      'name': site.name,
      'legalName': site.legalName,
      'numberOfEmployees': site.teamCount,
      'address': {
        '@type': 'PostalAddress',
        'addressLocality': site.location.city,
        'addressRegion': site.location.region,
        'addressCountry': 'IN'
      }
    }
  };

  const head = renderHead({
    title: 'About Marketing Setu | From Strategy to Growth | Delhi Agency',
    description: 'Discover Marketing Setu: a 15-member digital marketing powerhouse in Delhi, India. We unite performance marketing, technical SEO, and creative motion design.',
    canonicalPath: 'about.html',
    schema,
    relPrefix: ''
  });

  const nav = renderNav({ currentPath: 'about', relPrefix: '' });

  const body = `
  <main id="main-content">
    <!-- Hero Header -->
    <section class="section section-dark" style="padding-top: 9rem; padding-bottom: 4rem;">
      <div class="container" style="text-align: center; max-width: 900px;">
        <span class="section-badge">✦ Our Identity & Mission</span>
        <h1 style="margin-bottom: 1.5rem; font-size: clamp(2.4rem, 5vw, 4rem);">
          The Bridge Between Bold Ambition and <span class="highlight-orange">Measurable Growth</span>
        </h1>
        <p style="font-size: 1.2rem; color: #CBD5E1; line-height: 1.7; margin-bottom: 2rem;">
          "Setu" is the Sanskrit word for Bridge. In an era of fragmented digital noise, Marketing Setu exists to be the indestructible bridge connecting brand potential to real-world commercial scale.
        </p>
      </div>
    </section>

    <!-- Story & Origin -->
    <section class="section section-navy">
      <div class="container">
        <div class="intro-grid">
          <div>
            <span class="section-badge-navy" style="display:inline-block; font-size:0.75rem; padding:0.3rem 0.8rem; margin-bottom:1rem; border-radius:4px;">Born in Delhi, Built for Scale</span>
            <h2 style="margin-bottom: 1.4rem;">
              Crafted With Purpose.<br>
              <span class="highlight-orange">Executed With Rigor.</span>
            </h2>
            <p style="color: var(--text-muted); font-size: 1rem; line-height: 1.7; margin-bottom: 1.2rem;">
              Headquartered in Delhi, India, Marketing Setu was established to solve the greatest frustration facing growing businesses: marketing agencies that excel at flashy pitch presentations but fail when it comes to daily media management, data accuracy, and commercial ROI.
            </p>
            <p style="color: var(--text-muted); font-size: 1rem; line-height: 1.7; margin-bottom: 1.4rem;">
              We rejected the traditional agency structure of layers of account executives passing briefs down to junior interns. Instead, we assembled a focused, elite team of 15 practitioners — senior media buyers, conversion copywriters, video animators, and web engineers who work collaboratively directly with business leaders.
            </p>
            <div style="display: flex; gap: 2rem; padding-top: 1.5rem; border-top: 1px solid var(--border-glass);">
              <div>
                <div style="font-family: var(--font-heading); font-size: 2.2rem; font-weight: 800; color: #FFFFFF;">15</div>
                <div style="font-size: 0.85rem; color: #94A3B8;">Dedicated Specialists</div>
              </div>
              <div>
                <div style="font-family: var(--font-heading); font-size: 2.2rem; font-weight: 800; color: var(--orange-bright);">100%</div>
                <div style="font-size: 0.85rem; color: #94A3B8;">In-House Execution</div>
              </div>
              <div>
                <div style="font-family: var(--font-heading); font-size: 2.2rem; font-weight: 800; color: #FFFFFF;">2026</div>
                <div style="font-size: 0.85rem; color: #94A3B8;">AI & AEO Ready</div>
              </div>
            </div>
          </div>

          <div class="intro-right-card">
            <h3 style="margin-bottom: 1.2rem; font-size: 1.5rem;">Our Core Principles</h3>
            <div style="display: flex; flex-direction: column; gap: 1.4rem;">
              <div>
                <h4 style="color: var(--orange-bright); font-size: 1.1rem; margin-bottom: 0.3rem;">01. Commercial Truth Over Vanity</h4>
                <p style="font-size: 0.9rem; color: var(--text-muted); margin: 0;">Impressions and clicks don't pay payroll. We optimize for sales-qualified leads, low customer acquisition costs, and enterprise pipeline value.</p>
              </div>
              <div>
                <h4 style="color: var(--orange-bright); font-size: 1.1rem; margin-bottom: 0.3rem;">02. Multidisciplinary Harmony</h4>
                <p style="font-size: 0.9rem; color: var(--text-muted); margin: 0;">Copy cannot succeed without psychology. Ads cannot convert without high-speed landing pages. We unify creative, tech, and performance.</p>
              </div>
              <div>
                <h4 style="color: var(--orange-bright); font-size: 1.1rem; margin-bottom: 0.3rem;">03. Complete Transparency</h4>
                <p style="font-size: 0.9rem; color: var(--text-muted); margin: 0;">You own your ad accounts, your data, and your creative files. Weekly video reviews and live dashboards keep you in total control.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Leadership Team -->
    <section class="section section-dark">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ Agency Governance</span>
          <h2 class="section-title">
            The Leadership <span class="highlight-orange">Behind Your Growth</span>
          </h2>
          <p class="section-subtitle">
            Experienced strategists personally steering agency direction and client outcomes.
          </p>
        </div>

        <div class="team-grid">
          ${site.leadership.map(m => `
            <div class="team-card">
              <div class="team-avatar-wrap">
                <span class="team-avatar-initials">${m.name.split(' ').map(n => n[0]).join('')}</span>
              </div>
              <h3 class="team-name">${m.name}</h3>
              <div class="team-role-pill">${m.title}</div>
              <p class="team-bio">${m.bio}</p>
              <div class="team-focus-tags">
                ${m.focus.map(f => `<span class="team-focus-tag">${f}</span>`).join('')}
              </div>
            </div>
          `).join('\n')}
        </div>
      </div>
    </section>

    <!-- Culture & Multidisciplinary Depth -->
    <section class="section section-navy">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ Collective Capability</span>
          <h2 class="section-title">
            Inside Our <span class="highlight-orange">15-Member Powerhouse</span>
          </h2>
          <p class="section-subtitle">
            Every client account is powered by a synchronized pod covering four essential growth disciplines.
          </p>
        </div>

        <div class="why-grid">
          <div class="why-card">
            <h3 class="why-card-title">Media Buying & Paid Acquisition</h3>
            <p class="why-card-desc">Certified Google Ads & Meta media buyers running search, Performance Max, YouTube, and retargeting with disciplined bid management.</p>
          </div>
          <div class="why-card">
            <h3 class="why-card-title">Technical SEO & AEO Specialists</h3>
            <p class="why-card-desc">Crawl engineers and semantic content strategists positioning your brand in top Google ranks and AI answer summaries.</p>
          </div>
          <div class="why-card">
            <h3 class="why-card-title">Creative Motion & Graphic Designers</h3>
            <p class="why-card-desc">Visual storytellers crafting thumb-stopping social reels, branding guides, infographics, and high-impact commercial assets.</p>
          </div>
          <div class="why-card">
            <h3 class="why-card-title">Frontend & Web Engineers</h3>
            <p class="why-card-desc">Developers building bespoke, lightning-fast digital experiences with clean code, smooth animations, and high Core Web Vitals.</p>
          </div>
          <div class="why-card">
            <h3 class="why-card-title">Conversion Copywriters</h3>
            <p class="why-card-desc">Persuasive copywriters crafting commercial ad hooks, long-form landing pages, and email nurture sequences that convert cold traffic.</p>
          </div>
          <div class="why-card">
            <h3 class="why-card-title">Analytics & Attribution Analysts</h3>
            <p class="why-card-desc">Tracking architects configuring server-side Google Tag Manager, Meta CAPI, and Looker Studio real-time executive dashboards.</p>
          </div>
        </div>

        <div style="text-align: center; margin-top: 3.5rem;">
          <button class="btn btn-primary btn-lg" data-open-modal="true" data-service="Meet Our Directors">
            <span>Schedule A Discussion With Our Directors</span>
            <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
          </button>
        </div>
      </div>
    </section>
  </main>`;

  const footer = renderFooter({ relPrefix: '' });
  return head + nav + body + footer;
}

module.exports = { generateAboutPage };

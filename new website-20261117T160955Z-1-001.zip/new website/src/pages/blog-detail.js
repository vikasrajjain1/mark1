/**
 * MARKETING SETU — INDIVIDUAL BLOG ARTICLE TEMPLATE
 */

const site = require('../../data/site');
const blogs = require('../../data/blogs');
const { renderHead, renderNav, renderFooter, escapeHtml } = require('../templates/common');

function generateBlogDetailPage(blog) {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    'headline': blog.title,
    'description': blog.metaDesc,
    'datePublished': '2026-11-15T10:00:00+05:30',
    'dateModified': '2026-11-17T12:00:00+05:30',
    'mainEntityOfPage': {
      '@type': 'WebPage',
      '@id': `${site.url}/blog/${blog.slug}.html`
    },
    'author': {
      '@type': 'Person',
      'name': blog.author.name,
      'jobTitle': blog.author.role
    },
    'publisher': {
      '@type': 'Organization',
      'name': site.name,
      'logo': {
        '@type': 'ImageObject',
        'url': `${site.url}/assets/images/logo.png`
      }
    },
    'image': `${site.url}/assets/images/logo.png`
  };

  const head = renderHead({
    title: blog.metaTitle,
    description: blog.metaDesc,
    canonicalPath: `blog/${blog.slug}.html`,
    schema,
    relPrefix: '../'
  });

  const nav = renderNav({ currentPath: `blog/${blog.slug}`, relPrefix: '../' });

  // Other blogs for related reading
  const otherBlogs = blogs.filter(b => b.slug !== blog.slug).slice(0, 2);

  const body = `
  <main id="main-content">
    <article itemscope itemtype="https://schema.org/BlogPosting">
      <!-- Article Header -->
      <header class="article-header">
        <div class="container" style="max-width: 860px;">
          <!-- Breadcrumb -->
          <nav aria-label="Breadcrumb" style="font-size: 0.82rem; color: #94A3B8; margin-bottom: 1.5rem; font-family: var(--font-mono);">
            <a href="../index.html" style="color: #94A3B8;">Home</a>
            <span style="margin: 0 0.5rem;">/</span>
            <a href="../blog.html" style="color: #94A3B8;">Blog</a>
            <span style="margin: 0 0.5rem;">/</span>
            <span style="color: var(--orange-bright);">${escapeHtml(blog.category)}</span>
          </nav>

          <span class="section-badge" style="margin-bottom: 1rem;">${escapeHtml(blog.category)}</span>
          <h1 itemprop="headline" style="margin-bottom: 1.4rem; font-size: clamp(2.2rem, 4.5vw, 3.4rem); line-height: 1.2;">
            ${escapeHtml(blog.title)}
          </h1>

          <div style="display: flex; align-items: center; justify-content: center; gap: 1.5rem; color: #94A3B8; font-size: 0.88rem; flex-wrap: wrap;">
            <span>By <strong style="color: #FFFFFF;">${blog.author.name}</strong> (${blog.author.role})</span>
            <span>•</span>
            <time itemprop="datePublished" datetime="2026-11-15">${blog.date}</time>
            <span>•</span>
            <span>${blog.readTime}</span>
          </div>
        </div>
      </header>

      <!-- Content Area with Sticky TOC -->
      <section class="section section-dark" style="padding-top: 1rem;">
        <div class="container">
          <div class="article-content-grid">
            <!-- Sidebar Sticky Table of Contents -->
            <aside class="article-sidebar-sticky" aria-label="Table of Contents">
              <div class="toc-heading">Table of Contents</div>
              <ul class="toc-list">
                ${blog.toc.map(t => `<li><a href="#${t.id}" class="toc-link">${escapeHtml(t.title)}</a></li>`).join('\n')}
              </ul>

              <div style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid var(--border-glass);">
                <div style="font-size: 0.85rem; font-weight: 700; color: #FFFFFF; margin-bottom: 0.5rem;">Need Strategic Guidance?</div>
                <p style="font-size: 0.78rem; color: #94A3B8; margin-bottom: 1rem;">Our Delhi team helps you implement these exact systems.</p>
                <button class="btn btn-outline-orange btn-sm" data-open-modal="true" data-service="${escapeHtml(blog.title.split(':')[0])}" style="width: 100%;">
                  Book Strategy Call
                </button>
              </div>
            </aside>

            <!-- Main Article Body -->
            <div class="article-body" itemprop="articleBody">
              ${injectSectionIds(blog.contentHtml, blog.toc)}

              <!-- Post Bottom Author Box -->
              <div style="margin-top: 3.5rem; padding: 2rem; background: var(--surface-card); border: 1px solid var(--border-glass); border-radius: var(--radius-lg); display: flex; gap: 1.5rem; align-items: center;">
                <div style="width: 64px; height: 64px; border-radius: 50%; background: linear-gradient(135deg, #102F60, #071B3D); border: 2px solid var(--orange-bright); display: flex; align-items: center; justify-content: center; font-family: var(--font-heading); font-size: 1.3rem; font-weight: 800; color: var(--orange-bright); flex-shrink: 0;">
                  VJ
                </div>
                <div>
                  <h4 style="margin-bottom: 0.25rem;">Written by ${blog.author.name}</h4>
                  <div style="font-size: 0.82rem; color: var(--orange-bright); margin-bottom: 0.5rem; font-family: var(--font-mono);">${blog.author.role}</div>
                  <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">
                    Leading performance media, technical SEO, and commercial acquisition strategies across Google, Meta, and AI search engines at Marketing Setu.
                  </p>
                </div>
              </div>

              <!-- Conversion CTA Box inside article -->
              <div style="margin-top: 3rem; background: linear-gradient(135deg, rgba(255,101,0,0.12) 0%, rgba(16,47,96,0.4) 100%); border: 1px solid rgba(255,101,0,0.35); border-radius: var(--radius-lg); padding: 2.2rem; text-align: center;">
                <h3 style="margin-bottom: 0.8rem; font-size: 1.4rem;">Accelerate Your Growth With Marketing Setu</h3>
                <p style="color: #CBD5E1; font-size: 0.95rem; margin-bottom: 1.5rem; max-width: 600px; margin-left: auto; margin-right: auto;">
                  Partner with our 15 in-house specialists in Delhi to turn these frameworks into high-converting revenue pipelines.
                </p>
                <button class="btn btn-primary" data-open-modal="true" data-service="${escapeHtml(blog.title)}">
                  <span>Schedule Consultation</span>
                  <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Related Posts -->
      <section class="section section-navy">
        <div class="container">
          <div class="section-header">
            <span class="section-badge">✦ Continue Reading</span>
            <h2 class="section-title">Related <span class="highlight-orange">Articles</span></h2>
          </div>

          <div class="blog-cards-grid" style="grid-template-columns: repeat(2, 1fr);">
            ${otherBlogs.map(b => `
              <article class="blog-card">
                <div class="blog-thumb-wrap">
                  <span class="blog-badge-tag">${b.category}</span>
                  <div style="font-family: var(--font-heading); font-size: 1.3rem; font-weight: 800; color: #FFFFFF; text-align: center; max-width: 85%;">
                    ${b.title.split(':')[0]}
                  </div>
                </div>
                <div class="blog-content">
                  <div class="blog-meta-row">
                    <span>${b.date}</span>
                    <span>•</span>
                    <span>${b.readTime}</span>
                  </div>
                  <h3 class="blog-title" style="font-size: 1.2rem;">
                    <a href="${b.slug}.html">${escapeHtml(b.title)}</a>
                  </h3>
                  <p class="blog-excerpt">${escapeHtml(b.metaDesc)}</p>
                  <a href="${b.slug}.html" class="blog-footer-link">
                    <span>Read Guide</span>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                  </a>
                </div>
              </article>
            `).join('\n')}
          </div>
        </div>
      </section>
    </article>
  </main>`;

  const footer = renderFooter({ relPrefix: '../' });
  return head + nav + body + footer;
}

// Helper to inject ID tags into H2 elements for smooth TOC linking
function injectSectionIds(html, toc) {
  let modified = html;
  toc.forEach(t => {
    // Replace first occurrence of matching H2
    const regex = new RegExp(`<h2>([\\s\\S]*?${escapeRegex(t.title)}[\\s\\S]*?)<\\/h2>`, 'i');
    modified = modified.replace(regex, `<h2 id="${t.id}">$1</h2>`);
  });
  return modified;
}

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

module.exports = { generateBlogDetailPage };

/**
 * MARKETING SETU — BLOG HUB TEMPLATE
 */

const site = require('../../data/site');
const blogs = require('../../data/blogs');
const { renderHead, renderNav, renderFooter, escapeHtml } = require('../templates/common');

function generateBlogHubPage() {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'Blog',
    'name': 'Marketing Setu Insights & Ideas',
    'description': 'Authoritative articles on 2026 SEO, AEO, Generative Engine Optimization, Google Ads, Meta Ads, and B2B Lead Generation.',
    'url': `${site.url}/blog.html`,
    'publisher': {
      '@type': 'Organization',
      'name': site.name
    },
    'blogPost': blogs.map(b => ({
      '@type': 'BlogPosting',
      'headline': b.title,
      'url': `${site.url}/blog/${b.slug}.html`,
      'datePublished': '2026-11-15'
    }))
  };

  const head = renderHead({
    title: 'Digital Marketing & AI Search Insights | Marketing Setu Blog',
    description: 'Expert marketing playbooks on 2026 SEO, AEO, GEO, Google Ads, Meta Ads, and qualified lead generation written by our Delhi directors.',
    canonicalPath: 'blog.html',
    schema,
    relPrefix: ''
  });

  const nav = renderNav({ currentPath: 'blog', relPrefix: '' });

  const body = `
  <main id="main-content">
    <section class="section section-dark" style="padding-top: 9rem; padding-bottom: 3.5rem;">
      <div class="container" style="text-align: center; max-width: 900px;">
        <span class="section-badge">✦ Strategic Intelligence</span>
        <h1 style="margin-bottom: 1.5rem; font-size: clamp(2.4rem, 5vw, 4.2rem);">
          Insights, Frameworks & <span class="highlight-orange">Search Analysis</span>
        </h1>
        <p style="font-size: 1.15rem; color: #CBD5E1; line-height: 1.7; margin-bottom: 2rem;">
          Rigorous guides written by senior practitioners. Preparing modern Indian and global brands for the AI search and performance advertising landscape of 2026.
        </p>
      </div>
    </section>

    <!-- Blog Grid -->
    <section class="section section-navy" style="padding-top: 1rem;">
      <div class="container">
        <div class="blog-cards-grid">
          ${blogs.map(b => `
            <article class="blog-card">
              <div class="blog-thumb-wrap">
                <span class="blog-badge-tag">${b.category}</span>
                <div style="font-family: var(--font-heading); font-size: 1.35rem; font-weight: 800; color: #FFFFFF; text-align: center; max-width: 85%;">
                  ${b.title.split(':')[0]}
                </div>
              </div>
              <div class="blog-content">
                <div class="blog-meta-row">
                  <span>${b.date}</span>
                  <span>•</span>
                  <span>${b.readTime}</span>
                </div>
                <h2 class="blog-title" style="font-size: 1.25rem;">
                  <a href="blog/${b.slug}.html">${escapeHtml(b.title)}</a>
                </h2>
                <p class="blog-excerpt">${escapeHtml(b.metaDesc)}</p>
                <a href="blog/${b.slug}.html" class="blog-footer-link">
                  <span>Read Complete Guide</span>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
              </div>
            </article>
          `).join('\n')}
        </div>
      </div>
    </section>

    <!-- Consultation CTA -->
    <section class="section section-dark" style="text-align: center;">
      <div class="container" style="max-width: 800px;">
        <span class="section-badge">✦ Implement What You Learn</span>
        <h2 style="margin-bottom: 1.2rem;">Ready To Apply These Frameworks To Your Business?</h2>
        <p style="color: #CBD5E1; font-size: 1.1rem; line-height: 1.7; margin-bottom: 2rem;">
          Don't let valuable strategy sit in articles. Schedule a discovery session with our Delhi practitioners to build a customized growth roadmap.
        </p>
        <button class="btn btn-primary btn-lg" data-open-modal="true" data-service="Strategy Consultation">
          <span>Schedule Strategy Session</span>
          <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
        </button>
      </div>
    </section>
  </main>`;

  const footer = renderFooter({ relPrefix: '' });
  return head + nav + body + footer;
}

module.exports = { generateBlogHubPage };

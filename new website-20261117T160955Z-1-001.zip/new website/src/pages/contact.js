/**
 * MARKETING SETU — CONTACT US PAGE TEMPLATE
 */

const site = require('../../data/site');
const services = require('../../data/services');
const { renderHead, renderNav, renderFooter, escapeHtml } = require('../templates/common');

function generateContactPage() {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'ContactPage',
    'name': 'Contact Marketing Setu | Digital Marketing Agency in Delhi',
    'description': 'Contact Marketing Setu in Delhi, India. Call +91 9205770757, WhatsApp us, or submit an inquiry to schedule an executive growth strategy session.',
    'url': `${site.url}/contact.html`,
    'mainEntity': {
      '@type': 'Organization',
      'name': site.name,
      'telephone': site.contacts.primaryPhone,
      'email': site.contacts.email,
      'address': {
        '@type': 'PostalAddress',
        'streetAddress': site.location.address,
        'addressLocality': site.location.city,
        'addressRegion': site.location.region,
        'addressCountry': 'IN'
      }
    }
  };

  const head = renderHead({
    title: 'Contact Us | Marketing Setu Delhi | Growth Strategy Session',
    description: 'Get in touch with Marketing Setu\'s senior growth directors in Delhi. Call +91 9205770757 or request a customized marketing strategy blueprint.',
    canonicalPath: 'contact.html',
    schema,
    relPrefix: ''
  });

  const nav = renderNav({ currentPath: 'contact', relPrefix: '' });

  const body = `
  <main id="main-content">
    <section class="section section-dark" style="padding-top: 9rem; padding-bottom: 3.5rem;">
      <div class="container" style="text-align: center; max-width: 900px;">
        <span class="section-badge">✦ Let's Connect</span>
        <h1 style="margin-bottom: 1.5rem; font-size: clamp(2.4rem, 5vw, 4.2rem);">
          Start Your Brand's <span class="highlight-orange">Next Growth Chapter</span>
        </h1>
        <p style="font-size: 1.15rem; color: #CBD5E1; line-height: 1.7; margin-bottom: 2rem;">
          Whether you need a full-funnel media review, technical SEO overhaul, or an award-worthy website, our 15-member team in Delhi is ready to build your customized growth roadmap.
        </p>
      </div>
    </section>

    <!-- Contact Form & Info Grid -->
    <section class="section section-navy" style="padding-top: 1rem;">
      <div class="container">
        <div class="conversion-box" style="margin-bottom: 4rem;">
          <!-- Left: Contact Details & Channels -->
          <div>
            <span class="section-badge-navy" style="display:inline-block; font-size:0.75rem; padding:0.3rem 0.8rem; margin-bottom:1.2rem; border-radius:4px;">Direct Communication</span>
            <h2 style="margin-bottom: 1.2rem; font-size: 2rem;">Speak With Our Senior Directors</h2>
            <p style="color: var(--text-muted); font-size: 0.98rem; line-height: 1.7; margin-bottom: 2.2rem;">
              We don't use aggressive sales call centers. Your inquiry goes directly to Director Vikas Jain and Co-Founder Pushpendra for a personalized commercial assessment.
            </p>

            <div style="display: flex; flex-direction: column; gap: 1.4rem;">
              <!-- Phone -->
              <div style="display: flex; align-items: flex-start; gap: 1rem;">
                <div style="width: 44px; height: 44px; border-radius: 12px; background: rgba(16,47,96,0.6); border: 1px solid var(--border-glass); display: flex; align-items: center; justify-content: center; color: var(--orange-bright); flex-shrink: 0;">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                </div>
                <div>
                  <div style="font-size: 0.8rem; color: #94A3B8; text-transform: uppercase; font-family: var(--font-mono);">Direct Phone Lines</div>
                  <a href="tel:${site.contacts.primaryPhone}" style="font-family: var(--font-mono); font-size: 1.1rem; font-weight: 700; color: #FFFFFF; display: block;">${site.contacts.primaryPhoneDisplay} (Primary)</a>
                  <a href="tel:${site.contacts.alternatePhone}" style="font-family: var(--font-mono); font-size: 0.95rem; font-weight: 600; color: #94A3B8; display: block; margin-top: 0.2rem;">${site.contacts.alternatePhoneDisplay} (Alternate)</a>
                </div>
              </div>

              <!-- WhatsApp -->
              <div style="display: flex; align-items: flex-start; gap: 1rem;">
                <div style="width: 44px; height: 44px; border-radius: 12px; background: rgba(37,211,102,0.15); border: 1px solid rgba(37,211,102,0.3); display: flex; align-items: center; justify-content: center; color: #25D366; flex-shrink: 0;">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2m.01 1.67c2.2 0 4.26.86 5.82 2.42a8.225 8.225 0 0 1 2.41 5.83c0 4.54-3.7 8.24-8.24 8.24-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.196 8.196 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.24-8.24m4.52 11.66c-.19.53-1.11 1.04-1.54 1.09-.41.05-.93.07-2.69-.66-2.25-.93-3.69-3.23-3.8-3.38-.11-.15-.9-1.2-0.9-2.28 0-1.09.57-1.62.77-1.85.2-.22.45-.28.6-.28.15 0 .3 0 .43.01.14.01.33-.05.51.39.19.45.64 1.56.7 1.67.06.11.1.25.02.4-.07.15-.11.25-.22.38-.11.13-.24.29-.34.39-.11.11-.23.23-.1.45.13.22.58.96 1.25 1.55.86.77 1.59 1.01 1.81 1.12.22.11.35.1.48-.05.13-.15.56-.65.71-.88.15-.22.3-.19.51-.11.2.07 1.3.61 1.52.72.22.11.37.17.43.26.05.1.05.57-.14 1.1z"/></svg>
                </div>
                <div>
                  <div style="font-size: 0.8rem; color: #94A3B8; text-transform: uppercase; font-family: var(--font-mono);">Instant WhatsApp Priority</div>
                  <a href="${site.contacts.whatsappUrl}" target="_blank" rel="noopener noreferrer" style="font-family: var(--font-mono); font-size: 1.05rem; font-weight: 700; color: #25D366; display: block;">+91 92057 70757 (Quick Chat)</a>
                </div>
              </div>

              <!-- Email -->
              <div style="display: flex; align-items: flex-start; gap: 1rem;">
                <div style="width: 44px; height: 44px; border-radius: 12px; background: rgba(16,47,96,0.6); border: 1px solid var(--border-glass); display: flex; align-items: center; justify-content: center; color: var(--orange-bright); flex-shrink: 0;">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                </div>
                <div>
                  <div style="font-size: 0.8rem; color: #94A3B8; text-transform: uppercase; font-family: var(--font-mono);">Official Correspondence</div>
                  <a href="mailto:${site.contacts.email}" style="font-size: 1rem; font-weight: 600; color: #FFFFFF; display: block;">${site.contacts.email}</a>
                </div>
              </div>

              <!-- Location -->
              <div style="display: flex; align-items: flex-start; gap: 1rem;">
                <div style="width: 44px; height: 44px; border-radius: 12px; background: rgba(16,47,96,0.6); border: 1px solid var(--border-glass); display: flex; align-items: center; justify-content: center; color: var(--orange-bright); flex-shrink: 0;">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                </div>
                <div>
                  <div style="font-size: 0.8rem; color: #94A3B8; text-transform: uppercase; font-family: var(--font-mono);">Headquarters</div>
                  <div style="font-size: 0.95rem; color: #CBD5E1; line-height: 1.5;">${site.location.address}</div>
                  <div style="font-size: 0.8rem; color: #64748B; margin-top: 0.3rem;">${site.contacts.hours}</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Right: Comprehensive Lead Form -->
          <div>
            <form data-ms-form="true" action="api/contact-handler.php" method="POST" class="conversion-form">
              <input type="text" name="_ms_hp" class="ms-hp-field" tabindex="-1" autocomplete="off">

              <div class="form-row-2">
                <div class="form-group">
                  <label for="contact-form-name" class="form-label">Full Name *</label>
                  <input type="text" id="contact-form-name" name="full_name" required placeholder="Vikas Sharma" autocomplete="name" class="form-input">
                </div>
                <div class="form-group">
                  <label for="contact-form-biz" class="form-label">Business Name</label>
                  <input type="text" id="contact-form-biz" name="business_name" placeholder="Acme Enterprises" autocomplete="organization" class="form-input">
                </div>
              </div>

              <div class="form-row-2">
                <div class="form-group">
                  <label for="contact-form-email" class="form-label">Work Email *</label>
                  <input type="email" id="contact-form-email" name="email" required placeholder="name@company.com" autocomplete="email" class="form-input">
                </div>
                <div class="form-group">
                  <label for="contact-form-phone" class="form-label">Phone / WhatsApp *</label>
                  <input type="tel" id="contact-form-phone" name="phone" required placeholder="+91 98765 43210" autocomplete="tel" class="form-input">
                </div>
              </div>

              <div class="form-row-2">
                <div class="form-group">
                  <label for="contact-form-service" class="form-label">Required Service</label>
                  <select id="contact-form-service" name="service" class="form-select">
                    <option value="General Growth Consultation">General Growth Consultation</option>
                    ${services.map(s => `<option value="${s.title}">${s.title}</option>`).join('\n')}
                  </select>
                </div>
                <div class="form-group">
                  <label for="contact-form-budget" class="form-label">Monthly Ad Budget</label>
                  <select id="contact-form-budget" name="budget" class="form-select">
                    <option value="Exploring Options">Exploring Options</option>
                    <option value="₹30,000 - ₹75,000">₹30,000 – ₹75,000 /mo</option>
                    <option value="₹75,000 - ₹2,00,000">₹75,000 – ₹2,00,000 /mo</option>
                    <option value="₹2,00,000 - ₹5,00,000">₹2,00,000 – ₹5,00,000 /mo</option>
                    <option value="₹5,00,000+ (Enterprise)">₹5,00,000+ /mo (Enterprise)</option>
                  </select>
                </div>
              </div>

              <div class="form-group">
                <label for="contact-form-message" class="form-label">Tell Us About Your Goals & Bottlenecks</label>
                <textarea id="contact-form-message" name="message" placeholder="Current monthly revenue, target CAC, existing bottlenecks, or launch deadlines..." class="form-textarea" style="min-height: 120px;"></textarea>
              </div>

              <div class="form-group" style="flex-direction: row; align-items: center; gap: 0.6rem;">
                <input type="checkbox" name="consent" id="contact-consent" checked required style="accent-color: var(--orange-brand); width: 16px; height: 16px;">
                <label for="contact-consent" style="font-size: 0.8rem; color: #94A3B8;">I consent to receiving commercial growth recommendations from Marketing Setu.</label>
              </div>

              <div class="form-status-msg"></div>

              <button type="submit" class="btn btn-primary btn-lg" style="width: 100%;">
                <span>Request Growth Blueprint</span>
                <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
              </button>

              <p class="form-disclaimer">
                🔒 We treat your commercial data with strict confidentiality. No spam. You will hear back within 2 business hours.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  </main>`;

  const footer = renderFooter({ relPrefix: '' });
  return head + nav + body + footer;
}

module.exports = { generateContactPage };

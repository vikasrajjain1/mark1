/**
 * MARKETING SETU — AWWWARDS-CALIBER HOMEPAGE TEMPLATE
 * Split-Screen 3D Hero, Holographic WebGL Sculpture, Floating Metric Cards,
 * Infinite Kinetic Marquee Ribbon, Bento Universe, and Interactive ROI Engine.
 */

const site = require('../../data/site');
const services = require('../../data/services');
const industries = require('../../data/industries');
const faqs = require('../../data/faq');
const blogs = require('../../data/blogs');
const { renderHead, renderNav, renderFooter, escapeHtml } = require('../templates/common');

function generateHomePage() {
  const schema = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': ['Organization', 'MarketingAgency', 'LocalBusiness'],
        '@id': `${site.url}/#organization`,
        'name': site.name,
        'legalName': site.legalName,
        'url': site.url,
        'logo': `${site.url}/assets/images/logo.png`,
        'description': site.heroSubheadline,
        'slogan': site.tagline,
        'telephone': site.contacts.primaryPhone,
        'email': site.contacts.email,
        'address': {
          '@type': 'PostalAddress',
          'streetAddress': site.location.address,
          'addressLocality': site.location.city,
          'addressRegion': site.location.region,
          'addressCountry': 'IN'
        },
        'geo': {
          '@type': 'GeoCoordinates',
          'latitude': site.location.geo.latitude,
          'longitude': site.location.geo.longitude
        },
        'areaServed': [
          { '@type': 'City', 'name': 'Delhi' },
          { '@type': 'AdministrativeArea', 'name': 'Delhi NCR' },
          { '@type': 'Country', 'name': 'India' }
        ],
        'numberOfEmployees': {
          '@type': 'QuantitativeValue',
          'value': site.teamCount
        },
        'founders': [
          { '@type': 'Person', 'name': 'Vikas Jain', 'jobTitle': 'Director' },
          { '@type': 'Person', 'name': 'Pushpendra', 'jobTitle': 'Co-Founder' }
        ],
        'sameAs': [
          'https://www.linkedin.com/company/marketingsetu'
        ]
      },
      {
        '@type': 'WebSite',
        '@id': `${site.url}/#website`,
        'url': site.url,
        'name': site.name,
        'publisher': { '@id': `${site.url}/#organization` }
      },
      {
        '@type': 'FAQPage',
        '@id': `${site.url}/#faq`,
        'mainEntity': faqs.map(f => ({
          '@type': 'Question',
          'name': f.q,
          'acceptedAnswer': {
            '@type': 'Answer',
            'text': f.a
          }
        }))
      }
    ]
  };

  const head = renderHead({
    title: 'Digital Marketing Agency in Delhi | Performance, SEO & Web',
    description: 'Marketing Setu is Delhi\'s premier digital marketing agency. 15 in-house specialists delivering high-ROAS Google Ads, Meta Ads, SEO, AEO, and award-worthy web design.',
    canonicalPath: '',
    schema,
    relPrefix: ''
  });

  const nav = renderNav({ currentPath: 'home', relPrefix: '' });

  const body = `
  <main id="main-content">
    <!-- SECTION 01: IMMERSIVE HERO WITH 3D WEBGL GROWTH CANVAS & DUAL-COLUMN STAGE -->
    <section class="hero-section" aria-label="Hero Introduction">
      <div class="hero-glow-orb hero-glow-1"></div>
      <div class="hero-glow-orb hero-glow-2"></div>

      <div class="container">
        <div class="hero-grid-split">
          <!-- Left Column: Kinetic Typography & CTAs -->
          <div class="hero-content-wrap">
            <div class="hero-tag-pill">
              <span class="pulse-dot"></span>
              <span>Delhi's Premier Digital Growth Agency</span>
              <span style="color: rgba(255,255,255,0.25);">|</span>
              <span style="color: var(--orange-bright);">From Strategy to Growth</span>
            </div>

            <h1 class="hero-headline">
              <span class="hero-word">We</span> <span class="hero-word">Don't</span> <span class="hero-word">Just</span> <span class="hero-word hero-serif-accent">Market</span> <span class="hero-word">Brands.</span><br>
              <span class="hero-word">We</span> <span class="hero-word">Move</span> <span class="hero-word">Them</span> <span class="hero-word highlight-orange">Forward.</span>
            </h1>

            <p class="hero-subheadline">
              ${site.heroSubheadline}
            </p>

            <!-- Interactive Growth Pillar Switcher Chips -->
            <div class="hero-pillar-nav" role="tablist" aria-label="Core Growth Pillars">
              <button class="hero-pillar-btn active" data-pillar="paid-ads" role="tab" aria-selected="true">
                <span class="pillar-icon">🎯</span>
                <span>Paid Ads (Google &amp; Meta)</span>
              </button>
              <button class="hero-pillar-btn" data-pillar="seo" role="tab" aria-selected="false">
                <span class="pillar-icon">🔍</span>
                <span>SEO &amp; AI Overview</span>
              </button>
              <button class="hero-pillar-btn" data-pillar="web-app" role="tab" aria-selected="false">
                <span class="pillar-icon">⚡</span>
                <span>Web &amp; App Dev</span>
              </button>
              <button class="hero-pillar-btn" data-pillar="branding" role="tab" aria-selected="false">
                <span class="pillar-icon">🎨</span>
                <span>Creative &amp; Branding</span>
              </button>
            </div>

            <div class="hero-cta-group">
              <button class="btn btn-primary btn-lg" data-open-modal="true" data-service="Growth Strategy Consultation">
                <span>Let's Grow Your Brand</span>
                <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
              </button>
              <a href="#services-universe" class="btn btn-secondary btn-lg">
                <span>Explore 20 Services</span>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m19 9-7 7-7-7"/></svg>
              </a>
            </div>

            <!-- Hero Stats Ticker -->
            <div class="hero-stats-ticker">
              <div class="hero-stat-item">
                <span class="hero-stat-num counter-animate" data-target="15" data-suffix=" In-House">15</span>
                <span class="hero-stat-label">Multidisciplinary Specialists</span>
              </div>
              <div class="hero-stat-item">
                <span class="hero-stat-num counter-animate" data-target="4.8" data-suffix="x">4.8x</span>
                <span class="hero-stat-label">Average Client ROAS</span>
              </div>
              <div class="hero-stat-item">
                <span class="hero-stat-num"><span class="num-accent">₹4.8Cr+</span></span>
                <span class="hero-stat-label">Pipeline Influenced</span>
              </div>
              <div class="hero-stat-item">
                <span class="hero-stat-num"><span class="num-accent">Delhi</span>, IN</span>
                <span class="hero-stat-label">Global Strategic Reach</span>
              </div>
            </div>
          </div>

          <!-- Right Column: Unobstructed 3D WebGL Growth Canvas & Corner Floating Glass Badges -->
          <div class="hero-visual-stage">
            <canvas id="hero-webgl-canvas"></canvas>

            <!-- Floating Glass Badge Top Right -->
            <div class="hero-float-card hero-float-card-top">
              <div class="float-card-header">
                <span class="float-card-title">Live Performance Metric</span>
                <span class="float-card-badge" id="hero-dynamic-badge">▲ +340% Lift</span>
              </div>
              <div class="float-card-val" id="hero-dynamic-val">4.8x ROAS</div>
              <div class="float-card-sub" id="hero-dynamic-sub" style="margin-top: 0.3rem;">Google Search &amp; PMax Scaled Funnels</div>
              <svg width="200" height="32" viewBox="0 0 200 32" style="margin-top: 0.5rem; overflow: visible;">
                <defs>
                  <linearGradient id="chartGrad" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stop-color="#38BDF8" />
                    <stop offset="100%" stop-color="#FF6500" />
                  </linearGradient>
                </defs>
                <path d="M 0 28 Q 50 24, 90 16 T 160 8 T 200 2" fill="none" stroke="url(#chartGrad)" stroke-width="2.5" stroke-linecap="round" />
                <circle cx="200" cy="2" r="4" fill="#FF7A18" />
              </svg>
            </div>

            <!-- Floating Glass Badge Bottom Left -->
            <div class="hero-float-card hero-float-card-bottom">
              <div class="float-card-header">
                <span class="float-card-title">AI Engine Discovery</span>
                <span class="float-card-badge" id="hero-dynamic-tag-badge" style="background: rgba(56, 189, 248, 0.18); color: #38BDF8; border-color: rgba(56, 189, 248, 0.35);">AEO Ready</span>
              </div>
              <div class="float-card-val" id="hero-dynamic-tag-val" style="font-size: 1.15rem;">Perplexity • Claude • ChatGPT</div>
              <div class="float-card-sub" id="hero-dynamic-tag-sub" style="margin-top: 0.2rem;">#1 Brand Citations &amp; Semantic Graph</div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- INFINITE KINETIC MARQUEE RIBBON -->
    <div class="marquee-ribbon" aria-hidden="true">
      <div class="marquee-track">
        <span class="marquee-item"><span class="star-icon">✦</span> HIGH-ROAS GOOGLE & META ADS</span>
        <span class="marquee-item"><span class="star-icon">✦</span> 15 IN-HOUSE SPECIALISTS IN DELHI</span>
        <span class="marquee-item"><span class="star-icon">✦</span> TOPICAL SEO & AI ANSWER ENGINES (AEO)</span>
        <span class="marquee-item"><span class="star-icon">✦</span> CREATIVE SHORT-FORM REELS & 3D MOTION</span>
        <span class="marquee-item"><span class="star-icon">✦</span> BESPOKE HIGH-SPEED WEB ENGINEERING</span>
        <span class="marquee-item"><span class="star-icon">✦</span> B2B LEAD GENERATION PIPELINES</span>
        <span class="marquee-item"><span class="star-icon">✦</span> FROM STRATEGY TO GROWTH</span>
        <span class="marquee-item"><span class="star-icon">✦</span> HIGH-ROAS GOOGLE & META ADS</span>
        <span class="marquee-item"><span class="star-icon">✦</span> 15 IN-HOUSE SPECIALISTS IN DELHI</span>
        <span class="marquee-item"><span class="star-icon">✦</span> TOPICAL SEO & AI ANSWER ENGINES (AEO)</span>
        <span class="marquee-item"><span class="star-icon">✦</span> CREATIVE SHORT-FORM REELS & 3D MOTION</span>
        <span class="marquee-item"><span class="star-icon">✦</span> BESPOKE HIGH-SPEED WEB ENGINEERING</span>
        <span class="marquee-item"><span class="star-icon">✦</span> B2B LEAD GENERATION PIPELINES</span>
        <span class="marquee-item"><span class="star-icon">✦</span> FROM STRATEGY TO GROWTH</span>
      </div>
    </div>

    <!-- SECTION 02: ANIMATED INTRODUCTION (SPLIT SCREEN) -->
    <section id="intro-section" class="section section-dark">
      <div class="container">
        <div class="intro-grid">
          <div class="intro-left">
            <span class="section-badge">✦ Strategic Foundation</span>
            <h2 class="section-title">
              Ideas That Connect.<br>
              <span class="highlight-orange">Strategies That Deliver.</span>
            </h2>
            <p style="font-size: 1.15rem; line-height: 1.75; margin-bottom: 1.4rem;">
              Based in the heart of Delhi, <strong>Marketing Setu</strong> was founded on a simple conviction: modern brands don't need another generic marketing checklist — they need an ambitious growth bridge connecting their boldest ideas to predictable, measurable revenue.
            </p>
            <p style="color: var(--text-muted); font-size: 1rem; line-height: 1.75;">
              Our 15-member team unites elite media buyers, technical SEO architects, creative motion designers, and web engineers under one collaborative roof. No fragmented handoffs. No outsourced guesswork. Just synchronized full-funnel execution.
            </p>
            <div style="margin-top: 2rem; display: flex; gap: 1rem; align-items: center;">
              <a href="about.html" class="btn btn-outline-orange">
                <span>Meet Our Team & Philosophy</span>
                <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
              </a>
            </div>
          </div>

          <div class="intro-right-card">
            <h3 style="margin-bottom: 1rem; font-size: 1.5rem;">The Marketing Setu Standard</h3>
            <p style="color: var(--text-muted); font-size: 0.94rem; margin-bottom: 2rem;">
              We eliminate the friction between creative storytelling and hard financial metrics.
            </p>

            <div class="intro-feature-list">
              <div class="intro-feature-item">
                <div class="intro-feature-icon">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                </div>
                <div>
                  <h4 style="font-size: 1.1rem; margin-bottom: 0.3rem;">Commercial Revenue Alignment</h4>
                  <p style="font-size: 0.9rem; color: var(--text-muted); margin: 0;">We measure success by pipeline generated, deal sizes closed, and net ROAS — never meaningless vanity traffic.</p>
                </div>
              </div>

              <div class="intro-feature-item">
                <div class="intro-feature-icon">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m12 6 4 6-4 6-4-6z"/></svg>
                </div>
                <div>
                  <h4 style="font-size: 1.1rem; margin-bottom: 0.3rem;">15-Specialist Cohesive Force</h4>
                  <p style="font-size: 0.9rem; color: var(--text-muted); margin: 0;">Dedicated directors Vikas Jain, Pushpendra, and Manish Bhagel personally architect and steer your accounts.</p>
                </div>
              </div>

              <div class="intro-feature-item">
                <div class="intro-feature-icon">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3Z"/></svg>
                </div>
                <div>
                  <h4 style="font-size: 1.1rem; margin-bottom: 0.3rem;">AEO & 2026 AI Search Preparedness</h4>
                  <p style="font-size: 0.9rem; color: var(--text-muted); margin: 0;">Engineered to ensure your brand is cited authoritatively in Perplexity, Claude, ChatGPT, and Google AI Overviews.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- SECTION 03: INTERACTIVE SERVICES UNIVERSE (BENTO GRID) -->
    <section id="services-universe" class="section section-light">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ Capabilities Matrix</span>
          <h2 class="section-title">
            The Interactive <span class="highlight-orange">Services Universe</span>
          </h2>
          <p class="section-subtitle">
            Explore 20 specialized disciplines spanning organic search discovery, performance media, cinematic motion, and high-conversion engineering.
          </p>
        </div>

        <!-- Filter Pills -->
        <div class="services-filter-bar" role="tablist" aria-label="Services Category Filters">
          <button class="filter-btn active" data-filter="all">All 20 Services</button>
          <button class="filter-btn" data-filter="Search & Discovery">Search & Discovery</button>
          <button class="filter-btn" data-filter="Paid Media & Ads">Paid Media & Ads</button>
          <button class="filter-btn" data-filter="Creative & Brand">Creative & Brand</button>
          <button class="filter-btn" data-filter="Performance & Tech">Performance & Tech</button>
        </div>

        <!-- Real-Time Search -->
        <div class="services-search-box">
          <label for="home-services-search" class="sr-only">Search Services</label>
          <svg class="services-search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
          <input type="search" id="home-services-search" name="services_query" placeholder="Search by service or keyword (e.g. SEO, PMax, Reels, UI/UX)..." class="services-search-input">
        </div>

        <!-- Bento Grid -->
        <div class="bento-services-grid">
          ${services.map((s, idx) => `
            <article class="bento-card ${idx === 0 ? 'bento-card-featured' : ''}" data-category="${escapeHtml(s.pillar)}">
              <div>
                <div class="bento-card-header">
                  <div class="bento-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24">${s.svgPath}</svg>
                  </div>
                  <div class="bento-metric-badge">
                    <span>${s.metric.value} ${s.metric.label}</span>
                  </div>
                </div>

                <span class="section-badge-navy" style="display:inline-block; font-size:0.72rem; padding:0.25rem 0.65rem; margin-bottom:0.75rem; border-radius:4px;">${s.pillar}</span>
                <h3 class="bento-title">${escapeHtml(s.title)}</h3>
                <p class="bento-desc">${escapeHtml(s.shortDesc)}</p>

                <div class="bento-deliverables-pill-group">
                  ${s.deliverables.slice(0, 3).map(d => `<span class="bento-deliverable-pill">✓ ${escapeHtml(d.title)}</span>`).join('')}
                </div>
              </div>

              <div class="bento-card-footer">
                <a href="services/${s.slug}.html" class="bento-link">
                  <span>Explore Service Blueprint</span>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
              </div>
            </article>
          `).join('\n')}
        </div>
      </div>
    </section>

    <!-- SECTION 04: OUR CREATIVE APPROACH (4-STEP SCROLL-DRIVEN JOURNEY) -->
    <section class="section section-light" style="background-color: #F1F5F9 !important;">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ Systematic Execution</span>
          <h2 class="section-title">
            Our Four-Stage <span class="highlight-orange">Growth Engine</span>
          </h2>
          <p class="section-subtitle">
            From forensic auditing to scaled performance. Every client journey follows a disciplined, battle-tested methodology.
          </p>
        </div>

        <div class="approach-journey-wrap">
          <!-- Animated Trajectory Line -->
          <svg class="approach-svg-trajectory" viewBox="0 0 4 1000" preserveAspectRatio="none">
            <defs>
              <linearGradient id="orangeTrajectoryGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#FF6500" />
                <stop offset="100%" stop-color="#FF8A00" />
              </linearGradient>
            </defs>
            <line x1="2" y1="0" x2="2" y2="1000" class="trajectory-line-base" />
            <line x1="2" y1="0" x2="2" y2="1000" class="trajectory-line-fill" />
          </svg>

          <div class="approach-step-list">
            <!-- Step 1 -->
            <div class="approach-step-card active">
              <div class="step-node-col">
                <div class="step-number-circle">01</div>
              </div>
              <div class="step-content-card">
                <div class="step-phase-badge">Phase 01 • Deep Diagnostic</div>
                <h3 class="step-title">Forensic Audit & Commercial Discovery</h3>
                <p class="step-desc">
                  We dismantle your current conversion funnel, tracking setup, competitor ad libraries, and search rankings to uncover hidden revenue leaks and untapped commercial keywords.
                </p>
                <div class="step-highlights-grid">
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Server-Side CAPI & Pixel Health Check</div>
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Competitor Spend & Angle Reverse-Engineering</div>
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Core Web Vitals & Technical Crawl</div>
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> ICP & Decision-Maker Pain Point Mapping</div>
                </div>
              </div>
            </div>

            <!-- Step 2 -->
            <div class="approach-step-card">
              <div class="step-node-col">
                <div class="step-number-circle">02</div>
              </div>
              <div class="step-content-card">
                <div class="step-phase-badge">Phase 02 • Architecture</div>
                <h3 class="step-title">Strategic Blueprint & Creative Formulation</h3>
                <p class="step-desc">
                  We formulate your 90-day growth roadmap: defining high-intent search clusters, ad creative hook concepts, conversion landing pages, and target cost-per-acquisition thresholds.
                </p>
                <div class="step-highlights-grid">
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Multi-Tier Campaign Budget Allocation</div>
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Video Scripting & Static Creative Wireframing</div>
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Semantic Topic Cluster Architecture</div>
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Lead Qualification Workflow Setup</div>
                </div>
              </div>
            </div>

            <!-- Step 3 -->
            <div class="approach-step-card">
              <div class="step-node-col">
                <div class="step-number-circle">03</div>
              </div>
              <div class="step-content-card">
                <div class="step-phase-badge">Phase 03 • Deployment</div>
                <h3 class="step-title">Agile Execution & Live Campaign Activation</h3>
                <p class="step-desc">
                  Our in-house 15 specialists launch bespoke ad creatives, high-speed landing pages, schema-optimized articles, and bid management algorithms without delay.
                </p>
                <div class="step-highlights-grid">
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Full Creative Suite Rollout (Reels + Carousels)</div>
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Negative Keyword Shields Applied</div>
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> High-Converting Landing Page Live Testing</div>
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Instant CRM & WhatsApp Lead Routing</div>
                </div>
              </div>
            </div>

            <!-- Step 4 -->
            <div class="approach-step-card">
              <div class="step-node-col">
                <div class="step-number-circle">04</div>
              </div>
              <div class="step-content-card">
                <div class="step-phase-badge">Phase 04 • Compounding</div>
                <h3 class="step-title">Relentless Optimization & Scale</h3>
                <p class="step-desc">
                  Performance is an iterative discipline. We analyze search query logs, perform creative hook testing, tune target CPA bids, and scale profitable ad spend sustainably.
                </p>
                <div class="step-highlights-grid">
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Weekly Creative Fatigue Monitoring</div>
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Scientific A/B Headline & Offer Testing</div>
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Real-Time Looker Studio Executive Dashboards</div>
                  <div class="step-highlight-item"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Direct Strategic Consultation with Directors</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- SECTION 05: WHY MARKETING SETU (EDITORIAL PILLARS) -->
    <section class="section section-navy">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ The Setu Advantage</span>
          <h2 class="section-title">
            Why Ambitious Brands <span class="highlight-orange">Partner With Us</span>
          </h2>
          <p class="section-subtitle">
            We reject the outdated agency playbook of vague vanity reports and junior account managers. Here is how we build lasting market leadership.
          </p>
        </div>

        <div class="why-grid">
          <div class="why-card">
            <div class="why-card-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            </div>
            <h3 class="why-card-title">Tailored Digital Strategies</h3>
            <p class="why-card-desc">
              No pre-packaged cookie-cutter formulas. Every strategy is engineered specifically around your industry unit economics, competitive moat, and customer acquisition payback periods.
            </p>
          </div>

          <div class="why-card">
            <div class="why-card-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            </div>
            <h3 class="why-card-title">Creative & Technical Depth</h3>
            <p class="why-card-desc">
              We bridge the gap between arresting artistic visual identity and hardcore technical infrastructure: Core Web Vitals, server-side tracking, schema markup, and high-performance code.
            </p>
          </div>

          <div class="why-card">
            <div class="why-card-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
            </div>
            <h3 class="why-card-title">Data-Informed Decisions</h3>
            <p class="why-card-desc">
              Every marketing rupee spent is accounted for with rigorous first-party attribution modeling. We allocate capital based on verifiable conversion data rather than subjective opinions.
            </p>
          </div>

          <div class="why-card">
            <div class="why-card-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            </div>
            <h3 class="why-card-title">15-Specialist Multidisciplinary Team</h3>
            <p class="why-card-desc">
              Your account benefits from a dedicated roster of media buyers, copywriters, graphic designers, video editors, and developers collaborating seamlessly in real time.
            </p>
          </div>

          <div class="why-card">
            <div class="why-card-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            </div>
            <h3 class="why-card-title">Transparent Communication</h3>
            <p class="why-card-desc">
              Direct access via dedicated WhatsApp groups and weekly strategic video reviews. You always know exactly what was executed, what succeeded, and what we are optimizing next.
            </p>
          </div>

          <div class="why-card">
            <div class="why-card-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 14 14"/></svg>
            </div>
            <h3 class="why-card-title">Business-Focused Execution</h3>
            <p class="why-card-desc">
              We align our KPIs with your business objectives: lowering customer acquisition costs, accelerating pipeline velocity, and maximizing bottom-line profitability.
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- SECTION 06: INDUSTRIES WE SERVE -->
    <section class="section section-dark">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ Specialized Focus</span>
          <h2 class="section-title">
            Industries We Are Built <span class="highlight-orange">To Scale</span>
          </h2>
          <p class="section-subtitle">
            Sector-specific playbooks tailored to unique commercial buyer journeys, regulatory compliance, and conversion dynamics.
          </p>
        </div>

        <div class="industries-grid">
          ${industries.map(ind => `
            <div class="industry-card">
              <div>
                <div class="industry-tag">${ind.tag}</div>
                <h3 class="industry-title">${ind.title}</h3>
                <p class="industry-desc">${ind.shortDesc}</p>
              </div>
              <div class="industry-metric-wrap">
                <div class="industry-metric-val">${ind.metric}</div>
                <div class="industry-metric-label">${ind.metricLabel}</div>
              </div>
            </div>
          `).join('\n')}
        </div>
      </div>
    </section>

    <!-- SECTION 07: LEADERSHIP & CORE TEAM -->
    <section class="section section-dark">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ Strategic Leadership</span>
          <h2 class="section-title">
            Meet The <span class="highlight-orange">Leadership Team</span>
          </h2>
          <p class="section-subtitle">
            Authentic industry specialists guiding Marketing Setu's 15-member team from our Delhi headquarters.
          </p>
        </div>

        <div class="team-grid">
          ${site.leadership.map(m => `
            <div class="team-card">
              <div class="team-avatar-wrap">
                <span class="team-avatar-initials">${m.name.split(' ').map(n => n[0]).join('')}</span>
              </div>
              <h3 class="team-name">${m.name}</h3>
              <div class="team-role-pill">${m.title}</div>
              <p class="team-bio">${m.bio}</p>
              <div class="team-focus-tags">
                ${m.focus.map(f => `<span class="team-focus-tag">${f}</span>`).join('')}
              </div>
            </div>
          `).join('\n')}
        </div>
      </div>
    </section>

    <!-- SECTION 09: GROWTH SIMULATOR / INTERACTIVE ROI CALCULATOR -->
    <section class="section section-navy">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ Interactive Modeling</span>
          <h2 class="section-title">
            Project Your <span class="highlight-orange">Revenue Velocity</span>
          </h2>
          <p class="section-subtitle">
            Use our interactive growth simulator to estimate qualified inquiries, customer reach, and pipeline value based on real industry acquisition benchmarks.
          </p>
        </div>

        <div class="roi-calc-container">
          <!-- Left: Controls -->
          <div>
            <h3 style="margin-bottom: 1.8rem; font-size: 1.5rem;">Configure Your Growth Model</h3>

            <div class="calc-control-group">
              <div class="calc-label-row">
                <span class="calc-label">Monthly Ad Spend Budget</span>
                <span id="calc-spend-display" class="calc-current-val">₹75,000/mo</span>
              </div>
              <input type="range" id="calc-spend-slider" min="25000" max="1000000" step="10000" value="75000" class="calc-range-slider" aria-label="Monthly Ad Budget Slider">
              <div style="display: flex; justify-content: space-between; font-size: 0.75rem; color: #64748B; margin-top: 0.4rem; font-family: var(--font-mono);">
                <span>₹25,000 (Starter)</span>
                <span>₹5,00,000 (Growth)</span>
                <span>₹10,00,000 (Enterprise)</span>
              </div>
            </div>

            <div class="calc-control-group">
              <div class="calc-label-row">
                <span class="calc-label">Your Target Industry</span>
              </div>
              <select id="calc-industry-select" class="calc-select-input" aria-label="Target Industry">
                <option value="b2b">B2B & Professional Services</option>
                <option value="ecommerce">E-commerce & D2C Retail</option>
                <option value="healthcare">Healthcare & Specialized Clinics</option>
                <option value="realestate">Real Estate & Luxury Developers</option>
                <option value="education">Education & EdTech Institutes</option>
                <option value="local">Local Delhi-NCR Businesses</option>
              </select>
            </div>

            <div class="calc-control-group">
              <div class="calc-label-row">
                <span class="calc-label">Primary Strategy Model</span>
              </div>
              <select id="calc-channel-select" class="calc-select-input" aria-label="Strategy Model">
                <option value="omnichannel">Omnichannel (Google Search + Meta Ads + SEO)</option>
                <option value="google">Google High-Intent Search & Performance Max</option>
                <option value="meta">Meta Creative Social & Video Funnels</option>
              </select>
            </div>
          </div>

          <!-- Right: Dynamic Projected Output -->
          <div class="calc-output-card">
            <h4 style="font-size: 1.2rem; margin-bottom: 1.5rem;">Estimated Monthly Performance</h4>

            <div class="calc-metrics-grid">
              <div class="calc-metric-box">
                <div class="calc-metric-title">Estimated Reach</div>
                <div id="calc-reach-val" class="calc-metric-number">120K+</div>
              </div>

              <div class="calc-metric-box">
                <div class="calc-metric-title">High-Intent Clicks</div>
                <div id="calc-clicks-val" class="calc-metric-number">1,650+</div>
              </div>

              <div class="calc-metric-box">
                <div class="calc-metric-title">Sales-Qualified Leads</div>
                <div id="calc-leads-val" class="calc-metric-number" style="color: var(--orange-bright);">79</div>
              </div>

              <div class="calc-metric-box">
                <div class="calc-metric-title">Target Return Multiple</div>
                <div id="calc-roi-val" class="calc-metric-number">5.5x</div>
              </div>

              <div class="calc-metric-box calc-roi-highlight">
                <div class="calc-metric-title">Projected Monthly Pipeline Value</div>
                <div id="calc-pipeline-val" class="calc-metric-number">₹4.1 Lakh</div>
                <p style="font-size: 0.78rem; color: #94A3B8; margin-top: 0.4rem;">Based on calibrated industry conversion benchmarks and disciplined ad spend management.</p>
              </div>
            </div>

            <button id="calc-claim-btn" class="btn btn-primary" style="width: 100%;">
              <span>Claim This Custom Growth Blueprint</span>
              <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
            </button>
          </div>
        </div>
      </div>
    </section>

    <!-- SECTION 10: INSIGHTS & IDEAS -->
    <section class="section section-light">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ Strategic Insights</span>
          <h2 class="section-title">
            Latest Ideas & <span class="highlight-orange">Search Analysis</span>
          </h2>
          <p class="section-subtitle">
            Deep-dive frameworks, AI search updates, and performance marketing strategies written directly by our practitioners.
          </p>
        </div>

        <div class="blog-cards-grid">
          ${blogs.slice(0, 3).map(b => `
            <article class="blog-card">
              <div class="blog-thumb-wrap">
                <span class="blog-badge-tag">${b.category}</span>
                <div style="font-family: var(--font-heading); font-size: 1.4rem; font-weight: 800; color: #FFFFFF; text-align: center; max-width: 80%;">
                  ${b.title.split(':')[0]}
                </div>
              </div>
              <div class="blog-content">
                <div class="blog-meta-row">
                  <span>${b.date}</span>
                  <span>•</span>
                  <span>${b.readTime}</span>
                </div>
                <h3 class="blog-title">
                  <a href="blog/${b.slug}.html">${escapeHtml(b.title)}</a>
                </h3>
                <p class="blog-excerpt">${escapeHtml(b.metaDesc)}</p>
                <a href="blog/${b.slug}.html" class="blog-footer-link">
                  <span>Read Full Article</span>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
              </div>
            </article>
          `).join('\n')}
        </div>

        <div style="text-align: center; margin-top: 3.5rem;">
          <a href="blog.html" class="btn btn-secondary">
            <span>Explore All 5 Master Articles</span>
            <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
          </a>
        </div>
      </div>
    </section>

    <!-- SECTION 11: INTERACTIVE FAQ ACCORDION -->
    <section class="section section-light" style="background-color: #F1F5F9 !important;">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ Direct Answers</span>
          <h2 class="section-title">
            Frequently Asked <span class="highlight-orange">Questions</span>
          </h2>
          <p class="section-subtitle">
            Transparent answers regarding our fees, methodologies, timelines, and Delhi agency delivery standards.
          </p>
        </div>

        <div class="faq-accordion-wrap">
          ${faqs.map((f, idx) => `
            <div class="faq-item ${idx === 0 ? 'active' : ''}">
              <button class="faq-question-btn" aria-expanded="${idx === 0 ? 'true' : 'false'}">
                <span>${escapeHtml(f.q)}</span>
                <span class="faq-icon-toggle">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
                </span>
              </button>
              <div class="faq-answer-pane" ${idx === 0 ? 'style="max-height: 250px;"' : ''}>
                <div class="faq-answer-inner">
                  ${escapeHtml(f.a)}
                </div>
              </div>
            </div>
          `).join('\n')}
        </div>
      </div>
    </section>

    <!-- SECTION 12: FINAL CONVERSION EXPERIENCE -->
    <section class="section conversion-section">
      <div class="container">
        <div class="conversion-box">
          <!-- Left: Copy & Contact -->
          <div>
            <span class="section-badge">✦ Ignite Your Growth</span>
            <h2 class="section-title" style="font-size: clamp(2rem, 4vw, 3.2rem);">
              Your Next Big Growth Story <span class="highlight-orange">Starts Here.</span>
            </h2>
            <p style="font-size: 1.15rem; line-height: 1.75; color: #CBD5E1; margin-bottom: 2rem;">
              Let's turn ambitious ideas into meaningful digital experiences and stronger marketing performance. Schedule an executive strategy session with our Delhi directors today.
            </p>

            <div style="display: flex; flex-direction: column; gap: 1.2rem; margin-bottom: 2.5rem;">
              <div style="display: flex; align-items: center; gap: 0.85rem;">
                <div style="width: 38px; height: 38px; border-radius: 50%; background: rgba(255,101,0,0.15); display: flex; align-items: center; justify-content: center; color: var(--orange-bright);">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                </div>
                <div>
                  <div style="font-size: 0.8rem; color: #94A3B8;">Primary Direct Line</div>
                  <a href="tel:${site.contacts.primaryPhone}" style="font-family: var(--font-mono); font-weight: 700; color: #FFFFFF;">${site.contacts.primaryPhoneDisplay}</a>
                </div>
              </div>

              <div style="display: flex; align-items: center; gap: 0.85rem;">
                <div style="width: 38px; height: 38px; border-radius: 50%; background: rgba(37,211,102,0.15); display: flex; align-items: center; justify-content: center; color: #25D366;">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2m.01 1.67c2.2 0 4.26.86 5.82 2.42a8.225 8.225 0 0 1 2.41 5.83c0 4.54-3.7 8.24-8.24 8.24-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.196 8.196 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.24-8.24m4.52 11.66c-.19.53-1.11 1.04-1.54 1.09-.41.05-.93.07-2.69-.66-2.25-.93-3.69-3.23-3.8-3.38-.11-.15-.9-1.2-0.9-2.28 0-1.09.57-1.62.77-1.85.2-.22.45-.28.6-.28.15 0 .3 0 .43.01.14.01.33-.05.51.39.19.45.64 1.56.7 1.67.06.11.1.25.02.4-.07.15-.11.25-.22.38-.11.13-.24.29-.34.39-.11.11-.23.23-.1.45.13.22.58.96 1.25 1.55.86.77 1.59 1.01 1.81 1.12.22.11.35.1.48-.05.13-.15.56-.65.71-.88.15-.22.3-.19.51-.11.2.07 1.3.61 1.52.72.22.11.37.17.43.26.05.1.05.57-.14 1.1z"/></svg>
                </div>
                <div>
                  <div style="font-size: 0.8rem; color: #94A3B8;">Direct WhatsApp Chat</div>
                  <a href="${site.contacts.whatsappUrl}" target="_blank" rel="noopener noreferrer" style="font-family: var(--font-mono); font-weight: 700; color: #25D366;">Instant Response Team</a>
                </div>
              </div>
            </div>
          </div>

          <!-- Right: Direct Lead Form -->
          <div>
            <form data-ms-form="true" action="api/contact-handler.php" method="POST" class="conversion-form">
              <input type="text" name="_ms_hp" class="ms-hp-field" tabindex="-1" autocomplete="off">

              <div class="form-row-2">
                <div class="form-group">
                  <label for="home-lead-name" class="form-label">Full Name *</label>
                  <input type="text" id="home-lead-name" name="full_name" required placeholder="Vikas Sharma" autocomplete="name" class="form-input">
                </div>
                <div class="form-group">
                  <label for="home-lead-biz" class="form-label">Business Name</label>
                  <input type="text" id="home-lead-biz" name="business_name" placeholder="Acme Enterprises" autocomplete="organization" class="form-input">
                </div>
              </div>

              <div class="form-row-2">
                <div class="form-group">
                  <label for="home-lead-email" class="form-label">Work Email *</label>
                  <input type="email" id="home-lead-email" name="email" required placeholder="name@company.com" autocomplete="email" class="form-input">
                </div>
                <div class="form-group">
                  <label for="home-lead-phone" class="form-label">Phone / WhatsApp *</label>
                  <input type="tel" id="home-lead-phone" name="phone" required placeholder="+91 98765 43210" autocomplete="tel" class="form-input">
                </div>
              </div>

              <div class="form-row-2">
                <div class="form-group">
                  <label for="home-lead-service" class="form-label">Required Service</label>
                  <select id="home-lead-service" name="service" class="form-select">
                    <option value="General Growth Consultation">General Growth Consultation</option>
                    ${services.map(s => `<option value="${s.title}">${s.title}</option>`).join('\n')}
                  </select>
                </div>
                <div class="form-group">
                  <label for="home-lead-budget" class="form-label">Monthly Ad Budget</label>
                  <select id="home-lead-budget" name="budget" class="form-select">
                    <option value="Exploring Options">Exploring Options</option>
                    <option value="₹30,000 - ₹75,000">₹30,000 – ₹75,000 /mo</option>
                    <option value="₹75,000 - ₹2,00,000">₹75,000 – ₹2,00,000 /mo</option>
                    <option value="₹2,00,000 - ₹5,00,000">₹2,00,000 – ₹5,00,000 /mo</option>
                    <option value="₹5,00,000+ (Scale)">₹5,00,000+ /mo (Enterprise)</option>
                  </select>
                </div>
              </div>

              <div class="form-group">
                <label for="home-lead-message" class="form-label">Brief Description of Your Goals</label>
                <textarea id="home-lead-message" name="message" placeholder="Current challenges, targets, or specific deliverables..." class="form-textarea"></textarea>
              </div>

              <div class="form-status-msg"></div>

              <button type="submit" class="btn btn-primary btn-lg" style="width: 100%;">
                <span>Start Your Growth Journey</span>
                <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
              </button>

              <p class="form-disclaimer">
                🔒 Privacy guaranteed. Zero spam. We reply within 2 business hours.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  </main>
  `;

  const footer = renderFooter({
    relPrefix: '',
    extraScripts: [
      'assets/js/hero-3d.js',
      'assets/js/growth-calc.js'
    ]
  });

  return head + nav + body + footer;
}

module.exports = { generateHomePage };

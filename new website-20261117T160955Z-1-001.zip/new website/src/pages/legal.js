/**
 * MARKETING SETU — LEGAL PAGES (PRIVACY POLICY & TERMS)
 */

const site = require('../../data/site');
const { renderHead, renderNav, renderFooter } = require('../templates/common');

function generatePrivacyPage() {
  const head = renderHead({
    title: 'Privacy Policy | Marketing Setu',
    description: 'Privacy Policy and data protection terms for Marketing Setu. Learn how we collect, protect, and process client information.',
    canonicalPath: 'privacy-policy.html',
    relPrefix: ''
  });

  const nav = renderNav({ currentPath: 'privacy', relPrefix: '' });

  const body = `
  <main id="main-content">
    <section class="section section-dark" style="padding-top: 9rem; padding-bottom: 5rem;">
      <div class="container" style="max-width: 860px;">
        <span class="section-badge">✦ Compliance & Security</span>
        <h1 style="margin-bottom: 1.5rem; font-size: 2.8rem;">Privacy Policy</h1>
        <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 2.5rem;">Effective Date: November 15, 2026 • Last Updated: November 17, 2026</p>

        <div class="article-body">
          <p>At <strong>Marketing Setu</strong> ("we", "our", or "us"), based in Delhi, India, we are committed to safeguarding the privacy and commercial confidentiality of our clients, website visitors, and prospective partners.</p>

          <h2>1. Information We Collect</h2>
          <p>When you interact with our website, request a consultation, or submit an inquiry, we collect information including:</p>
          <ul>
            <li><strong>Contact Details:</strong> Full name, corporate email address, telephone/WhatsApp number.</li>
            <li><strong>Business Metadata:</strong> Company name, website URL, industry sector, target marketing budget, and stated growth challenges.</li>
            <li><strong>Technical Analytics:</strong> Anonymized IP addresses, browser specifications, and user interaction signals used strictly for conversion optimization.</li>
          </ul>

          <h2>2. How We Use Your Information</h2>
          <p>Your submitted data is utilized strictly to:</p>
          <ul>
            <li>Provide customized growth strategy blueprints, marketing audits, and proposals.</li>
            <li>Coordinate telephone, WhatsApp, or video consultations regarding our services.</li>
            <li>Deliver scheduled performance marketing reporting and project deliverables.</li>
            <li>Prevent automated spam submissions and ensure website security.</li>
          </ul>

          <h2>3. Confidentiality & Non-Disclosure</h2>
          <p>We treat all client revenue numbers, advertising spend parameters, and commercial strategies with strict NDA-grade confidentiality. We do not sell, rent, or lease client data to third-party data brokers or marketing lists under any circumstances.</p>

          <h2>4. Data Retention & Security</h2>
          <p>We implement industry-standard encryption, server firewalls, and restricted local data vaults to protect your records against unauthorized access, alteration, or disclosure.</p>

          <h2>5. Contact Our Privacy Officer</h2>
          <p>If you have questions regarding this Privacy Policy or wish to request data deletion, contact us at:</p>
          <p>
            <strong>Marketing Setu</strong><br>
            Email: <a href="mailto:${site.contacts.email}" style="color: var(--orange-bright);">${site.contacts.email}</a><br>
            Phone: <a href="tel:${site.contacts.primaryPhone}" style="color: var(--orange-bright);">${site.contacts.primaryPhoneDisplay}</a><br>
            Location: ${site.location.address}
          </p>
        </div>
      </div>
    </section>
  </main>`;

  const footer = renderFooter({ relPrefix: '' });
  return head + nav + body + footer;
}

function generateTermsPage() {
  const head = renderHead({
    title: 'Terms & Conditions | Marketing Setu',
    description: 'Terms and Conditions governing digital marketing, advertising management, web development, and creative consulting services by Marketing Setu.',
    canonicalPath: 'terms-conditions.html',
    relPrefix: ''
  });

  const nav = renderNav({ currentPath: 'terms', relPrefix: '' });

  const body = `
  <main id="main-content">
    <section class="section section-dark" style="padding-top: 9rem; padding-bottom: 5rem;">
      <div class="container" style="max-width: 860px;">
        <span class="section-badge">✦ Legal Terms</span>
        <h1 style="margin-bottom: 1.5rem; font-size: 2.8rem;">Terms & Conditions</h1>
        <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 2.5rem;">Effective Date: November 15, 2026 • Last Updated: November 17, 2026</p>

        <div class="article-body">
          <p>Welcome to <strong>Marketing Setu</strong>. By accessing this website or engaging our agency for digital marketing, search engine optimization, paid advertising, web design, or consulting services, you agree to these Terms and Conditions.</p>

          <h2>1. Professional Agency Services</h2>
          <p>Marketing Setu provides multidisciplinary digital marketing and web engineering services. All engagements are governed by formal client service agreements, statements of work (SOW), and approved project timelines.</p>

          <h2>2. Account & Asset Ownership</h2>
          <p>Clients retain 100% full ownership of their advertising accounts (Google Ads, Meta Business Manager, LinkedIn Campaign Manager), domain registrations, and brand intellectual property. Marketing Setu operates with delegated administrative or partner access.</p>

          <h2>3. Advertising Spend & Third-Party Platforms</h2>
          <p>Advertising spend is paid directly by the client to the advertising platforms (Google, Meta, LinkedIn, etc.) via their connected payment methods unless explicitly stated otherwise in a written enterprise agreement.</p>

          <h2>4. Realistic Performance Guarantees</h2>
          <p>Marketing Setu adheres to rigorous, industry-leading performance marketing and SEO practices. However, because search engine algorithms, auction competition, and ad platform policies remain under the control of third parties (Google, Meta, OpenAI), ethical agencies cannot guarantee specific #1 organic search rankings or exact conversion volumes.</p>

          <h2>5. Governing Law & Jurisdiction</h2>
          <p>These terms and any client agreements shall be governed by and construed in accordance with the laws of India, with exclusive jurisdiction resting in the courts of Delhi, India.</p>

          <h2>6. Inquiries & Notices</h2>
          <p>For inquiries regarding client agreements or these terms, contact:</p>
          <p>
            <strong>Marketing Setu</strong><br>
            Email: <a href="mailto:${site.contacts.email}" style="color: var(--orange-bright);">${site.contacts.email}</a><br>
            Phone: <a href="tel:${site.contacts.primaryPhone}" style="color: var(--orange-bright);">${site.contacts.primaryPhoneDisplay}</a>
          </p>
        </div>
      </div>
    </section>
  </main>`;

  const footer = renderFooter({ relPrefix: '' });
  return head + nav + body + footer;
}

module.exports = {
  generatePrivacyPage,
  generateTermsPage
};

/**
 * MARKETING SETU — CAPABILITIES & SELECTED WORK TEMPLATE
 */

const site = require('../../data/site');
const { renderHead, renderNav, renderFooter, escapeHtml } = require('../templates/common');

function generatePortfolioPage() {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'CollectionPage',
    'name': 'Capabilities & Strategic Disciplines | Marketing Setu Delhi',
    'description': 'Explore Marketing Setu\'s strategic frameworks, campaign architectures, and creative disciplines across performance marketing and web engineering.',
    'url': `${site.url}/portfolio.html`
  };

  const head = renderHead({
    title: 'Capabilities & Creative Disciplines | Marketing Setu',
    description: 'Explore Marketing Setu\'s creative disciplines, campaign architectures, and strategic frameworks engineered for scalable commercial growth.',
    canonicalPath: 'portfolio.html',
    schema,
    relPrefix: ''
  });

  const nav = renderNav({ currentPath: 'portfolio', relPrefix: '' });

  const body = `
  <main id="main-content">
    <section class="section section-dark" style="padding-top: 9rem; padding-bottom: 3.5rem;">
      <div class="container" style="text-align: center; max-width: 900px;">
        <span class="section-badge">✦ Strategic Disciplines</span>
        <h1 style="margin-bottom: 1.5rem; font-size: clamp(2.4rem, 5vw, 4.2rem);">
          Capabilities Engineered For <span class="highlight-orange">Market Dominance</span>
        </h1>
        <p style="font-size: 1.15rem; color: #CBD5E1; line-height: 1.7; margin-bottom: 2rem;">
          We build robust commercial growth architectures where scientific data modeling, rapid creative iteration, and award-worthy web design compound together.
        </p>
      </div>
    </section>

    <!-- Capabilities Grid -->
    <section class="section section-navy">
      <div class="container">
        <div class="capabilities-grid">
          <!-- Capability 1 -->
          <div class="capability-card">
            <div class="capability-banner">
              <div class="capability-banner-pattern"></div>
              <span class="capability-badge-pill">Paid Acquisition</span>
              <div style="font-family: var(--font-heading); font-size: 1.8rem; font-weight: 800; color: #FFFFFF; z-index: 1;">
                Full-Funnel Ads
              </div>
            </div>
            <div class="capability-body">
              <h3 style="font-size: 1.25rem; margin-bottom: 0.6rem;">Omnichannel Performance Media Architecture</h3>
              <p style="color: var(--text-muted); font-size: 0.9rem; line-height: 1.6; margin-bottom: 1.4rem;">
                Synchronized ad distribution across Google Search, Performance Max, Meta Video, and YouTube. Engineered with server-side CAPI signals and automated negative keyword filters.
              </p>
              <div class="bento-deliverables-pill-group">
                <span class="bento-deliverable-pill">Search Intent Mapping</span>
                <span class="bento-deliverable-pill">PMax Asset Tuning</span>
                <span class="bento-deliverable-pill">Target CPA Bidding</span>
              </div>
            </div>
          </div>

          <!-- Capability 2 -->
          <div class="capability-card">
            <div class="capability-banner">
              <div class="capability-banner-pattern"></div>
              <span class="capability-badge-pill">Organic Authority</span>
              <div style="font-family: var(--font-heading); font-size: 1.8rem; font-weight: 800; color: #FFFFFF; z-index: 1;">
                SEO & AEO Engine
              </div>
            </div>
            <div class="capability-body">
              <h3 style="font-size: 1.25rem; margin-bottom: 0.6rem;">Semantic Authority & AI Search Citations</h3>
              <p style="color: var(--text-muted); font-size: 0.9rem; line-height: 1.6; margin-bottom: 1.4rem;">
                Transforming brand domains into authoritative industry hubs cited by Perplexity, Claude, ChatGPT, and Google AI Overviews through semantic schema and high-intent clustering.
              </p>
              <div class="bento-deliverables-pill-group">
                <span class="bento-deliverable-pill">Topic Clustering</span>
                <span class="bento-deliverable-pill">Schema Engineering</span>
                <span class="bento-deliverable-pill">Core Web Vitals</span>
              </div>
            </div>
          </div>

          <!-- Capability 3 -->
          <div class="capability-card">
            <div class="capability-banner">
              <div class="capability-banner-pattern"></div>
              <span class="capability-badge-pill">Creative Motion</span>
              <div style="font-family: var(--font-heading); font-size: 1.8rem; font-weight: 800; color: #FFFFFF; z-index: 1;">
                Motion & Visuals
              </div>
            </div>
            <div class="capability-body">
              <h3 style="font-size: 1.25rem; margin-bottom: 0.6rem;">Thumb-Stopping Creative Motion Design</h3>
              <p style="color: var(--text-muted); font-size: 0.9rem; line-height: 1.6; margin-bottom: 1.4rem;">
                High-converting static carousels, 3D kinetic typography, and short-form video reels scripted to capture attention in the first 3 seconds and combat ad fatigue.
              </p>
              <div class="bento-deliverables-pill-group">
                <span class="bento-deliverable-pill">Reels & TikTok Ads</span>
                <span class="bento-deliverable-pill">3D Kinetic Assets</span>
                <span class="bento-deliverable-pill">Brand Guidelines</span>
              </div>
            </div>
          </div>

          <!-- Capability 4 -->
          <div class="capability-card">
            <div class="capability-banner">
              <div class="capability-banner-pattern"></div>
              <span class="capability-badge-pill">Web Engineering</span>
              <div style="font-family: var(--font-heading); font-size: 1.8rem; font-weight: 800; color: #FFFFFF; z-index: 1;">
                Bespoke Digital
              </div>
            </div>
            <div class="capability-body">
              <h3 style="font-size: 1.25rem; margin-bottom: 0.6rem;">Awwwards-Caliber Web Design & Engineering</h3>
              <p style="color: var(--text-muted); font-size: 0.9rem; line-height: 1.6; margin-bottom: 1.4rem;">
                Fast, responsive websites engineered with fluid typography, glassmorphism surfaces, GSAP scroll storytelling, and accessible microinteractions with sub-second page loads.
              </p>
              <div class="bento-deliverables-pill-group">
                <span class="bento-deliverable-pill">LCP &lt; 1.5s</span>
                <span class="bento-deliverable-pill">Fluid Motion</span>
                <span class="bento-deliverable-pill">Zero Bloat</span>
              </div>
            </div>
          </div>

          <!-- Capability 5 -->
          <div class="capability-card">
            <div class="capability-banner">
              <div class="capability-banner-pattern"></div>
              <span class="capability-badge-pill">Demand Gen</span>
              <div style="font-family: var(--font-heading); font-size: 1.8rem; font-weight: 800; color: #FFFFFF; z-index: 1;">
                B2B Lead Engine
              </div>
            </div>
            <div class="capability-body">
              <h3 style="font-size: 1.25rem; margin-bottom: 0.6rem;">High-Intent B2B Pipeline Architecture</h3>
              <p style="color: var(--text-muted); font-size: 0.9rem; line-height: 1.6; margin-bottom: 1.4rem;">
                Account-based marketing (ABM) on LinkedIn paired with bottom-of-funnel Google Search, smart qualification forms, and instant WhatsApp response routing.
              </p>
              <div class="bento-deliverables-pill-group">
                <span class="bento-deliverable-pill">ICP Definition</span>
                <span class="bento-deliverable-pill">Multi-Step Forms</span>
                <span class="bento-deliverable-pill">CRM Integration</span>
              </div>
            </div>
          </div>

          <!-- Capability 6 -->
          <div class="capability-card">
            <div class="capability-banner">
              <div class="capability-banner-pattern"></div>
              <span class="capability-badge-pill">CRO & Retention</span>
              <div style="font-family: var(--font-heading); font-size: 1.8rem; font-weight: 800; color: #FFFFFF; z-index: 1;">
                Conversion Lift
              </div>
            </div>
            <div class="capability-body">
              <h3 style="font-size: 1.25rem; margin-bottom: 0.6rem;">Scientific CRO & Lifecycle Retention</h3>
              <p style="color: var(--text-muted); font-size: 0.9rem; line-height: 1.6; margin-bottom: 1.4rem;">
                A/B split testing of offer hooks and checkout flows, combined with behavioral email lifecycle automation to maximize customer lifetime value.
              </p>
              <div class="bento-deliverables-pill-group">
                <span class="bento-deliverable-pill">Heatmap Auditing</span>
                <span class="bento-deliverable-pill">Klaviyo Automation</span>
                <span class="bento-deliverable-pill">A/B Testing</span>
              </div>
            </div>
          </div>
        </div>

        <div style="text-align: center; margin-top: 4rem;">
          <button class="btn btn-primary btn-lg" data-open-modal="true" data-service="Capabilities Assessment">
            <span>Discuss Your Brand's Growth Requirements</span>
            <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
          </button>
        </div>
      </div>
    </section>
  </main>`;

  const footer = renderFooter({ relPrefix: '' });
  return head + nav + body + footer;
}

module.exports = { generatePortfolioPage };

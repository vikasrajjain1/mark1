/**
 * MARKETING SETU — INDIVIDUAL SERVICE PAGE TEMPLATE
 * Generates an SEO-rich, comprehensive landing page for each of the 20 services.
 */

const site = require('../../data/site');
const services = require('../../data/services');
const { renderHead, renderNav, renderFooter, escapeHtml } = require('../templates/common');

function generateServiceDetailPage(service) {
  const schema = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'Service',
        '@id': `${site.url}/services/${service.slug}.html#service`,
        'name': service.title,
        'description': service.metaDesc,
        'provider': {
          '@type': 'Organization',
          'name': site.name,
          'url': site.url,
          'logo': `${site.url}/assets/images/logo.png`,
          'telephone': site.contacts.primaryPhone,
          'address': {
            '@type': 'PostalAddress',
            'streetAddress': site.location.address,
            'addressLocality': site.location.city,
            'addressCountry': 'IN'
          }
        },
        'areaServed': {
          '@type': 'City',
          'name': 'Delhi'
        },
        'serviceType': service.category
      },
      {
        '@type': 'BreadcrumbList',
        '@id': `${site.url}/services/${service.slug}.html#breadcrumb`,
        'itemListElement': [
          {
            '@type': 'ListItem',
            'position': 1,
            'name': 'Home',
            'item': `${site.url}/`
          },
          {
            '@type': 'ListItem',
            'position': 2,
            'name': 'Services',
            'item': `${site.url}/services.html`
          },
          {
            '@type': 'ListItem',
            'position': 3,
            'name': service.title,
            'item': `${site.url}/services/${service.slug}.html`
          }
        ]
      },
      {
        '@type': 'FAQPage',
        '@id': `${site.url}/services/${service.slug}.html#faq`,
        'mainEntity': service.faqs.map(f => ({
          '@type': 'Question',
          'name': f.q,
          'acceptedAnswer': {
            '@type': 'Answer',
            'text': f.a
          }
        }))
      }
    ]
  };

  const head = renderHead({
    title: `${service.title} in Delhi | Marketing Setu`,
    description: service.metaDesc,
    canonicalPath: `services/${service.slug}.html`,
    schema,
    relPrefix: '../'
  });

  const nav = renderNav({ currentPath: `services/${service.slug}`, relPrefix: '../' });

  // Find related service objects
  const relatedServicesList = (service.related || []).map(r => {
    return services.find(s => s.slug === r.slug) || {
      slug: r.slug,
      title: r.title,
      shortDesc: 'Comprehensive digital growth discipline by Marketing Setu Delhi.',
      pillar: 'Full-Funnel Growth'
    };
  });

  const body = `
  <main id="main-content">
    <!-- Service Hero -->
    <section class="section section-dark service-hero-section">
      <div class="container">
        <!-- Breadcrumbs -->
        <nav aria-label="Breadcrumb" class="service-breadcrumb">
          <a href="../index.html">Home</a>
          <span class="crumb-sep">/</span>
          <a href="../services.html">Services</a>
          <span class="crumb-sep">/</span>
          <span class="crumb-current">${escapeHtml(service.title.split('(')[0].trim())}</span>
        </nav>

        <div class="service-hero-grid">
          <div class="service-hero-content">
            <div class="service-hero-badges">
              <span class="section-badge">${escapeHtml(service.pillar)}</span>
              <span class="bento-metric-badge" style="color: var(--orange-bright);">${service.metric.value} ${service.metric.label}</span>
            </div>

            <h1 class="service-hero-title">
              ${escapeHtml(service.title)}
            </h1>

            <p class="service-hero-tagline">
              ${escapeHtml(service.tagline)}
            </p>

            <div class="service-hero-cta-group">
              <button class="btn btn-primary btn-lg" data-open-modal="true" data-service="${escapeHtml(service.title)}">
                <span>Book Free Consultation</span>
                <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
              </button>
              <a href="${site.contacts.whatsappUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-lg">
                <span>WhatsApp Strategy Chat</span>
              </a>
            </div>
          </div>

          <div class="service-hero-icon-box" aria-hidden="true">
            <svg viewBox="0 0 24 24">${service.svgPath}</svg>
          </div>
        </div>
      </div>
    </section>

    <!-- The Problem / Market Challenge -->
    <section class="section section-navy">
      <div class="container">
        <div class="intro-grid">
          <div>
            <span class="section-badge-navy" style="display:inline-block; font-size:0.75rem; padding:0.3rem 0.8rem; margin-bottom:1rem; border-radius:4px;">The Market Reality</span>
            <h2 style="margin-bottom: 1.2rem;">
              The Cost of <span class="highlight-orange">Inefficient Execution</span>
            </h2>
            <p style="font-size: 1.05rem; line-height: 1.7; color: var(--text-muted); margin-bottom: 1.4rem;">
              ${escapeHtml(service.challenge)}
            </p>
            <p style="font-size: 0.98rem; line-height: 1.7; color: #CBD5E1;">
              Marketing Setu eliminates this waste. Our 15-member team in Delhi treats your capital as an investment portfolio, executing with forensic data discipline and rigorous weekly review cycles.
            </p>
          </div>

          <div class="intro-right-card">
            <h3 style="margin-bottom: 1rem; font-size: 1.4rem;">What You Gain with Marketing Setu</h3>
            <ul style="list-style: none; display: flex; flex-direction: column; gap: 1rem; font-size: 0.95rem; color: #CBD5E1;">
              <li style="display: flex; gap: 0.75rem; align-items: flex-start;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--orange-bright)" stroke-width="2.5" style="flex-shrink:0; margin-top:2px;"><polyline points="20 6 9 17 4 12"/></svg>
                <span><strong>Full Commercial Ownership:</strong> Direct account access with zero agency lock-in.</span>
              </li>
              <li style="display: flex; gap: 0.75rem; align-items: flex-start;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--orange-bright)" stroke-width="2.5" style="flex-shrink:0; margin-top:2px;"><polyline points="20 6 9 17 4 12"/></svg>
                <span><strong>Dedicated Senior Governance:</strong> Director-level involvement across planning and launch.</span>
              </li>
              <li style="display: flex; gap: 0.75rem; align-items: flex-start;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--orange-bright)" stroke-width="2.5" style="flex-shrink:0; margin-top:2px;"><polyline points="20 6 9 17 4 12"/></svg>
                <span><strong>Real-Time Analytics:</strong> Live Looker Studio dashboards tracking tangible business ROI.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <!-- Detailed Deliverables -->
    <section class="section section-dark">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ Complete Scope</span>
          <h2 class="section-title">
            What We Deliver Inside <span class="highlight-orange">${escapeHtml(service.title.split('(')[0].trim())}</span>
          </h2>
          <p class="section-subtitle">
            A comprehensive, transparent breakdown of the exact tactical deliverables executed for your brand.
          </p>
        </div>

        <div class="why-grid">
          ${service.deliverables.map((d, i) => `
            <div class="why-card">
              <div style="font-family: var(--font-mono); font-size: 0.85rem; font-weight: 700; color: var(--orange-bright); margin-bottom: 0.8rem;">
                Deliverable 0${i + 1}
              </div>
              <h3 class="why-card-title">${escapeHtml(d.title)}</h3>
              <p class="why-card-desc">${escapeHtml(d.desc)}</p>
            </div>
          `).join('\n')}
        </div>
      </div>
    </section>

    <!-- Execution Workflow -->
    <section class="section section-navy">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ Step-by-Step Delivery</span>
          <h2 class="section-title">
            Our 4-Stage Execution <span class="highlight-orange">Workflow</span>
          </h2>
          <p class="section-subtitle">
            How we take your campaign from initial onboarding to compounding revenue impact.
          </p>
        </div>

        <div class="workflow-grid">
          ${service.process.map(p => `
            <div class="workflow-card">
              <div class="workflow-step-num">${p.step}</div>
              <h4 class="workflow-step-title">${escapeHtml(p.title)}</h4>
              <p class="workflow-step-desc">${escapeHtml(p.desc)}</p>
            </div>
          `).join('\n')}
        </div>
      </div>
    </section>

    <!-- Service Specific FAQs -->
    <section class="section section-dark">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ Common Inquiries</span>
          <h2 class="section-title">
            Questions About <span class="highlight-orange">${escapeHtml(service.title.split('(')[0].trim())}</span>
          </h2>
          <p class="section-subtitle">
            Clear answers to help you evaluate whether this discipline aligns with your commercial goals.
          </p>
        </div>

        <div class="faq-accordion-wrap">
          ${service.faqs.map((f, idx) => `
            <div class="faq-item ${idx === 0 ? 'active' : ''}">
              <button class="faq-question-btn" aria-expanded="${idx === 0 ? 'true' : 'false'}">
                <span>${escapeHtml(f.q)}</span>
                <span class="faq-icon-toggle">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
                </span>
              </button>
              <div class="faq-answer-pane" ${idx === 0 ? 'style="max-height: 250px;"' : ''}>
                <div class="faq-answer-inner">
                  ${escapeHtml(f.a)}
                </div>
              </div>
            </div>
          `).join('\n')}
        </div>
      </div>
    </section>

    <!-- Related Cross-Linked Services -->
    <section class="section section-navy">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ Synergistic Services</span>
          <h2 class="section-title">
            Recommended Disciplines To <span class="highlight-orange">Pair With This</span>
          </h2>
          <p class="section-subtitle">
            Full-funnel growth is achieved when complementary channels work in harmony.
          </p>
        </div>

        <div class="why-grid">
          ${relatedServicesList.slice(0, 3).map(r => `
            <div class="why-card">
              <span class="section-badge-navy" style="display:inline-block; font-size:0.72rem; padding:0.2rem 0.6rem; margin-bottom:0.8rem; border-radius:4px;">${r.pillar}</span>
              <h3 class="why-card-title">${escapeHtml(r.title)}</h3>
              <p class="why-card-desc">${escapeHtml(r.shortDesc)}</p>
              <div style="margin-top: auto; padding-top: 1.2rem;">
                <a href="${r.slug}.html" class="bento-link">
                  <span>View Discipline Blueprint</span>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
              </div>
            </div>
          `).join('\n')}
        </div>
      </div>
    </section>

    <!-- Dedicated Lead Capture Section -->
    <section class="section conversion-section">
      <div class="container">
        <div class="conversion-box">
          <div>
            <span class="section-badge">✦ Start Immediately</span>
            <h2 class="section-title">
              Request Your <span class="highlight-orange">${escapeHtml(service.title.split('(')[0].trim())}</span> Blueprint
            </h2>
            <p style="font-size: 1.05rem; line-height: 1.7; color: #CBD5E1; margin-bottom: 2rem;">
              Direct consultation with our senior growth directors in Delhi. We review your current baseline and construct a personalized 90-day execution roadmap.
            </p>
            <div class="conversion-cta-buttons" style="display: flex; gap: 1rem; align-items: center; flex-wrap: wrap;">
              <a href="${site.contacts.whatsappUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-outline-orange">
                <span>Chat On WhatsApp</span>
              </a>
              <a href="tel:${site.contacts.primaryPhone}" class="btn btn-secondary">
                <span>Call Now: ${site.contacts.primaryPhoneDisplay}</span>
              </a>
            </div>
          </div>

          <div>
            <form data-ms-form="true" action="../api/contact-handler.php" method="POST" class="conversion-form" data-redirect="../thank-you.html">
              <input type="text" name="_ms_hp" class="ms-hp-field" tabindex="-1" autocomplete="off">
              <input type="hidden" name="service" value="${escapeHtml(service.title)}">

              <div class="form-row-2">
                <div class="form-group">
                  <label for="service-lead-name" class="form-label">Full Name *</label>
                  <input type="text" id="service-lead-name" name="full_name" required placeholder="Vikas Sharma" autocomplete="name" class="form-input">
                </div>
                <div class="form-group">
                  <label for="service-lead-biz" class="form-label">Business Name</label>
                  <input type="text" id="service-lead-biz" name="business_name" placeholder="Acme Enterprises" autocomplete="organization" class="form-input">
                </div>
              </div>

              <div class="form-row-2">
                <div class="form-group">
                  <label for="service-lead-email" class="form-label">Work Email *</label>
                  <input type="email" id="service-lead-email" name="email" required placeholder="name@company.com" autocomplete="email" class="form-input">
                </div>
                <div class="form-group">
                  <label for="service-lead-phone" class="form-label">Phone / WhatsApp *</label>
                  <input type="tel" id="service-lead-phone" name="phone" required placeholder="+91 98765 43210" autocomplete="tel" class="form-input">
                </div>
              </div>

              <div class="form-group">
                <label for="service-lead-budget" class="form-label">Monthly Ad Budget</label>
                <select id="service-lead-budget" name="budget" class="form-select">
                  <option value="Exploring Options">Exploring Options</option>
                  <option value="₹30,000 - ₹75,000">₹30,000 – ₹75,000 /mo</option>
                  <option value="₹75,000 - ₹2,00,000">₹75,000 – ₹2,00,000 /mo</option>
                  <option value="₹2,00,000 - ₹5,00,000">₹2,00,000 – ₹5,00,000 /mo</option>
                  <option value="₹5,00,000+ (Enterprise)">₹5,00,000+ /mo (Enterprise)</option>
                </select>
              </div>

              <div class="form-group">
                <label for="service-lead-message" class="form-label">Describe Your Specific Objectives</label>
                <textarea id="service-lead-message" name="message" placeholder="Current baseline, target CPA, or existing bottlenecks..." class="form-textarea"></textarea>
              </div>

              <div class="form-status-msg"></div>

              <button type="submit" class="btn btn-primary btn-lg" style="width: 100%;">
                <span>Request Growth Blueprint</span>
                <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  </main>`;

  const footer = renderFooter({ relPrefix: '../' });
  return head + nav + body + footer;
}

module.exports = { generateServiceDetailPage };

/**
 * MARKETING SETU — SERVICES HUB TEMPLATE
 */

const site = require('../../data/site');
const services = require('../../data/services');
const { renderHead, renderNav, renderFooter, escapeHtml } = require('../templates/common');

function generateServicesHubPage() {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'CollectionPage',
    'name': 'All 20 Digital Marketing Services | Marketing Setu Delhi',
    'description': 'Explore our complete suite of 20 digital marketing services in Delhi: SEO, Google Ads, Meta Ads, Lead Generation, AEO, Web Design, and Creative Motion.',
    'url': `${site.url}/services.html`,
    'hasPart': services.map(s => ({
      '@type': 'Service',
      'name': s.title,
      'url': `${site.url}/services/${s.slug}.html`,
      'provider': {
        '@type': 'Organization',
        'name': site.name
      }
    }))
  };

  const head = renderHead({
    title: 'Digital Marketing Services Delhi | All 20 Core Disciplines | Marketing Setu',
    description: 'Explore Marketing Setu\'s full suite of 20 specialized digital marketing services in Delhi: SEO, Google Ads, Meta Ads, Lead Generation, AEO, Web Design, and Creative Motion.',
    canonicalPath: 'services.html',
    schema,
    relPrefix: ''
  });

  const nav = renderNav({ currentPath: 'services', relPrefix: '' });

  const body = `
  <main id="main-content">
    <!-- Header -->
    <section class="section section-dark" style="padding-top: 9rem; padding-bottom: 3.5rem;">
      <div class="container" style="text-align: center; max-width: 920px;">
        <span class="section-badge">✦ Full-Funnel Capabilities</span>
        <h1 style="margin-bottom: 1.5rem; font-size: clamp(2.4rem, 5vw, 4.2rem);">
          20 Specialized Disciplines.<br>
          <span class="highlight-orange">One Cohesive Growth Engine.</span>
        </h1>
        <p style="font-size: 1.15rem; color: #CBD5E1; line-height: 1.7; margin-bottom: 2rem;">
          From dominating Google and Perplexity search answers to deploying multi-million rupee ad budgets and crafting award-worthy web interfaces, explore our complete universe of growth capabilities.
        </p>
      </div>
    </section>

    <!-- Services Grid with Live Search & Filter -->
    <section class="section section-navy" style="padding-top: 1rem;">
      <div class="container">
        <!-- Filter Pills -->
        <div class="services-filter-bar" role="tablist" aria-label="Services Category Filters">
          <button class="filter-btn active" data-filter="all">All 20 Services</button>
          <button class="filter-btn" data-filter="Search & Discovery">Search & Discovery</button>
          <button class="filter-btn" data-filter="Paid Media & Ads">Paid Media & Ads</button>
          <button class="filter-btn" data-filter="Creative & Brand">Creative & Brand</button>
          <button class="filter-btn" data-filter="Performance & Tech">Performance & Tech</button>
        </div>

        <!-- Real-Time Search -->
        <div class="services-search-box">
          <label for="services-hub-search" class="sr-only">Search Services</label>
          <svg class="services-search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
          <input type="search" id="services-hub-search" name="services_query" placeholder="Filter by keyword (e.g. Google Ads, SEO, Local, Reels)..." class="services-search-input">
        </div>

        <!-- Bento Grid -->
        <div class="bento-services-grid">
          ${services.map((s, idx) => `
            <article class="bento-card" data-category="${escapeHtml(s.pillar)}">
              <div>
                <div class="bento-card-header">
                  <div class="bento-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24">${s.svgPath}</svg>
                  </div>
                  <div class="bento-metric-badge">
                    <span>${s.metric.value} ${s.metric.label}</span>
                  </div>
                </div>

                <span class="section-badge-navy" style="display:inline-block; font-size:0.72rem; padding:0.2rem 0.6rem; margin-bottom:0.75rem; border-radius:4px;">${s.pillar}</span>
                <h3 class="bento-title">${escapeHtml(s.title)}</h3>
                <p class="bento-desc">${escapeHtml(s.shortDesc)}</p>

                <div class="bento-deliverables-pill-group">
                  ${s.deliverables.slice(0, 3).map(d => `<span class="bento-deliverable-pill">✓ ${escapeHtml(d.title)}</span>`).join('')}
                </div>
              </div>

              <div class="bento-card-footer">
                <a href="services/${s.slug}.html" class="bento-link">
                  <span>Explore Service Blueprint</span>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
              </div>
            </article>
          `).join('\n')}
        </div>
      </div>
    </section>

    <!-- Comparison Table -->
    <section class="section section-dark">
      <div class="container">
        <div class="section-header">
          <span class="section-badge">✦ The Comparative Standard</span>
          <h2 class="section-title">
            How Marketing Setu <span class="highlight-orange">Compares</span>
          </h2>
          <p class="section-subtitle">
            Why leading brands choose a multidisciplinary Delhi partner over generic agencies or unpredictable freelancers.
          </p>
        </div>

        <div style="overflow-x: auto; background: var(--surface-card); border-radius: var(--radius-lg); border: 1px solid var(--border-glass); padding: 1.5rem;">
          <table style="width: 100%; border-collapse: collapse; min-width: 650px; font-size: 0.92rem; color: #CBD5E1;">
            <thead>
              <tr style="border-bottom: 2px solid var(--border-glass); text-align: left;">
                <th style="padding: 1.2rem; font-family: var(--font-heading); color: #FFFFFF; font-size: 1rem;">Execution Dimension</th>
                <th style="padding: 1.2rem; font-family: var(--font-heading); color: var(--orange-bright); font-size: 1.05rem;">Marketing Setu (15 In-House)</th>
                <th style="padding: 1.2rem; font-family: var(--font-heading); color: #94A3B8; font-size: 0.95rem;">Traditional Retainer Agency</th>
                <th style="padding: 1.2rem; font-family: var(--font-heading); color: #94A3B8; font-size: 0.95rem;">Low-Cost Freelancers</th>
              </tr>
            </thead>
            <tbody>
              <tr style="border-bottom: 1px solid var(--border-glass);">
                <td style="padding: 1.2rem; font-weight: 600; color: #FFFFFF;">Primary KPI Alignment</td>
                <td style="padding: 1.2rem; color: #4ADE80; font-weight: 600;">Net Sales Leads, Revenue & Real CAC</td>
                <td style="padding: 1.2rem; color: #94A3B8;">Vanity Impressions & Social Likes</td>
                <td style="padding: 1.2rem; color: #94A3B8;">Isolated Task Completion Only</td>
              </tr>
              <tr style="border-bottom: 1px solid var(--border-glass);">
                <td style="padding: 1.2rem; font-weight: 600; color: #FFFFFF;">Team Structure</td>
                <td style="padding: 1.2rem; color: #4ADE80; font-weight: 600;">15 Multidisciplinary Specialists</td>
                <td style="padding: 1.2rem; color: #94A3B8;">Layers of Account Managers & Interns</td>
                <td style="padding: 1.2rem; color: #94A3B8;">Solo Individual with Limited Scope</td>
              </tr>
              <tr style="border-bottom: 1px solid var(--border-glass);">
                <td style="padding: 1.2rem; font-weight: 600; color: #FFFFFF;">Account Governance</td>
                <td style="padding: 1.2rem; color: #4ADE80; font-weight: 600;">Direct Access to Directors Vikas & Pushpendra</td>
                <td style="padding: 1.2rem; color: #94A3B8;">Junior Account Executives</td>
                <td style="padding: 1.2rem; color: #94A3B8;">Unpredictable Availability</td>
              </tr>
              <tr style="border-bottom: 1px solid var(--border-glass);">
                <td style="padding: 1.2rem; font-weight: 600; color: #FFFFFF;">2026 AI Preparedness (AEO/GEO)</td>
                <td style="padding: 1.2rem; color: #4ADE80; font-weight: 600;">Fully Integrated AI Answer Optimization</td>
                <td style="padding: 1.2rem; color: #94A3B8;">Outdated Keyword Formulas</td>
                <td style="padding: 1.2rem; color: #94A3B8;">No Architecture</td>
              </tr>
              <tr>
                <td style="padding: 1.2rem; font-weight: 600; color: #FFFFFF;">Account & Asset Ownership</td>
                <td style="padding: 1.2rem; color: #4ADE80; font-weight: 600;">100% Owned by Client from Day 1</td>
                <td style="padding: 1.2rem; color: #94A3B8;">Held Hostage in Agency Portals</td>
                <td style="padding: 1.2rem; color: #94A3B8;">Scattered File Handoffs</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- Consultation CTA -->
    <section class="section section-navy" style="text-align: center;">
      <div class="container" style="max-width: 800px;">
        <span class="section-badge">✦ Let's Discuss Your Mix</span>
        <h2 style="margin-bottom: 1.2rem;">Unsure Which Service Mix Fits Your Stage?</h2>
        <p style="color: #CBD5E1; font-size: 1.1rem; line-height: 1.7; margin-bottom: 2.2rem;">
          Schedule a 30-minute discovery consultation with our senior directors. We will analyze your current performance and recommend the highest-impact channels.
        </p>
        <button class="btn btn-primary btn-lg" data-open-modal="true" data-service="Full Funnel Mix Consultation">
          <span>Request Custom Services Blueprint</span>
          <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
        </button>
      </div>
    </section>
  </main>`;

  const footer = renderFooter({ relPrefix: '' });
  return head + nav + body + footer;
}

module.exports = { generateServicesHubPage };

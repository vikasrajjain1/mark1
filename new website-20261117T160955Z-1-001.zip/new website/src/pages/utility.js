/**
 * MARKETING SETU — UTILITY PAGES (THANK YOU & CUSTOM 404)
 */

const site = require('../../data/site');
const { renderHead, renderNav, renderFooter } = require('../templates/common');

function generateThankYouPage() {
  const head = renderHead({
    title: 'Thank You | Strategy Request Received | Marketing Setu',
    description: 'Thank you for reaching out to Marketing Setu. Our senior growth team in Delhi will review your business goals and reach out within 2 hours.',
    canonicalPath: 'thank-you.html',
    relPrefix: ''
  });

  const nav = renderNav({ currentPath: 'thank-you', relPrefix: '' });

  const body = `
  <main id="main-content">
    <section class="section section-dark" style="min-height: 80vh; display: flex; align-items: center; padding-top: 9rem; padding-bottom: 5rem;">
      <div class="container" style="text-align: center; max-width: 760px;">
        <div style="width: 80px; height: 80px; border-radius: 50%; background: rgba(34, 197, 94, 0.15); border: 2px solid #22C55E; display: flex; align-items: center; justify-content: center; color: #4ADE80; margin: 0 auto 2rem auto;">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
        </div>

        <span class="section-badge" style="background: rgba(34, 197, 94, 0.15); border-color: rgba(34, 197, 94, 0.3); color: #4ADE80;">✦ Inquiry Confirmed</span>
        <h1 style="margin-bottom: 1.2rem; font-size: clamp(2.3rem, 4.5vw, 3.6rem);">
          Your Strategy Request Has Been <span class="highlight-orange">Transmitted</span>
        </h1>

        <p style="font-size: 1.15rem; color: #CBD5E1; line-height: 1.7; margin-bottom: 2.5rem;">
          Thank you for trusting Marketing Setu. Director Vikas Jain and our senior strategy team in Delhi are already reviewing your submission. You will receive a personalized response within 2 business hours.
        </p>

        <!-- What Happens Next -->
        <div style="background: var(--surface-card); border: 1px solid var(--border-glass); border-radius: var(--radius-lg); padding: 2rem; text-align: left; margin-bottom: 2.5rem;">
          <h3 style="font-size: 1.2rem; margin-bottom: 1.2rem; color: #FFFFFF;">What Happens Next:</h3>
          <div style="display: flex; flex-direction: column; gap: 1rem; font-size: 0.95rem; color: #CBD5E1;">
            <div style="display: flex; gap: 0.8rem; align-items: flex-start;">
              <span style="font-family: var(--font-mono); font-weight: 700; color: var(--orange-bright);">01.</span>
              <span><strong>Baseline Audit:</strong> We analyze your public digital footprint, competitors, and keyword landscape.</span>
            </div>
            <div style="display: flex; gap: 0.8rem; align-items: flex-start;">
              <span style="font-family: var(--font-mono); font-weight: 700; color: var(--orange-bright);">02.</span>
              <span><strong>Roadmap Draft:</strong> We prepare specific high-impact recommendations for your commercial goals.</span>
            </div>
            <div style="display: flex; gap: 0.8rem; align-items: flex-start;">
              <span style="font-family: var(--font-mono); font-weight: 700; color: var(--orange-bright);">03.</span>
              <span><strong>Director Call:</strong> We connect directly via telephone or Google Meet to review the strategy.</span>
            </div>
          </div>
        </div>

        <!-- Quick Actions -->
        <div style="display: flex; justify-content: center; gap: 1.2rem; flex-wrap: wrap;">
          <a href="${site.contacts.whatsappUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-lg">
            <span>Fast-Track On WhatsApp</span>
            <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
          </a>
          <a href="index.html" class="btn btn-secondary btn-lg">
            <span>Return to Homepage</span>
          </a>
        </div>
      </div>
    </section>
  </main>`;

  const footer = renderFooter({ relPrefix: '' });
  return head + nav + body + footer;
}

function generate404Page() {
  const head = renderHead({
    title: '404 — Page Not Found | Marketing Setu',
    description: 'The requested page could not be located. Explore our 20 specialized digital marketing services or return to the homepage.',
    canonicalPath: '404.html',
    relPrefix: ''
  });

  const nav = renderNav({ currentPath: '404', relPrefix: '' });

  const body = `
  <main id="main-content">
    <section class="section section-dark" style="min-height: 80vh; display: flex; align-items: center; padding-top: 9rem; padding-bottom: 5rem;">
      <div class="container" style="text-align: center; max-width: 700px;">
        <div style="font-family: var(--font-heading); font-size: clamp(5rem, 12vw, 8rem); font-weight: 900; line-height: 1; color: var(--orange-bright); margin-bottom: 1rem; text-shadow: 0 0 40px rgba(255,101,0,0.3);">
          404
        </div>

        <span class="section-badge">✦ Route Disconnected</span>
        <h1 style="margin-bottom: 1.2rem; font-size: clamp(2rem, 4vw, 3rem);">
          The Bridge You Seek <span class="highlight-orange">Does Not Exist</span>
        </h1>

        <p style="font-size: 1.15rem; color: #CBD5E1; line-height: 1.7; margin-bottom: 2.5rem;">
          The page may have moved or been updated as part of our 2026 digital architecture refresh. Let's redirect you back to active ground.
        </p>

        <div style="display: flex; justify-content: center; gap: 1.2rem; flex-wrap: wrap;">
          <a href="index.html" class="btn btn-primary btn-lg">
            <span>Return to Homepage</span>
            <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
          </a>
          <a href="services.html" class="btn btn-secondary btn-lg">
            <span>Explore All 20 Services</span>
          </a>
        </div>
      </div>
    </section>
  </main>`;

  const footer = renderFooter({ relPrefix: '' });
  return head + nav + body + footer;
}

module.exports = {
  generateThankYouPage,
  generate404Page
};

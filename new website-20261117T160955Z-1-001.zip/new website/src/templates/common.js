/**
 * MARKETING SETU — SHARED TEMPLATE COMPONENTS
 */

const site = require('../../data/site');
const services = require('../../data/services');

function renderHead({ title, description, canonicalPath = '', schema = null, relPrefix = '' }) {
  const canonicalUrl = `${site.url}${canonicalPath ? '/' + canonicalPath.replace(/^\//, '') : ''}`;
  const pageTitle = title.includes(site.name) ? title : `${title} | ${site.name}`;

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(pageTitle)}</title>
  <meta name="description" content="${escapeHtml(description)}">
  <link rel="canonical" href="${canonicalUrl}">
  <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">

  <!-- Open Graph / Social -->
  <meta property="og:type" content="website">
  <meta property="og:url" content="${canonicalUrl}">
  <meta property="og:title" content="${escapeHtml(pageTitle)}">
  <meta property="og:description" content="${escapeHtml(description)}">
  <meta property="og:site_name" content="${site.name}">
  <meta property="og:locale" content="en_IN">
  <meta property="og:image" content="${site.url}/assets/images/logo.png">

  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${escapeHtml(pageTitle)}">
  <meta name="twitter:description" content="${escapeHtml(description)}">
  <meta name="twitter:image" content="${site.url}/assets/images/logo.png">

  <!-- Favicon & Brand Icons -->
  <link rel="icon" type="image/svg+xml" href="${relPrefix}assets/images/favicon.svg">
  <link rel="apple-touch-icon" href="${relPrefix}assets/images/favicon.svg">
  <meta name="theme-color" content="#050D1F">

  <!-- Preconnect & Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">

  <!-- Master Stylesheet -->
  <link rel="stylesheet" href="${relPrefix}assets/css/main.css">

  ${schema ? `<script type="application/ld+json">\n${JSON.stringify(schema, null, 2)}\n  </script>` : ''}
</head>
<body>`;
}

function renderNav({ currentPath = '', relPrefix = '' }) {
  // Group services by category for mega menu
  const searchServices = services.filter(s => s.pillar === 'Search & Discovery');
  const paidServices = services.filter(s => s.pillar === 'Paid Media & Ads');
  const creativeServices = services.filter(s => s.pillar === 'Creative & Brand');
  const techServices = services.filter(s => s.pillar === 'Performance & Tech');

  return `
  <!-- HEADER NAVIGATION -->
  <header class="site-header" role="banner">
    <div class="container-wide nav-container">
      <a href="${relPrefix}index.html" class="brand-logo-wrap" aria-label="Marketing Setu Home">
        <img src="${relPrefix}assets/images/logo-white.png" alt="Marketing Setu Logo - Digital Growth Agency" class="brand-logo-img" width="220" height="44">
      </a>

      <!-- Desktop Navigation -->
      <nav class="main-navigation" role="navigation" aria-label="Main menu">
        <a href="${relPrefix}index.html" class="nav-link ${currentPath === 'home' ? 'active' : ''}">Home</a>
        <a href="${relPrefix}about.html" class="nav-link ${currentPath === 'about' ? 'active' : ''}">About</a>

        <!-- Services with Mega Menu -->
        <div class="nav-item-dropdown">
          <a href="${relPrefix}services.html" class="nav-link ${currentPath.startsWith('services') ? 'active' : ''}">
            Services
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m6 9 6 6 6-6"/></svg>
          </a>

          <div class="mega-menu" role="region" aria-label="Services Mega Menu">
            <div class="mega-menu-grid">
              <div class="mega-col">
                <div class="mega-col-title">Search & Discovery</div>
                ${searchServices.map(s => `<a href="${relPrefix}services/${s.slug}.html" class="mega-menu-item">${s.title.split('(')[0].trim()}</a>`).join('\n')}
              </div>
              <div class="mega-col">
                <div class="mega-col-title">Paid Media & Ads</div>
                ${paidServices.map(s => `<a href="${relPrefix}services/${s.slug}.html" class="mega-menu-item">${s.title.split('(')[0].trim()}</a>`).join('\n')}
              </div>
              <div class="mega-col">
                <div class="mega-col-title">Creative & Brand</div>
                ${creativeServices.map(s => `<a href="${relPrefix}services/${s.slug}.html" class="mega-menu-item">${s.title.split('(')[0].trim()}</a>`).join('\n')}
              </div>
              <div class="mega-col">
                <div class="mega-col-title">Performance & Tech</div>
                ${techServices.map(s => `<a href="${relPrefix}services/${s.slug}.html" class="mega-menu-item">${s.title.split('(')[0].trim()}</a>`).join('\n')}
              </div>
            </div>
            <div class="mega-menu-footer">
              <span style="color: #94A3B8; font-size: 0.85rem;">✦ Delhi's 15-Member Performance Marketing & Creative Powerhouse</span>
              <a href="${relPrefix}services.html" class="bento-link" style="font-size: 0.85rem;">View All 20 Services →</a>
            </div>
          </div>
        </div>

        <a href="${relPrefix}portfolio.html" class="nav-link ${currentPath === 'portfolio' ? 'active' : ''}">Capabilities</a>
        <a href="${relPrefix}blog.html" class="nav-link ${currentPath.startsWith('blog') ? 'active' : ''}">Insights</a>
        <a href="${relPrefix}contact.html" class="nav-link ${currentPath === 'contact' ? 'active' : ''}">Contact</a>
      </nav>

      <!-- Desktop Nav Actions -->
      <div class="nav-actions">
        <a href="tel:${site.contacts.primaryPhone}" class="nav-phone" aria-label="Call Marketing Setu">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
          <span>${site.contacts.primaryPhoneDisplay}</span>
        </a>
        <button class="btn btn-primary btn-sm" data-open-modal="true" data-service="General Consultation">
          <span>Book Strategy Call</span>
          <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
        </button>
      </div>

      <!-- Mobile Hamburger Toggle -->
      <button class="mobile-nav-toggle" aria-label="Toggle navigation menu" aria-expanded="false">
        <span></span>
        <span></span>
        <span></span>
      </button>
    </div>
  </header>

  <!-- Mobile Drawer -->
  <div class="mobile-drawer" role="dialog" aria-modal="true" aria-label="Mobile Navigation Menu">
    <div class="mobile-drawer-links">
      <a href="${relPrefix}index.html" class="mobile-nav-link">Home</a>
      <a href="${relPrefix}about.html" class="mobile-nav-link">About Us</a>
      <a href="${relPrefix}services.html" class="mobile-nav-link">All 20 Services</a>
      <a href="${relPrefix}portfolio.html" class="mobile-nav-link">Capabilities</a>
      <a href="${relPrefix}blog.html" class="mobile-nav-link">Insights & Blog</a>
      <a href="${relPrefix}contact.html" class="mobile-nav-link">Contact</a>
    </div>

    <div class="mobile-drawer-footer">
      <a href="tel:${site.contacts.primaryPhone}" class="btn btn-secondary btn-sm" style="width: 100%;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
        <span>Call: ${site.contacts.primaryPhoneDisplay}</span>
      </a>
      <a href="${site.contacts.whatsappUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm" style="width: 100%;">
        <span>WhatsApp Strategy Chat</span>
      </a>
    </div>
  </div>`;
}

function renderFooter({ relPrefix = '', extraScripts = [] } = {}) {
  return `
  <!-- FOOTER -->
  <footer class="site-footer" role="contentinfo">
    <div class="container">
      <div class="footer-top-grid">
        <!-- Brand Col -->
        <div class="footer-brand-col">
          <a href="${relPrefix}index.html" aria-label="Marketing Setu">
            <img src="${relPrefix}assets/images/logo-white.png" alt="Marketing Setu" width="220" height="44" class="brand-logo-img">
          </a>
          <p>
            From Strategy to Growth. Delhi's multidisciplinary 15-member digital agency combining creative motion design, full-funnel paid advertising, organic topical authority, and technical engineering.
          </p>
          <div style="display: flex; gap: 0.8rem; margin-top: 1rem;">
            <a href="${site.contacts.whatsappUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-outline-orange btn-sm" style="padding: 0.5rem 1rem;">
              WhatsApp Us
            </a>
            <a href="tel:${site.contacts.primaryPhone}" class="btn btn-secondary btn-sm" style="padding: 0.5rem 1rem;">
              Call Now
            </a>
          </div>
        </div>

        <!-- Pillar Links: Search & Paid -->
        <div>
          <h5 class="footer-heading">Search & Performance</h5>
          <ul class="footer-links-list">
            <li><a href="${relPrefix}services/seo.html" class="footer-link">Search Engine Optimization</a></li>
            <li><a href="${relPrefix}services/google-ads.html" class="footer-link">Google Ads Management</a></li>
            <li><a href="${relPrefix}services/meta-ads.html" class="footer-link">Meta Ads Management</a></li>
            <li><a href="${relPrefix}services/lead-generation.html" class="footer-link">Lead Generation Funnels</a></li>
            <li><a href="${relPrefix}services/aeo.html" class="footer-link">Answer Engine Optimization</a></li>
            <li><a href="${relPrefix}services/geo.html" class="footer-link">Generative Engine Optimization</a></li>
            <li><a href="${relPrefix}services/technical-seo.html" class="footer-link">Technical SEO & Vitals</a></li>
          </ul>
        </div>

        <!-- Pillar Links: Creative & Web -->
        <div>
          <h5 class="footer-heading">Creative & Tech</h5>
          <ul class="footer-links-list">
            <li><a href="${relPrefix}services/website-design.html" class="footer-link">Website Design & Dev</a></li>
            <li><a href="${relPrefix}services/app-design.html" class="footer-link">App UI/UX Design</a></li>
            <li><a href="${relPrefix}services/branding.html" class="footer-link">Branding & Strategy</a></li>
            <li><a href="${relPrefix}services/video-editing.html" class="footer-link">Video Editing & Motion</a></li>
            <li><a href="${relPrefix}services/graphic-design.html" class="footer-link">Graphic Designing</a></li>
            <li><a href="${relPrefix}services/social-media-marketing.html" class="footer-link">Social Media Marketing</a></li>
            <li><a href="${relPrefix}services/linkedin-marketing.html" class="footer-link">LinkedIn B2B Growth</a></li>
          </ul>
        </div>

        <!-- Direct Contact Col -->
        <div>
          <h5 class="footer-heading">Agency Headquarters</h5>
          <div class="footer-contact-item">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
            <span>${site.location.address}</span>
          </div>
          <div class="footer-contact-item">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
            <div>
              <a href="tel:${site.contacts.primaryPhone}" class="footer-link" style="display:block;">${site.contacts.primaryPhoneDisplay}</a>
              <a href="tel:${site.contacts.alternatePhone}" class="footer-link" style="display:block;">${site.contacts.alternatePhoneDisplay}</a>
            </div>
          </div>
          <div class="footer-contact-item">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
            <a href="mailto:${site.contacts.email}" class="footer-link">${site.contacts.email}</a>
          </div>
          <div class="footer-contact-item" style="color: #64748B; font-size: 0.8rem; margin-top: 0.8rem;">
            <span>${site.contacts.hours}</span>
          </div>
        </div>
      </div>

      <!-- Bottom Bar -->
      <div class="footer-bottom-bar">
        <div>
          &copy; ${new Date().getFullYear()} ${site.legalName}. All rights reserved. Based with pride in Delhi, India.
        </div>
        <div class="footer-bottom-links">
          <a href="${relPrefix}privacy-policy.html" class="footer-link">Privacy Policy</a>
          <a href="${relPrefix}terms-conditions.html" class="footer-link">Terms & Conditions</a>
          <a href="${relPrefix}sitemap.xml" class="footer-link">Sitemap</a>
        </div>
      </div>
    </div>
  </footer>

  <!-- FLOATING CONNECT ACTIONS -->
  <div class="floating-connect-wrap" aria-label="Quick Connect Actions">
    <a href="${site.contacts.whatsappUrl}" target="_blank" rel="noopener noreferrer" class="floating-btn floating-whatsapp" aria-label="Chat on WhatsApp">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor"><path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2m.01 1.67c2.2 0 4.26.86 5.82 2.42a8.225 8.225 0 0 1 2.41 5.83c0 4.54-3.7 8.24-8.24 8.24-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.196 8.196 0 0 1-1.26-4.38c0-4.54 3.7-8.24 8.24-8.24m4.52 11.66c-.19.53-1.11 1.04-1.54 1.09-.41.05-.93.07-2.69-.66-2.25-.93-3.69-3.23-3.8-3.38-.11-.15-.9-1.2-0.9-2.28 0-1.09.57-1.62.77-1.85.2-.22.45-.28.6-.28.15 0 .3 0 .43.01.14.01.33-.05.51.39.19.45.64 1.56.7 1.67.06.11.1.25.02.4-.07.15-.11.25-.22.38-.11.13-.24.29-.34.39-.11.11-.23.23-.1.45.13.22.58.96 1.25 1.55.86.77 1.59 1.01 1.81 1.12.22.11.35.1.48-.05.13-.15.56-.65.71-.88.15-.22.3-.19.51-.11.2.07 1.3.61 1.52.72.22.11.37.17.43.26.05.1.05.57-.14 1.1z"/></svg>
    </a>
    <a href="tel:${site.contacts.primaryPhone}" class="floating-btn floating-phone" aria-label="Call Marketing Setu">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
    </a>
    <button class="floating-btn floating-top" aria-label="Scroll to top of page">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="m18 15-6-6-6 6"/></svg>
    </button>
  </div>

  <!-- LEAD GENERATION QUICK AUDIT MODAL -->
  <div id="lead-modal" class="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="modal-title">
    <div class="modal-dialog">
      <button class="modal-close-btn" aria-label="Close modal">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 6 6 18M6 6l12 12"/></svg>
      </button>

      <span class="section-badge" style="margin-bottom: 0.8rem;">✦ Free Strategy Blueprint</span>
      <h3 id="modal-title" style="margin-bottom: 0.6rem; font-size: 1.6rem;">Let's Build Your Growth Plan</h3>
      <p style="color: #94A3B8; font-size: 0.9rem; margin-bottom: 1.8rem;">
        Speak directly with our senior directors in Delhi. No junior pitch reps. No fluff.
      </p>

      <form data-ms-form="true" action="${relPrefix}api/contact-handler.php" method="POST" class="conversion-form">
        <!-- Bot honeypot -->
        <input type="text" name="_ms_hp" class="ms-hp-field" tabindex="-1" autocomplete="off">

        <div class="form-row-2">
          <div class="form-group">
            <label for="modal-field-name" class="form-label">Full Name *</label>
            <input type="text" id="modal-field-name" name="full_name" required placeholder="Vikas Sharma" autocomplete="name" class="form-input">
          </div>
          <div class="form-group">
            <label for="modal-field-biz" class="form-label">Business Name</label>
            <input type="text" id="modal-field-biz" name="business_name" placeholder="Acme Enterprises" autocomplete="organization" class="form-input">
          </div>
        </div>

        <div class="form-row-2">
          <div class="form-group">
            <label for="modal-field-email" class="form-label">Work Email *</label>
            <input type="email" id="modal-field-email" name="email" required placeholder="name@company.com" autocomplete="email" class="form-input">
          </div>
          <div class="form-group">
            <label for="modal-field-phone" class="form-label">Phone / WhatsApp *</label>
            <input type="tel" id="modal-field-phone" name="phone" required placeholder="+91 98765 43210" autocomplete="tel" class="form-input">
          </div>
        </div>

        <div class="form-row-2">
          <div class="form-group">
            <label for="modal-field-service" class="form-label">Required Service</label>
            <select name="service" id="modal-field-service" class="form-select">
              <option value="General Growth Consultation">General Growth Consultation</option>
              ${services.map(s => `<option value="${s.title}">${s.title}</option>`).join('\n')}
            </select>
          </div>
          <div class="form-group">
            <label for="modal-field-budget" class="form-label">Monthly Ad Budget</label>
            <select name="budget" id="modal-field-budget" class="form-select">
              <option value="Exploring Options">Exploring Options</option>
              <option value="₹30,000 - ₹75,000">₹30,000 – ₹75,000 /mo</option>
              <option value="₹75,000 - ₹2,00,000">₹75,000 – ₹2,00,000 /mo</option>
              <option value="₹2,00,000 - ₹5,00,000">₹2,00,000 – ₹5,00,000 /mo</option>
              <option value="₹5,00,000+ (Scale)">₹5,00,000+ /mo (Enterprise)</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label for="modal-field-message" class="form-label">Tell Us About Your Goals</label>
          <textarea name="message" id="modal-field-message" placeholder="Current monthly revenue, target CAC, or specific challenges..." class="form-textarea"></textarea>
        </div>

        <div class="form-status-msg"></div>

        <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 0.5rem;">
          <span>Request Growth Blueprint</span>
          <span class="btn-icon-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
        </button>

        <p class="form-disclaimer">
          🔒 We respect your confidentiality. NDA-grade privacy. We never spam or sell client records.
        </p>
      </form>
    </div>
  </div>

  <!-- SCRIPTS -->
  <script src="${relPrefix}assets/js/vendor/three.min.js"></script>
  <script src="${relPrefix}assets/js/vendor/gsap.min.js"></script>
  <script src="${relPrefix}assets/js/vendor/ScrollTrigger.min.js"></script>
  <script src="${relPrefix}assets/js/main.js"></script>
  <script src="${relPrefix}assets/js/motion.js"></script>
  ${extraScripts.map(s => `<script src="${relPrefix}${s}"></script>`).join('\n  ')}
</body>
</html>`;
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
}

module.exports = {
  renderHead,
  renderNav,
  renderFooter,
  escapeHtml
};
